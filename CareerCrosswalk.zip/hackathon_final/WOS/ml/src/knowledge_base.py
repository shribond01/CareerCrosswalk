"""Minimum viable workforce knowledge layer for the WOS demo.

No O*NET dataset or API configuration is present in this workspace. The records
below are a clearly labelled development fixture derived only from the canonical
skill catalog. They are not official O*NET observations and must not be presented
as labor-market facts. A future O*NET adapter can implement the same interface.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Mapping

SOURCE_TYPE = "development_fixture_not_official_onet"


@dataclass(frozen=True)
class SkillContext:
    skill: str
    related_occupations: List[str]
    importance: float
    workforce_relevance: str
    source_type: str = SOURCE_TYPE


_FIXTURE: Mapping[str, SkillContext] = {
    "Python": SkillContext("Python", ["Software Developer", "Data Scientist", "Machine Learning Engineer"], 0.90, "Core implementation skill across software and data workflows."),
    "Machine Learning": SkillContext("Machine Learning", ["Machine Learning Engineer", "Data Scientist"], 0.95, "Core modeling skill for predictive systems."),
    "Deep Learning": SkillContext("Deep Learning", ["Machine Learning Engineer", "Computer Vision Engineer"], 0.88, "Specialized modeling skill for neural architectures."),
    "Natural Language Processing": SkillContext("Natural Language Processing", ["NLP Engineer", "Data Scientist"], 0.82, "Specialized language-data modeling skill."),
    "Computer Vision": SkillContext("Computer Vision", ["Computer Vision Engineer", "Machine Learning Engineer"], 0.86, "Specialized image and video intelligence skill."),
    "PyTorch": SkillContext("PyTorch", ["Machine Learning Engineer", "Research Engineer"], 0.78, "Common deep-learning implementation framework."),
    "TensorFlow": SkillContext("TensorFlow", ["Machine Learning Engineer", "Research Engineer"], 0.78, "Common production and research deep-learning framework."),
    "SQL": SkillContext("SQL", ["Data Analyst", "Data Engineer", "Data Scientist"], 0.84, "Core data access and transformation skill."),
    "PostgreSQL": SkillContext("PostgreSQL", ["Backend Developer", "Data Engineer"], 0.72, "Database implementation skill for application and data systems."),
    "FastAPI": SkillContext("FastAPI", ["Backend Developer", "Machine Learning Engineer"], 0.70, "API delivery skill for Python services."),
    "Docker": SkillContext("Docker", ["DevOps Engineer", "Machine Learning Engineer", "Backend Developer"], 0.80, "Container packaging and reproducible delivery skill."),
    "Kubernetes": SkillContext("Kubernetes", ["DevOps Engineer", "Site Reliability Engineer", "MLOps Engineer"], 0.86, "Orchestration skill for scalable services."),
    "AWS": SkillContext("AWS", ["Cloud Engineer", "DevOps Engineer", "Machine Learning Engineer"], 0.83, "Cloud infrastructure and service delivery skill."),
    "JavaScript": SkillContext("JavaScript", ["Frontend Developer", "Full Stack Developer"], 0.74, "Web application implementation skill."),
    "React": SkillContext("React", ["Frontend Developer", "Full Stack Developer"], 0.76, "Component-based web interface skill."),
    "Data Science": SkillContext("Data Science", ["Data Scientist", "Analytics Engineer"], 0.89, "Applied analytics and experimentation skill."),
    "MLOps": SkillContext("MLOps", ["MLOps Engineer", "Machine Learning Engineer", "DevOps Engineer"], 0.91, "Operational lifecycle skill for deploying and monitoring models."),
}


def _get(skill: str) -> SkillContext:
    if skill in _FIXTURE:
        return _FIXTURE[skill]
    return SkillContext(skill, [], 0.50, "No fixture context is available for this skill.")


def get_skill_context(skill: str) -> Dict[str, object]:
    """Return context for one canonical skill, marked as development fixture data."""
    context = _get(skill)
    return {
        "skill": context.skill,
        "related_occupations": list(context.related_occupations),
        "importance": context.importance,
        "workforce_relevance": context.workforce_relevance,
        "source_type": context.source_type,
    }


def get_related_occupations(skill: str) -> List[str]:
    return list(_get(skill).related_occupations)


def get_skill_importance(skill: str) -> float:
    return float(_get(skill).importance)


class DevelopmentFixtureKnowledgeBase:
    """Adapter-shaped object that can later be replaced by an O*NET adapter."""

    source_type = SOURCE_TYPE

    def get_skill_context(self, skill: str) -> Dict[str, object]:
        return get_skill_context(skill)

    def get_related_occupations(self, skill: str) -> List[str]:
        return get_related_occupations(skill)

    def get_skill_importance(self, skill: str) -> float:
        return get_skill_importance(skill)


def get_default_knowledge_base() -> DevelopmentFixtureKnowledgeBase:
    return DevelopmentFixtureKnowledgeBase()
