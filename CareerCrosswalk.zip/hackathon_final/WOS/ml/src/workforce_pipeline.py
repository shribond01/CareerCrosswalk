"""End-to-end WOS workforce intelligence pipeline for the development demo."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence

from hybrid_matcher import HybridSkillMatcher, MatcherConfig
from knowledge_base import DevelopmentFixtureKnowledgeBase, get_default_knowledge_base
from workforce_scorer import ScoringConfig, score_workforce


class WorkforcePipeline:
    """Reusable candidate/job analyzer; the matcher is constructed once."""

    def __init__(
        self,
        skill_names: Sequence[str],
        skill_embedding_artifact: Optional[Path] = None,
        matcher_config: Optional[MatcherConfig] = None,
        scoring_config: Optional[ScoringConfig] = None,
        knowledge_base: Optional[DevelopmentFixtureKnowledgeBase] = None,
        selection_threshold: float = 0.60,
    ) -> None:
        if not 0.0 <= selection_threshold <= 1.0:
            raise ValueError("selection_threshold must be between 0 and 1")
        self.matcher = HybridSkillMatcher(skill_names, config=matcher_config, skill_embedding_artifact=skill_embedding_artifact)
        self.scoring_config = scoring_config or ScoringConfig()
        self.knowledge_base = knowledge_base or get_default_knowledge_base()
        self.selection_threshold = selection_threshold

    def _select(self, match_output: Mapping[str, Any]) -> List[Dict[str, Any]]:
        """Select explicit lexical matches plus high-confidence hybrid matches."""
        selected = []
        for item in match_output["hybrid_ranking"]:
            if item["lexical_match"] or float(item["hybrid_score"]) >= self.selection_threshold:
                selected.append(dict(item))
        # A no-match input remains a valid pipeline output without inventing a skill.
        return selected

    def _extract_required_skills(self, job_description: str, job_match: Mapping[str, Any]) -> List[str]:
        explicit = list(job_match["lexical_matches"])
        if explicit:
            return explicit
        return [item["skill"] for item in job_match["hybrid_ranking"] if float(item["hybrid_score"]) >= self.selection_threshold]

    def analyze_candidate(self, resume_text: str, job_description: str) -> Dict[str, Any]:
        if not str(resume_text).strip():
            raise ValueError("resume_text must not be empty")
        if not str(job_description).strip():
            raise ValueError("job_description must not be empty")
        candidate_match = self.matcher.match(resume_text, top_k=len(self.matcher.skill_names))
        job_match = self.matcher.match(job_description, top_k=len(self.matcher.skill_names))
        candidate_selected = self._select(candidate_match)
        required = self._extract_required_skills(job_description, job_match)
        scored = score_workforce(candidate_selected, required, knowledge_base=self.knowledge_base, config=self.scoring_config)
        matched_required = [skill for skill in required if skill in {item["skill"] for item in candidate_selected}]
        missing = [skill for skill in required if skill not in matched_required]
        confidence_values = [float(item["numeric_confidence"]) for item in candidate_selected]
        return {
            "candidate_skills": [item["skill"] for item in candidate_selected],
            "matched_skills": matched_required,
            "missing_skills": missing,
            "skill_gaps": scored["skill_gaps"],
            "readiness_score": scored["readiness_score"],
            "career_paths": scored["career_paths"],
            "job_relevance": {
                "required_skills": required,
                "matched_skills": matched_required,
                "missing_skills": missing,
                "coverage": (len(matched_required) / len(required)) if required else 0.0,
            },
            "confidence": {
                "level": "high" if any(item["lexical_match"] for item in candidate_selected) else "medium" if candidate_selected else "low",
                "mean_numeric_confidence": sum(confidence_values) / len(confidence_values) if confidence_values else 0.0,
                "selection_threshold": self.selection_threshold,
            },
            "evidence": {
                "candidate_match": candidate_match,
                "job_match": job_match,
                "selected_candidate_matches": candidate_selected,
                "knowledge_source_type": self.knowledge_base.source_type,
            },
            "scoring_details": scored,
        }


def analyze_candidate(
    resume_text: str,
    job_description: str,
    skill_names: Sequence[str],
    skill_embedding_artifact: Optional[Path] = None,
    selection_threshold: float = 0.60,
) -> Dict[str, Any]:
    """Convenience API; callers needing repeated analyses should reuse WorkforcePipeline."""
    pipeline = WorkforcePipeline(skill_names, skill_embedding_artifact=skill_embedding_artifact, selection_threshold=selection_threshold)
    return pipeline.analyze_candidate(resume_text, job_description)
