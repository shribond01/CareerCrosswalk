"""Phase 5 hybrid lexical + E5 semantic skill matcher.

This module is intentionally independent of the frozen Phase 3/4 evaluation code.
It performs deterministic canonical-skill lexical matching and E5 semantic retrieval.
The 0.65/0.35 weights and confidence thresholds are initial heuristics, not tuned.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence

import numpy as np
from sentence_transformers import SentenceTransformer

MODEL_NAME = "intfloat/e5-base-v2"
LEXICAL_WEIGHT = 0.65
SEMANTIC_WEIGHT = 0.35
HIGH_CONFIDENCE_THRESHOLD = 0.60
MEDIUM_CONFIDENCE_THRESHOLD = 0.40

# Standard abbreviations/derivatives are accepted only when word-boundary safe.
# The matcher never emits a skill outside the supplied canonical catalog.
LEXICAL_ALIASES: Mapping[str, Sequence[str]] = {
    "Machine Learning": ("machine learning", "ml"),
    "Deep Learning": ("deep learning",),
    "Natural Language Processing": ("natural language processing", "nlp"),
    "Computer Vision": ("computer vision",),
    "Docker": ("docker", "dockerized", "docker compose"),
    "MLOps": ("mlops",),
}


def normalize_text(text: str) -> str:
    """Lowercase, normalize whitespace, and normalize non-breaking spaces."""
    return re.sub(r"\s+", " ", str(text).replace("\u00a0", " ").strip().lower())


def _alias_pattern(alias: str) -> re.Pattern[str]:
    normalized = normalize_text(alias)
    # A whitespace-normalized multi-word pattern with non-word guards avoids
    # matching substrings such as "pythonista" or "postgresqlite".
    body = re.escape(normalized).replace(r"\ ", r"\s+")
    return re.compile(rf"(?<!\w){body}(?!\w)", re.IGNORECASE)


def lexical_matches(text: str, skill_names: Sequence[str]) -> Dict[str, bool]:
    normalized = normalize_text(text)
    result: Dict[str, bool] = {}
    for skill in skill_names:
        aliases = LEXICAL_ALIASES.get(skill, (skill,))
        result[skill] = any(_alias_pattern(alias).search(normalized) is not None for alias in aliases)
    return result


def normalize_rows(matrix: np.ndarray) -> np.ndarray:
    arr = np.asarray(matrix, dtype=np.float32)
    norms = np.linalg.norm(arr, axis=1, keepdims=True)
    norms[norms == 0.0] = 1.0
    return arr / norms


@dataclass(frozen=True)
class MatcherConfig:
    model_name: str = MODEL_NAME
    lexical_weight: float = LEXICAL_WEIGHT
    semantic_weight: float = SEMANTIC_WEIGHT
    high_confidence_threshold: float = HIGH_CONFIDENCE_THRESHOLD
    medium_confidence_threshold: float = MEDIUM_CONFIDENCE_THRESHOLD
    top_k: int = 5

    def validate(self) -> None:
        if abs((self.lexical_weight + self.semantic_weight) - 1.0) > 1e-8:
            raise ValueError("lexical_weight + semantic_weight must equal 1.0")
        if not 0.0 <= self.medium_confidence_threshold <= self.high_confidence_threshold:
            raise ValueError("confidence thresholds must satisfy 0 <= medium <= high")
        if self.top_k < 1:
            raise ValueError("top_k must be at least 1")


class HybridSkillMatcher:
    """Reusable Phase 5 matcher. The E5 model is loaded once per instance."""

    def __init__(
        self,
        skill_names: Sequence[str],
        config: Optional[MatcherConfig] = None,
        model: Optional[SentenceTransformer] = None,
        skill_vectors: Optional[np.ndarray] = None,
        skill_embedding_artifact: Optional[Path] = None,
    ) -> None:
        self.config = config or MatcherConfig()
        self.config.validate()
        self.skill_names = list(skill_names)
        if not self.skill_names:
            raise ValueError("skill_names must not be empty")
        if len(set(self.skill_names)) != len(self.skill_names):
            raise ValueError("skill_names must be unique")
        self.model = model if model is not None else SentenceTransformer(self.config.model_name)
        self.skill_vectors = self._load_or_encode_skill_vectors(skill_vectors, skill_embedding_artifact)
        if self.skill_vectors.shape[0] != len(self.skill_names):
            raise ValueError("skill vector count does not match skill catalog")

    def _load_or_encode_skill_vectors(self, skill_vectors: Optional[np.ndarray], artifact: Optional[Path]) -> np.ndarray:
        if skill_vectors is not None:
            return normalize_rows(np.asarray(skill_vectors, dtype=np.float32))
        if artifact is not None and artifact.exists():
            with artifact.open("r", encoding="utf-8") as handle:
                payload = json.load(handle)
            if payload.get("model_name") != self.config.model_name or payload.get("skills") != self.skill_names:
                raise ValueError(f"Embedding artifact does not match model/catalog: {artifact}")
            return normalize_rows(np.asarray(payload["vectors"], dtype=np.float32))
        passages = [f"passage: {skill}" for skill in self.skill_names]
        encoded = self.model.encode(passages, normalize_embeddings=False, convert_to_numpy=True, show_progress_bar=False)
        return normalize_rows(np.asarray(encoded, dtype=np.float32))

    def _semantic_matrix(self, texts: Sequence[str]) -> np.ndarray:
        queries = [f"query: {normalize_text(text)}" for text in texts]
        vectors = self.model.encode(queries, normalize_embeddings=False, convert_to_numpy=True, show_progress_bar=False)
        return normalize_rows(np.asarray(vectors, dtype=np.float32)) @ self.skill_vectors.T

    def _confidence(self, lexical_match: bool, semantic_score: float) -> tuple[str, float]:
        if lexical_match:
            return "high", 1.0
        if semantic_score >= self.config.high_confidence_threshold:
            return "high", float(semantic_score)
        if semantic_score >= self.config.medium_confidence_threshold:
            return "medium", float(semantic_score)
        return "low", float(semantic_score)

    def match_many(self, texts: Sequence[str], top_k: Optional[int] = None) -> List[Dict[str, Any]]:
        if not texts:
            return []
        k = min(top_k or self.config.top_k, len(self.skill_names))
        semantic_matrix = self._semantic_matrix(texts)
        outputs: List[Dict[str, Any]] = []
        for row_text, semantic_scores in zip(texts, semantic_matrix):
            lexical = lexical_matches(row_text, self.skill_names)
            ranked: List[Dict[str, Any]] = []
            for idx in np.argsort(semantic_scores)[::-1]:
                skill = self.skill_names[int(idx)]
                semantic_score = float(semantic_scores[int(idx)])
                lexical_match = bool(lexical[skill])
                hybrid_score = self.config.lexical_weight * float(lexical_match) + self.config.semantic_weight * semantic_score
                confidence, numeric_confidence = self._confidence(lexical_match, semantic_score)
                ranked.append({
                    "skill": skill,
                    "lexical_match": lexical_match,
                    "lexical_score": 1.0 if lexical_match else 0.0,
                    "semantic_score": semantic_score,
                    "hybrid_score": float(hybrid_score),
                    "confidence": confidence,
                    "numeric_confidence": numeric_confidence,
                })
            hybrid_ranked = sorted(ranked, key=lambda item: (-item["hybrid_score"], item["skill"]))
            outputs.append({
                "input": row_text,
                "lexical_matches": [skill for skill in self.skill_names if lexical[skill]],
                "matches": hybrid_ranked[:k],
                "semantic_ranking": sorted(ranked, key=lambda item: (-item["semantic_score"], item["skill"]))[:k],
                "hybrid_ranking": hybrid_ranked[:k],
            })
        return outputs

    def match(self, evidence: str, top_k: Optional[int] = None) -> Dict[str, Any]:
        return self.match_many([evidence], top_k=top_k)[0]
