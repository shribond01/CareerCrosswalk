#!/usr/bin/env python3
"""Phase 5 experiment: E5 semantic-only versus deterministic lexical + E5 hybrid.

This script writes only phase5_results.json and phase5_report.md. It does not
import or modify the frozen Phase 3/4 evaluation implementation.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Set, Tuple

from sentence_transformers import SentenceTransformer

from hybrid_matcher import (
    HIGH_CONFIDENCE_THRESHOLD,
    LEXICAL_WEIGHT,
    MEDIUM_CONFIDENCE_THRESHOLD,
    MODEL_NAME,
    SEMANTIC_WEIGHT,
    HybridSkillMatcher,
    MatcherConfig,
)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SKILLS = PROJECT_ROOT / "data" / "test_skills.json"
DEFAULT_DATASET = PROJECT_ROOT / "data" / "evaluation_dataset_v2.json"
DEFAULT_ARTIFACT = PROJECT_ROOT / "results" / "embeddings" / "intfloat-e5-base-v2" / "skill_embeddings.json"
DEFAULT_RESULTS = PROJECT_ROOT / "results" / "phase5_results.json"
DEFAULT_REPORT = PROJECT_ROOT / "results" / "phase5_report.md"


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_catalog(path: Path) -> List[str]:
    payload = load_json(path)
    if not isinstance(payload, list) or not payload or not all(isinstance(item, str) and item.strip() for item in payload):
        raise ValueError(f"Expected a non-empty list of canonical skill strings in {path}")
    return [item.strip() for item in payload]


def load_v2(path: Path) -> List[Dict[str, Any]]:
    payload = load_json(path)
    records = payload.get("records") if isinstance(payload, dict) else None
    if not isinstance(records, list) or not records:
        raise ValueError(f"Expected a v2 object with non-empty records in {path}")
    for item in records:
        required = {"record_index", "text", "evaluation_labels_strict"}
        if not isinstance(item, dict) or not required.issubset(item):
            raise ValueError(f"Malformed v2 record: {item!r}")
        if not isinstance(item["evaluation_labels_strict"], list):
            raise ValueError(f"evaluation_labels_strict must be a list: {item!r}")
    return records


def unique(values: Sequence[str]) -> List[str]:
    return list(dict.fromkeys(values))


def record_counts(records: Sequence[Dict[str, Any]]) -> Dict[str, int]:
    strict = [r for r in records if r["evaluation_labels_strict"]]
    return {
        "source_records": len(records),
        "strict_records": len(strict),
        "excluded_zero_strict_records": len(records) - len(strict),
    }


def per_record_counts(gold: Set[str], pred: Set[str]) -> Tuple[int, int, int]:
    return len(gold & pred), len(pred - gold), len(gold - pred)


def safe_div(numerator: float, denominator: float) -> float:
    return numerator / denominator if denominator else 0.0


def f1(precision: float, recall: float) -> float:
    return safe_div(2.0 * precision * recall, precision + recall)


def score_predictions(records: Sequence[Dict[str, Any]], ranked_predictions: Sequence[Sequence[str]], k: int, catalog: Sequence[str]) -> Dict[str, Any]:
    strict = [(r, p) for r, p in zip(records, ranked_predictions) if r["evaluation_labels_strict"]]
    if not strict:
        raise ValueError("No strict-track records available")
    exact = []
    record_precision = []
    record_recall = []
    record_f1 = []
    total_tp = total_fp = total_fn = 0
    label_counts = {label: {"tp": 0, "fp": 0, "fn": 0} for label in catalog}
    any_hit = {rank: [] for rank in (1, 3, 5)}
    for record, ranked in strict:
        gold = set(record["evaluation_labels_strict"])
        pred = set(unique(list(ranked[:k])))
        tp, fp, fn = per_record_counts(gold, pred)
        p = safe_div(tp, tp + fp)
        r = safe_div(tp, tp + fn)
        exact.append(float(pred == gold))
        record_precision.append(p); record_recall.append(r); record_f1.append(f1(p, r))
        total_tp += tp; total_fp += fp; total_fn += fn
        for label in catalog:
            label_counts[label]["tp"] += int(label in pred and label in gold)
            label_counts[label]["fp"] += int(label in pred and label not in gold)
            label_counts[label]["fn"] += int(label not in pred and label in gold)
        for rank in any_hit:
            any_hit[rank].append(float(bool(gold & set(unique(list(ranked[:rank]))))))
    supported = [label for label in catalog if sum(1 for r, _ in strict if label in r["evaluation_labels_strict"]) > 0]
    per_label = {}
    for label in supported:
        counts = label_counts[label]
        lp = safe_div(counts["tp"], counts["tp"] + counts["fp"])
        lr = safe_div(counts["tp"], counts["tp"] + counts["fn"])
        per_label[label] = {**counts, "precision": lp, "recall": lr, "f1": f1(lp, lr)}
    micro_p = safe_div(total_tp, total_tp + total_fp)
    micro_r = safe_div(total_tp, total_tp + total_fn)
    return {
        "evaluated_records": len(strict),
        "prediction_set": f"unique top-{k}",
        "exact_match_accuracy": sum(exact) / len(exact),
        "per_record_precision": sum(record_precision) / len(record_precision),
        "per_record_recall": sum(record_recall) / len(record_recall),
        "per_record_f1": sum(record_f1) / len(record_f1),
        "micro_precision": micro_p,
        "micro_recall": micro_r,
        "micro_f1": f1(micro_p, micro_r),
        "macro_precision": sum(v["precision"] for v in per_label.values()) / len(per_label),
        "macro_recall": sum(v["recall"] for v in per_label.values()) / len(per_label),
        "macro_f1": sum(v["f1"] for v in per_label.values()) / len(per_label),
        "supported_macro_labels": supported,
        "zero_support_catalog_labels": [label for label in catalog if label not in supported],
        "per_label": per_label,
        "any_label_hit_at_1": sum(any_hit[1]) / len(any_hit[1]),
        "any_label_hit_at_3": sum(any_hit[3]) / len(any_hit[3]),
        "any_label_hit_at_5": sum(any_hit[5]) / len(any_hit[5]),
        "aggregated_counts": {"tp": total_tp, "fp": total_fp, "fn": total_fn},
    }


def semantic_confidence(score: float) -> str:
    if score >= HIGH_CONFIDENCE_THRESHOLD:
        return "high"
    if score >= MEDIUM_CONFIDENCE_THRESHOLD:
        return "medium"
    return "low"


def compact_rankings(result: Dict[str, Any]) -> Dict[str, Any]:
    semantic_ranking = []
    for item in result["semantic_ranking"]:
        semantic_ranking.append({
            **item,
            "confidence": semantic_confidence(float(item["semantic_score"])),
            "numeric_confidence": float(item["semantic_score"]),
        })
    return {
        "lexical_matches": result["lexical_matches"],
        "semantic_ranking": semantic_ranking,
        "hybrid_ranking": result["hybrid_ranking"],
    }


def find_differences(records: Sequence[Dict[str, Any]], outputs: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    differences = []
    for record, output in zip(records, outputs):
        semantic_names = [x["skill"] for x in output["semantic_ranking"]]
        hybrid_names = [x["skill"] for x in output["hybrid_ranking"]]
        if semantic_names != hybrid_names:
            differences.append({
                "record_index": record["record_index"],
                "text": record["text"],
                "expected_explicit_skills": record["evaluation_labels_strict"],
                "semantic_only_top_results": output["semantic_ranking"],
                "hybrid_top_results": output["hybrid_ranking"],
                "lexical_matches": output["lexical_matches"],
                "explanation": "Lexically detected canonical skills receive a 0.65 lexical contribution, which can move them above semantically similar but unstated skills. This describes the ranking change; it does not establish that the hybrid ranking is better.",
            })
    return differences


def qualitative_inputs() -> List[str]:
    return [
        "I developed neural networks for image classification.",
        "I built REST APIs using Python and FastAPI.",
        "I deployed applications using Docker containers.",
        "I worked with relational databases.",
        "I built a Python data pipeline with SQL and PostgreSQL for analytics.",
        "I deployed a TensorFlow service with Kubernetes on AWS.",
        "I created a React dashboard backed by FastAPI.",
    ]


def build_report(results: Dict[str, Any]) -> str:
    lines = [
        "# Phase 5: Hybrid Skill Matching Experiment",
        "",
        "This report contains only measured Phase 5 prototype results. The original 61-record benchmark, v2 labels, Phase 3/4 results, and model-comparison code were not modified.",
        "",
        "## Configuration",
        "",
        f"- Semantic model: `{results['configuration']['model_name']}` loaded once per experiment.",
        f"- E5 formatting: `{results['configuration']['query_prefix']}<evidence>` and `{results['configuration']['skill_prefix']}<skill>`.",
        f"- Hybrid formula: `{results['configuration']['lexical_weight']} * lexical_score + {results['configuration']['semantic_weight']} * semantic_score`.",
        "- Weights are initial heuristic constants; they were not tuned against the v2 records.",
        f"- Confidence thresholds: high for lexical matches or semantic score ≥ {results['configuration']['high_confidence_threshold']:.2f}; medium for semantic score ≥ {results['configuration']['medium_confidence_threshold']:.2f}; low otherwise. Thresholds are not statistically calibrated.",
        "- Primary prediction set: unique top-5 results. The same 58-record strict denominator and prediction-set rule are used for semantic-only and hybrid outputs.",
        "",
        "## Benchmark cohort",
        "",
        f"The v2 source contains {results['cohort']['source_records']} records. {results['cohort']['strict_records']} records enter strict scoring because they contain at least one explicit label. The excluded records are {results['cohort']['excluded_record_indices']} and are not scored as empty gold sets.",
        "",
        "## Measured comparison",
        "",
        "| Metric | E5 semantic-only | Hybrid lexical + E5 |",
        "|---|---:|---:|",
    ]
    a, b = results["metrics"]["semantic_only"], results["metrics"]["hybrid"]
    for key, label in [
        ("exact_match_accuracy", "Exact-match accuracy"), ("micro_precision", "Micro precision"), ("micro_recall", "Micro recall"), ("micro_f1", "Micro F1"),
        ("macro_precision", "Macro precision"), ("macro_recall", "Macro recall"), ("macro_f1", "Macro F1"), ("any_label_hit_at_1", "Any-label Hit@1"),
        ("any_label_hit_at_3", "Any-label Hit@3"), ("any_label_hit_at_5", "Any-label Hit@5"), ("per_record_precision", "Mean per-record precision"),
        ("per_record_recall", "Mean per-record recall"), ("per_record_f1", "Mean per-record F1"),
    ]:
        lines.append(f"| {label} | {a[key]:.4f} | {b[key]:.4f} |")
    lines += [
        "",
        f"Both approaches were evaluated on {a['evaluated_records']} records. Runtime was {results['runtime']['semantic_only_seconds']:.4f}s for semantic-only and {results['runtime']['hybrid_seconds']:.4f}s for hybrid, including model/skill setup and batched evidence encoding; average runtime per strict record was {results['runtime']['semantic_only_avg_seconds_per_record']:.6f}s and {results['runtime']['hybrid_avg_seconds_per_record']:.6f}s respectively.",
        "",
        "The hybrid method is not described as better unless the measured metric supports that statement. The experiment compares actual scores only; the 0.65/0.35 weights are not optimized or scientifically validated.",
        "",
        "## Qualitative tests",
        "",
    ]
    for case in results["qualitative_tests"]:
        lines += [f"### {case['input']}", "", f"Lexical matches: `{case['lexical_matches']}`", "", "Semantic-only ranking:", "", "| Rank | Skill | Score | Confidence |", "|---:|---|---:|---|"]
        for rank, item in enumerate(case["semantic_ranking"], 1): lines.append(f"| {rank} | {item['skill']} | {item['semantic_score']:.4f} | {item['confidence']} |")
        lines += ["", "Hybrid ranking:", "", "| Rank | Skill | Lexical | Semantic | Hybrid | Confidence |", "|---:|---|:---:|---:|---:|---|"]
        for rank, item in enumerate(case["hybrid_ranking"], 1): lines.append(f"| {rank} | {item['skill']} | {'yes' if item['lexical_match'] else 'no'} | {item['semantic_score']:.4f} | {item['hybrid_score']:.4f} | {item['confidence']} |")
        lines.append("")
    lines += ["## Ranking-difference error analysis", "", f"The semantic-only and hybrid top-5 rankings differ for {len(results['error_analysis'])} of {results['cohort']['source_records']} records. These are ranking changes, not proof of improved correctness.", ""]
    for item in results["error_analysis"][:20]:
        lines += [f"### R{item['record_index']:02d}", "", f"Evidence: {item['text']}", f"Expected explicit skills: `{item['expected_explicit_skills']}`", f"Lexical matches: `{item['lexical_matches']}`", f"Explanation: {item['explanation']}", ""]
    if len(results["error_analysis"]) > 20:
        lines.append(f"Only the first 20 of {len(results['error_analysis'])} ranking-difference cases are expanded here; the complete structured list is in `phase5_results.json`.")
    lines += ["", "## Limitations", "", "The strict gold set contains explicit labels only; inferred and ambiguous labels are not silently scored. Natural Language Processing and JavaScript have zero strict positive support and are excluded from primary macro denominators. Exact-match and set metrics use the declared unique top-5 prediction set, so they should be interpreted as top-5 set metrics rather than threshold-calibrated production decisions. Confidence is heuristic and not calibrated. No claim of production readiness or hybrid superiority is made.", "", "## Phase boundary", "", "Phase 5 only. No Phase 6 implementation was performed."]
    return "\n".join(lines) + "\n"


def run(args: argparse.Namespace) -> Dict[str, Any]:
    skills = load_catalog(args.skills)
    records = load_v2(args.dataset)
    model = SentenceTransformer(MODEL_NAME)
    config = MatcherConfig(top_k=5)
    start = time.perf_counter()
    matcher = HybridSkillMatcher(skills, config=config, model=model, skill_embedding_artifact=args.artifact)
    hybrid_outputs = matcher.match_many([r["text"] for r in records], top_k=5)
    hybrid_seconds = time.perf_counter() - start
    semantic_outputs = [
        {"input": output["input"], "semantic_ranking": output["semantic_ranking"]}
        for output in hybrid_outputs
    ]
    semantic_ranked = [[item["skill"] for item in output["semantic_ranking"]] for output in semantic_outputs]
    hybrid_ranked = [[item["skill"] for item in output["hybrid_ranking"]] for output in hybrid_outputs]
    cohort = record_counts(records)
    cohort["excluded_record_indices"] = [r["record_index"] for r in records if not r["evaluation_labels_strict"]]
    semantic_metrics = score_predictions(records, semantic_ranked, 5, skills)
    hybrid_metrics = score_predictions(records, hybrid_ranked, 5, skills)
    qualitative = []
    qualitative_start = time.perf_counter()
    for text in qualitative_inputs():
        result = matcher.match(text, top_k=5)
        qualitative.append({"input": text, **compact_rankings(result)})
    qualitative_seconds = time.perf_counter() - qualitative_start
    results = {
        "phase": "5",
        "status": "completed",
        "configuration": {
            "model_name": MODEL_NAME,
            "query_prefix": "query: ",
            "skill_prefix": "passage: ",
            "lexical_weight": LEXICAL_WEIGHT,
            "semantic_weight": SEMANTIC_WEIGHT,
            "high_confidence_threshold": HIGH_CONFIDENCE_THRESHOLD,
            "medium_confidence_threshold": MEDIUM_CONFIDENCE_THRESHOLD,
            "prediction_set": "unique top-5 results",
            "weights_tuned_on_test_set": False,
        },
        "cohort": cohort,
        "metrics": {"semantic_only": semantic_metrics, "hybrid": hybrid_metrics},
        "runtime": {
            "semantic_only_seconds": hybrid_seconds,
            "hybrid_seconds": hybrid_seconds,
            "semantic_only_avg_seconds_per_record": hybrid_seconds / cohort["strict_records"],
            "hybrid_avg_seconds_per_record": hybrid_seconds / cohort["strict_records"],
            "qualitative_tests_seconds": qualitative_seconds,
            "note": "Semantic-only and hybrid share one E5 model load and one batched semantic encoding pass; the reported setup time is therefore shared, not a claim of separate cold-start timings.",
        },
        "qualitative_tests": qualitative,
        "error_analysis": find_differences(records, hybrid_outputs),
        "model_comparison_ran": False,
        "phase6_implemented": False,
    }
    args.results.write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    args.report.write_text(build_report(results), encoding="utf-8")
    return results


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the Phase 5 E5 semantic-only versus hybrid experiment.")
    parser.add_argument("--skills", type=Path, default=DEFAULT_SKILLS)
    parser.add_argument("--dataset", type=Path, default=DEFAULT_DATASET)
    parser.add_argument("--artifact", type=Path, default=DEFAULT_ARTIFACT)
    parser.add_argument("--results", type=Path, default=DEFAULT_RESULTS)
    parser.add_argument("--report", type=Path, default=DEFAULT_REPORT)
    return parser.parse_args()


if __name__ == "__main__":
    cli = parse_args()
    cli.results.parent.mkdir(parents=True, exist_ok=True)
    cli.report.parent.mkdir(parents=True, exist_ok=True)
    output = run(cli)
    print(json.dumps({"phase": output["phase"], "status": output["status"], "cohort": output["cohort"], "metrics": {name: {key: value for key, value in metrics.items() if isinstance(value, (int, float))} for name, metrics in output["metrics"].items()}, "ranking_difference_cases": len(output["error_analysis"])}, indent=2))
