"""Transparent rule-based workforce readiness scorer for the WOS demo."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Mapping, Sequence

from knowledge_base import DevelopmentFixtureKnowledgeBase, get_default_knowledge_base


@dataclass(frozen=True)
class ScoringConfig:
    confidence_weights: Mapping[str, float] = None  # type: ignore[assignment]
    default_confidence: float = 0.50
    min_career_overlap: int = 1

    def __post_init__(self) -> None:
        if self.confidence_weights is None:
            object.__setattr__(self, "confidence_weights", {"high": 1.0, "medium": 0.70, "low": 0.40})
        if any(float(v) < 0.0 or float(v) > 1.0 for v in self.confidence_weights.values()):
            raise ValueError("confidence weights must be between 0 and 1")


def _confidence_value(item: Mapping[str, Any], config: ScoringConfig) -> float:
    confidence = str(item.get("confidence", "")).lower()
    return float(config.confidence_weights.get(confidence, config.default_confidence))


def _skill_evidence(item: Mapping[str, Any], config: ScoringConfig, kb: DevelopmentFixtureKnowledgeBase) -> Dict[str, Any]:
    skill = str(item["skill"])
    context = kb.get_skill_context(skill)
    confidence_value = _confidence_value(item, config)
    importance = float(context["importance"])
    return {
        "skill": skill,
        "confidence": item.get("confidence", "unknown"),
        "confidence_value": confidence_value,
        "semantic_score": float(item.get("semantic_score", 0.0)),
        "lexical_score": float(item.get("lexical_score", 0.0)),
        "hybrid_score": float(item.get("hybrid_score", 0.0)),
        "lexical_match": bool(item.get("lexical_match", False)),
        "importance": importance,
        "candidate_skill_score": confidence_value * importance,
        "context": context,
    }


def score_workforce(
    matched_skills: Sequence[Mapping[str, Any]],
    required_skills: Sequence[str],
    knowledge_base: DevelopmentFixtureKnowledgeBase | None = None,
    config: ScoringConfig | None = None,
) -> Dict[str, Any]:
    """Score a candidate against required canonical skills.

    `matched_skills` should be the selected matcher outputs, not every ranked
    candidate. All weights are transparent heuristics and are not validated.
    """
    kb = knowledge_base or get_default_knowledge_base()
    cfg = config or ScoringConfig()
    required = list(dict.fromkeys(str(skill) for skill in required_skills))
    evidence = [_skill_evidence(item, cfg, kb) for item in matched_skills]
    by_skill = {item["skill"]: item for item in evidence}
    detected = [item for item in evidence if item["skill"] in required]
    gaps = []
    for skill in required:
        if skill not in by_skill:
            context = kb.get_skill_context(skill)
            gaps.append({"skill": skill, "importance": float(context["importance"]), "reason": "required skill has no selected candidate evidence", "context": context})
    total_weight = sum(float(kb.get_skill_importance(skill)) for skill in required)
    matched_weight = sum(float(item["importance"]) * float(item["confidence_value"]) for item in detected)
    readiness = matched_weight / total_weight if total_weight else 0.0
    career_scores = defaultdict(lambda: {"overlap": 0, "weighted_overlap": 0.0, "skills": []})
    for item in detected:
        for occupation in item["context"]["related_occupations"]:
            career_scores[occupation]["overlap"] += 1
            career_scores[occupation]["weighted_overlap"] += item["candidate_skill_score"]
            career_scores[occupation]["skills"].append(item["skill"])
    career_paths = []
    for occupation, values in career_scores.items():
        if values["overlap"] >= cfg.min_career_overlap:
            career_paths.append({"occupation": occupation, **values, "source_type": kb.source_type})
    career_paths.sort(key=lambda item: (-item["weighted_overlap"], -item["overlap"], item["occupation"]))
    explanations = []
    for item in detected:
        explanations.append({"type": "matched_skill", "skill": item["skill"], "text": f"{item['skill']} contributes {item['candidate_skill_score']:.3f} from confidence × fixture importance.", "evidence": item})
    for gap in gaps:
        explanations.append({"type": "skill_gap", "skill": gap["skill"], "text": f"{gap['skill']} is required but has no selected candidate evidence.", "evidence": gap})
    return {
        "skills_detected": [item["skill"] for item in evidence],
        "skill_gaps": gaps,
        "readiness_score": float(readiness),
        "career_paths": career_paths[:5],
        "explanation_data": explanations,
        "matched_skill_evidence": evidence,
        "required_skills": required,
        "source_type": kb.source_type,
        "scoring_config": {"confidence_weights": dict(cfg.confidence_weights), "default_confidence": cfg.default_confidence, "weights_scientifically_validated": False},
    }
