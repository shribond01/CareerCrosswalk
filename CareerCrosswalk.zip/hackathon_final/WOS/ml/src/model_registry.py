#!/usr/bin/env python3
"""Registry of benchmarked sentence-embedding models and their formatting rules.

This module keeps the model comparison controlled and reproducible. The only intentional
configuration differences between models are the architecture/weights and any model-specific
input formatting required by the retrieval setup.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass(frozen=True)
class ModelSpec:
    model_name: str
    family: str
    embedding_dimension: int
    input_formatting_strategy: str
    query_prefix: str = ""
    skill_prefix: str = ""
    normalization_required: bool = True


MODEL_REGISTRY: Dict[str, ModelSpec] = {
    "all-MiniLM-L6-v2": ModelSpec(
        model_name="all-MiniLM-L6-v2",
        family="SentenceTransformer",
        embedding_dimension=384,
        input_formatting_strategy="plain text",
        query_prefix="",
        skill_prefix="",
        normalization_required=True,
    ),
    "intfloat/e5-base-v2": ModelSpec(
        model_name="intfloat/e5-base-v2",
        family="E5",
        embedding_dimension=768,
        input_formatting_strategy="E5 retrieval format",
        query_prefix="query: ",
        skill_prefix="passage: ",
        normalization_required=True,
    ),
    "BAAI/bge-base-en-v1.5": ModelSpec(
        model_name="BAAI/bge-base-en-v1.5",
        family="BGE",
        embedding_dimension=768,
        input_formatting_strategy="BGE retrieval format",
        query_prefix="Represent this sentence for searching relevant passages: ",
        skill_prefix="",
        normalization_required=True,
    ),
}


def get_model_spec(model_name: str) -> ModelSpec:
    if model_name not in MODEL_REGISTRY:
        raise KeyError(f"Unknown model registered: {model_name}")
    return MODEL_REGISTRY[model_name]


def model_names() -> List[str]:
    return list(MODEL_REGISTRY.keys())
