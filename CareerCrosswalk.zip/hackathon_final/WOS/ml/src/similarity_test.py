#!/usr/bin/env python3
"""Experiment-only semantic matching for canonical skills.

This script is intentionally separate from the model generation step. It reuses the
persisted skill embeddings when available and falls back to generating them only when
necessary. The goal is to compare an evidence sentence against the canonical skills
using cosine similarity and print the Top-K matches.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Iterable, List, Sequence, Tuple

import numpy as np
from sentence_transformers import SentenceTransformer

MODEL_NAME = "all-MiniLM-L6-v2"
DEFAULT_SKILLS_PATH = "data/test_skills.json"
DEFAULT_EMBEDDINGS_PATH = "embeddings/skill_embeddings.json"


def project_root() -> Path:
    """Return the project root so the script can be run from the ml directory."""
    return Path(__file__).resolve().parents[1]


def resolve_path(path_value: str) -> Path:
    """Resolve a path relative to the ML project root when needed."""
    path = Path(path_value)
    if not path.is_absolute():
        return project_root() / path
    return path


def load_skill_catalog(path: Path) -> List[str]:
    """Load canonical skill names from the JSON dataset."""
    try:
        with path.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
    except FileNotFoundError as exc:
        raise FileNotFoundError(f"Skill catalog not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Malformed JSON in {path}: {exc}") from exc

    if not isinstance(payload, list):
        raise ValueError(f"Expected a list of skill strings in {path}, got {type(payload).__name__}")

    skills: List[str] = []
    for item in payload:
        if isinstance(item, str):
            cleaned = item.strip()
            if cleaned:
                skills.append(cleaned)
        elif isinstance(item, dict):
            for key in ("skill", "name", "canonical_skill"):
                value = item.get(key)
                if isinstance(value, str):
                    cleaned = value.strip()
                    if cleaned:
                        skills.append(cleaned)
                    break
            else:
                raise ValueError(f"Unsupported skill object format: {item!r}")
        else:
            raise ValueError(f"Unsupported skill entry type: {type(item).__name__}: {item!r}")

    if not skills:
        raise ValueError(f"No valid skill names were found in {path}")

    return skills


def load_cached_embeddings(path: Path, expected_skills: Sequence[str]) -> tuple[List[str], np.ndarray]:
    """Load precomputed embeddings when they already exist and match the skill catalog."""
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except FileNotFoundError:
        raise
    except json.JSONDecodeError as exc:
        raise ValueError(f"Malformed JSON in {path}: {exc}") from exc

    if not isinstance(data, dict):
        raise ValueError(f"Expected an object payload in {path}")

    skills = data.get("skills")
    vectors = data.get("vectors")
    if not isinstance(skills, list) or not isinstance(vectors, list):
        raise ValueError(f"Embeddings file {path} is missing required 'skills' or 'vectors' fields")

    if len(skills) != len(expected_skills) or len(skills) != len(vectors):
        raise ValueError(
            f"Skill count mismatch: expected {len(expected_skills)} entries, found {len(skills)} skills and {len(vectors)} vectors"
        )

    if list(skills) != list(expected_skills):
        raise ValueError(
            f"Skill catalog mismatch: cached skills do not match the input catalog in {path}"
        )

    arr = np.asarray(vectors, dtype=np.float32)
    if arr.ndim != 2:
        raise ValueError(f"Embedding matrix must be 2D; received shape {arr.shape}")

    return list(skills), arr


def generate_embeddings_for_skills(skills: Sequence[str], model_name: str = MODEL_NAME) -> np.ndarray:
    """Generate embeddings for the skill catalog when the cached artifact is unavailable."""
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    try:
        import embed_skills  # type: ignore
    except ModuleNotFoundError as exc:
        raise RuntimeError("Could not import embed_skills.py. Ensure the script is run from the ml directory.") from exc

    model_data = embed_skills.generate_embeddings(skills, model_name=model_name)
    vectors = np.asarray(model_data["vectors"], dtype=np.float32)
    return vectors


def normalize_rows(matrix: np.ndarray) -> np.ndarray:
    """Normalize rows to unit length for cosine similarity."""
    matrix = np.asarray(matrix, dtype=np.float32)
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0.0] = 1.0
    return matrix / norms


def rank_skills_for_evidence(
    evidence: str,
    skills: Sequence[str],
    skill_vectors: np.ndarray,
    model_name: str = MODEL_NAME,
    top_k: int = 5,
) -> List[Tuple[int, str, float]]:
    """Encode evidence and rank all canonical skills by cosine similarity."""
    model = SentenceTransformer(model_name)
    evidence_vector = np.asarray(
        model.encode(
            [evidence],
            normalize_embeddings=True,
            convert_to_numpy=True,
            show_progress_bar=False,
        ),
        dtype=np.float32,
    )
    evidence_vector = evidence_vector.reshape(1, -1)

    normalized_skills = normalize_rows(skill_vectors)
    normalized_evidence = normalize_rows(evidence_vector)
    similarities = normalized_skills @ normalized_evidence.T
    scores = similarities[:, 0]

    ranked_indices = np.argsort(scores)[::-1]
    results: List[Tuple[int, str, float]] = []
    for rank, index in enumerate(ranked_indices[:top_k], start=1):
        results.append((rank, skills[int(index)], float(scores[int(index)])))
    return results


def print_ranked_results(evidence: str, results: Sequence[Tuple[int, str, float]]) -> None:
    """Pretty-print the matching output in a compact experiment format."""
    print(f"\nInput evidence: {evidence}")
    print("Rank | Canonical skill | Similarity")
    print("-----|----------------|-----------")
    for rank, skill, score in results:
        print(f"{rank:>4} | {skill:<16} | {score:.4f}")


def resolve_skills_and_vectors(skills_path: Path, embeddings_path: Path, model_name: str) -> tuple[List[str], np.ndarray]:
    """Prefer cached embeddings but generate a fresh copy only when needed."""
    skills = load_skill_catalog(skills_path)

    if embeddings_path.exists():
        try:
            cached_skills, cached_vectors = load_cached_embeddings(embeddings_path, skills)
            print(f"Using cached embeddings from {embeddings_path}")
            return cached_skills, cached_vectors
        except ValueError as exc:
            print(f"Cached embeddings invalid: {exc}", file=sys.stderr)

    print(f"Generating embeddings for {len(skills)} skills with {model_name}")
    vectors = generate_embeddings_for_skills(skills, model_name=model_name)
    return skills, vectors


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Semantic matching experiment using pretrained sentence-transformer embeddings.")
    parser.add_argument("--input", dest="evidence", help="Natural-language evidence sentence to match against canonical skills.")
    parser.add_argument("--skills", default=str(DEFAULT_SKILLS_PATH), help="Path to the canonical skill JSON file.")
    parser.add_argument("--embeddings", default=str(DEFAULT_EMBEDDINGS_PATH), help="Path to the persisted embedding artifact.")
    parser.add_argument("--model", default=MODEL_NAME, help="Sentence-transformer model name to use for encoding.")
    parser.add_argument("--top-k", type=int, default=5, help="Number of skill matches to display.")
    return parser.parse_args()


def default_test_cases() -> List[str]:
    return [
        "I developed neural networks for image classification.",
        "I built REST APIs using Python and FastAPI.",
        "I deployed applications using Docker containers.",
        "I worked with relational databases.",
    ]


def main() -> int:
    args = parse_args()
    skills_path = resolve_path(args.skills)
    embeddings_path = resolve_path(args.embeddings)

    try:
        skills, skill_vectors = resolve_skills_and_vectors(skills_path, embeddings_path, args.model)

        if args.evidence:
            evidence_cases = [args.evidence]
        else:
            evidence_cases = default_test_cases()

        for evidence in evidence_cases:
            results = rank_skills_for_evidence(
                evidence=evidence,
                skills=skills,
                skill_vectors=skill_vectors,
                model_name=args.model,
                top_k=args.top_k,
            )
            print_ranked_results(evidence=evidence, results=results)

        return 0
    except (FileNotFoundError, ValueError, RuntimeError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
