#!/usr/bin/env python3
"""Compare the baseline and stronger sentence embedding models under a controlled benchmark.

The experiment intentionally keeps the evaluation dataset, canonical skill catalog, retrieval
logic, and metric definitions fixed. The only intended differences between runs are the model
architecture/weights and the model-specific input formatting required by the retrieval setup.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from evaluate_model import evaluate_single_model
from model_registry import MODEL_REGISTRY, model_names

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = PROJECT_ROOT / "results"
EMBEDDINGS_DIR = RESULTS_DIR / "embeddings"
SUMMARY_PATH = RESULTS_DIR / "model_comparison_summary.json"
REPORT_PATH = RESULTS_DIR / "model_comparison_report.md"


def build_markdown_table(summary_rows: List[Dict[str, Any]]) -> str:
    headers = [
        "Model",
        "Family",
        "Dimension",
        "Top-1",
        "Top-3",
        "Top-5",
        "P@1",
        "P@3",
        "P@5",
        "R@1",
        "R@3",
        "R@5",
        "Avg Time/Record",
        "Formatting",
    ]
    rows = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]

    for row in summary_rows:
        rows.append(
            "| "
            + " | ".join(
                [
                    row["model_name"],
                    row["family"],
                    str(row["embedding_dimension"]),
                    f"{row['Top-1 accuracy']:.4f}",
                    f"{row['Top-3 accuracy']:.4f}",
                    f"{row['Top-5 accuracy']:.4f}",
                    f"{row['Precision@1']:.4f}",
                    f"{row['Precision@3']:.4f}",
                    f"{row['Precision@5']:.4f}",
                    f"{row['Recall@1']:.4f}",
                    f"{row['Recall@3']:.4f}",
                    f"{row['Recall@5']:.4f}",
                    f"{row['avg_inference_time_seconds_per_record']:.6f}s",
                    row["input_formatting_strategy"],
                ]
            )
            + " |"
        )

    return "\n".join(rows) + "\n"


def build_report(summary_rows: List[Dict[str, Any]]) -> str:
    lines = [
        "# Phase 4: WOS Model Comparison",
        "",
        "This report compares the baseline skill-matching model against two stronger sentence embedding models under the same evaluation dataset, canonical skill catalog, cosine retrieval procedure, and metric definitions.",
        "",
        build_markdown_table(summary_rows),
        "",
        "## Model-specific formatting",
        "",
    ]

    for row in summary_rows:
        lines.append(f"### {row['model_name']}")
        lines.append(f"- Family: {row['family']}")
        lines.append(f"- Dimension: {row['embedding_dimension']}")
        lines.append(f"- Formatting: {row['input_formatting_strategy']}")
        lines.append(f"- Query prefix: {row['query_prefix']!r}")
        lines.append(f"- Skill prefix: {row['skill_prefix']!r}")
        lines.append(f"- Normalization: {row['normalization_required']}")
        lines.append("")

    return "\n".join(lines)


def main() -> int:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    EMBEDDINGS_DIR.mkdir(parents=True, exist_ok=True)

    summary_rows: List[Dict[str, Any]] = []

    for model_name in model_names():
        spec = MODEL_REGISTRY[model_name]
        model_result = evaluate_single_model(model_name=model_name, embeddings_root=EMBEDDINGS_DIR)
        summary_rows.append(model_result)

    with SUMMARY_PATH.open("w", encoding="utf-8") as handle:
        json.dump(summary_rows, handle, indent=2)
        handle.write("\n")

    report_text = build_report(summary_rows)
    REPORT_PATH.write_text(report_text, encoding="utf-8")

    print(build_markdown_table(summary_rows))
    print("\nSummary saved to:", SUMMARY_PATH)
    print("Report saved to:", REPORT_PATH)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
