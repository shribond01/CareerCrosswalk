#!/usr/bin/env python3
"""Evaluate a single sentence-embedding model on the WOS skill-matching benchmark.

This module is intentionally experiment-focused. It keeps the evaluation dataset, canonical
skill catalog, cosine retrieval procedure, and metric definitions fixed while only varying
model architecture and any model-specific input formatting needed by the embedding model.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np
from sentence_transformers import SentenceTransformer

from model_registry import ModelSpec, get_model_spec


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SKILLS_PATH = PROJECT_ROOT / "data" / "test_skills.json"
DEFAULT_DATASET_PATH = PROJECT_ROOT / "data" / "evaluation_dataset.json"
DEFAULT_EMBEDDINGS_ROOT = PROJECT_ROOT / "results" / "embeddings"


def resolve_path(path_value: str | Path) -> Path:
    path = Path(path_value)
    if not path.is_absolute():
        return PROJECT_ROOT / path
    return path


def safe_name(model_name: str) -> str:
    return model_name.replace("/", "-")


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_skill_catalog(path: Path) -> List[str]:
    payload = load_json(path)
    if not isinstance(payload, list):
        raise ValueError(f"Expected a list of skills in {path}")

    skills: List[str] = []
    for item in payload:
        if isinstance(item, str):
            cleaned = item.strip()
            if cleaned:
                skills.append(cleaned)
        elif isinstance(item, dict):
            for key in ("skill", "name", "canonical_skill"):
                value = item.get(key)
                if isinstance(value, str):
                    cleaned = value.strip()
                    if cleaned:
                        skills.append(cleaned)
                    break
            else:
                raise ValueError(f"Unsupported skill record: {item!r}")
        else:
            raise ValueError(f"Unsupported skill entry: {item!r}")

    if not skills:
        raise ValueError(f"No valid skills found in {path}")
    return skills


def load_evaluation_dataset(path: Path) -> List[Dict[str, Any]]:
    payload = load_json(path)
    if not isinstance(payload, list):
        raise ValueError(f"Expected a list of evaluation records in {path}")
    return payload


def format_text_for_model(text: str, role: str, spec: ModelSpec) -> str:
    if role == "query":
        prefix = spec.query_prefix
    elif role == "skill":
        prefix = spec.skill_prefix
    else:
        raise ValueError(f"Unsupported role: {role}")

    if not prefix:
        return text.strip()
    return f"{prefix}{text.strip()}"


def normalize_rows(matrix: np.ndarray) -> np.ndarray:
    matrix = np.asarray(matrix, dtype=np.float32)
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0.0] = 1.0
    return matrix / norms


def encode_texts(model: SentenceTransformer, texts: Sequence[str], role: str, spec: ModelSpec) -> np.ndarray:
    formatted = [format_text_for_model(text, role, spec) for text in texts]
    vectors = model.encode(
        formatted,
        normalize_embeddings=False,
        convert_to_numpy=True,
        show_progress_bar=False,
    )
    return np.asarray(vectors, dtype=np.float32)


def save_skill_embedding_artifact(model_name: str, spec: ModelSpec, skill_names: Sequence[str], skill_vectors: np.ndarray, output_dir: Path) -> Path:
    artifact_dir = output_dir / safe_name(model_name)
    artifact_dir.mkdir(parents=True, exist_ok=True)
    artifact_path = artifact_dir / "skill_embeddings.json"

    payload = {
        "model_name": model_name,
        "family": spec.family,
        "embedding_dimension": int(skill_vectors.shape[1]),
        "input_formatting_strategy": spec.input_formatting_strategy,
        "query_prefix": spec.query_prefix,
        "skill_prefix": spec.skill_prefix,
        "normalization_required": spec.normalization_required,
        "skills": list(skill_names),
        "vectors": skill_vectors.tolist(),
    }
    with artifact_path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")
    return artifact_path


def precision_recall_at_k(predictions: Sequence[Sequence[str]], expected: Sequence[Sequence[str]], k: int) -> Tuple[float, float]:
    precisions: List[float] = []
    recalls: List[float] = []

    for pred_list, exp_list in zip(predictions, expected):
        exp_set = set(exp_list)
        if not exp_set:
            continue
        top_k_preds = set(pred_list[:k])
        hits = exp_set & top_k_preds
        precision = len(hits) / max(len(top_k_preds), 1)
        recall = len(hits) / max(len(exp_set), 1)
        precisions.append(precision)
        recalls.append(recall)

    return float(np.mean(precisions)) if precisions else 0.0, float(np.mean(recalls)) if recalls else 0.0


def top_k_accuracy(predictions: Sequence[Sequence[str]], expected: Sequence[Sequence[str]], k: int) -> float:
    correct = 0
    for pred_list, exp_list in zip(predictions, expected):
        exp_set = set(exp_list)
        if not exp_set:
            continue
        if exp_set & set(pred_list[:k]):
            correct += 1
    return correct / max(len(expected), 1)


def rank_skills_for_text(
    evidence: str,
    skill_names: Sequence[str],
    skill_vectors: np.ndarray,
    model: SentenceTransformer,
    spec: ModelSpec,
    top_k: int = 5,
) -> List[Tuple[int, str, float]]:
    evidence_emb = encode_texts(model, [evidence], "query", spec)
    evidence_vector = evidence_emb.reshape(1, -1)
    normalized_skills = normalize_rows(skill_vectors)
    normalized_evidence = normalize_rows(evidence_vector)

    similarities = normalized_skills @ normalized_evidence.T
    scores = similarities[:, 0]
    ranked_indices = np.argsort(scores)[::-1]

    results: List[Tuple[int, str, float]] = []
    for rank, idx in enumerate(ranked_indices[:top_k], start=1):
        results.append((rank, skill_names[int(idx)], float(scores[int(idx)])))
    return results


def evaluate_single_model(
    model_name: str,
    skill_path: Path = DEFAULT_SKILLS_PATH,
    dataset_path: Path = DEFAULT_DATASET_PATH,
    embeddings_root: Path = DEFAULT_EMBEDDINGS_ROOT,
) -> Dict[str, Any]:
    spec = get_model_spec(model_name)
    skill_names = load_skill_catalog(skill_path)
    dataset = load_evaluation_dataset(dataset_path)

    model = SentenceTransformer(model_name)
    detected_dim = int(model.get_sentence_embedding_dimension())
    if detected_dim != spec.embedding_dimension:
        raise ValueError(
            f"Model dimension mismatch for {model_name}: expected {spec.embedding_dimension}, got {detected_dim}"
        )

    start = time.perf_counter()
    skill_texts = [format_text_for_model(skill, "skill", spec) for skill in skill_names]
    skill_vectors = np.asarray(
        model.encode(
            skill_texts,
            normalize_embeddings=False,
            convert_to_numpy=True,
            show_progress_bar=False,
        ),
        dtype=np.float32,
    )
    skill_encode_time = time.perf_counter() - start

    artifact_path = save_skill_embedding_artifact(model_name, spec, skill_names, skill_vectors, embeddings_root)

    evidence_texts = [str(item["text"]).strip() for item in dataset if str(item.get("text", "")).strip()]
    evidence_start = time.perf_counter()
    evidence_vectors = encode_texts(model, evidence_texts, "query", spec)
    evidence_time = time.perf_counter() - evidence_start

    predictions: List[List[str]] = []
    expected_lists: List[List[str]] = []
    failure_examples: List[Dict[str, Any]] = []

    for item in dataset:
        text = str(item.get("text", "")).strip()
        expected = item.get("expected", [])
        if not text:
            continue
        if not isinstance(expected, list):
            raise ValueError(f"Expected field must be a list in evaluation record: {item!r}")

        ranked = rank_skills_for_text(text, skill_names, skill_vectors, model, spec, top_k=5)
        ranked_names = [skill for _, skill, _ in ranked]
        predictions.append(ranked_names)
        expected_lists.append([str(skill).strip() for skill in expected if str(skill).strip()])

        if not set(expected_lists[-1]).intersection(ranked_names[:1]):
            failure_examples.append(
                {
                    "text": text,
                    "expected": expected_lists[-1],
                    "top_5_predictions": ranked_names,
                    "top_5_scores": [float(score) for _, _, score in ranked],
                }
            )

    top1 = top_k_accuracy(predictions, expected_lists, 1)
    top3 = top_k_accuracy(predictions, expected_lists, 3)
    top5 = top_k_accuracy(predictions, expected_lists, 5)
    p1, r1 = precision_recall_at_k(predictions, expected_lists, 1)
    p3, r3 = precision_recall_at_k(predictions, expected_lists, 3)
    p5, r5 = precision_recall_at_k(predictions, expected_lists, 5)

    total_time = skill_encode_time + evidence_time
    avg_time_per_record = total_time / max(len(dataset), 1)

    summary = {
        "model_name": model_name,
        "family": spec.family,
        "embedding_dimension": int(skill_vectors.shape[1]),
        "input_formatting_strategy": spec.input_formatting_strategy,
        "query_prefix": spec.query_prefix,
        "skill_prefix": spec.skill_prefix,
        "normalization_required": spec.normalization_required,
        "total_records": len(dataset),
        "Top-1 accuracy": top1,
        "Top-3 accuracy": top3,
        "Top-5 accuracy": top5,
        "Precision@1": p1,
        "Precision@3": p3,
        "Precision@5": p5,
        "Recall@1": r1,
        "Recall@3": r3,
        "Recall@5": r5,
        "total_inference_time_seconds": total_time,
        "avg_inference_time_seconds_per_record": avg_time_per_record,
        "artifact_path": str(artifact_path),
        "top1_failure_examples": failure_examples,
    }
    return summary
