#!/usr/bin/env python3
"""Evaluation-only experiment for the WOS semantic skill-matching baseline.

This script measures how well the pretrained all-MiniLM-L6-v2 baseline matches
natural-language technical evidence sentences against the canonical skill catalog.
It is intentionally separate from production embedding generation and matching code.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
from sentence_transformers import SentenceTransformer

MODEL_NAME = "all-MiniLM-L6-v2"
DEFAULT_SKILLS_PATH = "data/test_skills.json"
DEFAULT_EMBEDDINGS_PATH = "embeddings/skill_embeddings.json"
DEFAULT_DATASET_PATH = "data/evaluation_dataset.json"


def project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def resolve_path(path_value: str) -> Path:
    path = Path(path_value)
    if not path.is_absolute():
        return project_root() / path
    return path


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_skill_catalog(path: Path) -> List[str]:
    payload = load_json(path)
    if not isinstance(payload, list):
        raise ValueError(f"Expected a list of skills in {path}")

    skills: List[str] = []
    for item in payload:
        if isinstance(item, str):
            cleaned = item.strip()
            if cleaned:
                skills.append(cleaned)
        elif isinstance(item, dict):
            for key in ("skill", "name", "canonical_skill"):
                value = item.get(key)
                if isinstance(value, str):
                    cleaned = value.strip()
                    if cleaned:
                        skills.append(cleaned)
                    break
            else:
                raise ValueError(f"Unsupported skill record: {item!r}")
        else:
            raise ValueError(f"Unsupported skill entry: {item!r}")

    if not skills:
        raise ValueError(f"No valid skills found in {path}")
    return skills


def load_cached_embeddings(path: Path, expected_skills: Sequence[str]) -> Tuple[List[str], np.ndarray]:
    data = load_json(path)
    skills = data.get("skills")
    vectors = data.get("vectors")
    if not isinstance(skills, list) or not isinstance(vectors, list):
        raise ValueError(f"Embedding file {path} is missing 'skills' or 'vectors'")

    if len(skills) != len(expected_skills) or len(skills) != len(vectors):
        raise ValueError(
            f"Skill count mismatch: expected {len(expected_skills)}, got {len(skills)} skills and {len(vectors)} vectors"
        )

    if list(skills) != list(expected_skills):
        raise ValueError(f"Cached skills do not match the input skill catalog in {path}")

    matrix = np.asarray(vectors, dtype=np.float32)
    if matrix.ndim != 2:
        raise ValueError(f"Embedding matrix must be 2D; got shape {matrix.shape}")

    return list(skills), matrix


def normalize_rows(matrix: np.ndarray) -> np.ndarray:
    matrix = np.asarray(matrix, dtype=np.float32)
    norms = np.linalg.norm(matrix, axis=1, keepdims=True)
    norms[norms == 0.0] = 1.0
    return matrix / norms


def encode_texts(texts: Sequence[str], model_name: str = MODEL_NAME) -> np.ndarray:
    model = SentenceTransformer(model_name)
    vectors = model.encode(
        list(texts),
        normalize_embeddings=True,
        convert_to_numpy=True,
        show_progress_bar=False,
    )
    return np.asarray(vectors, dtype=np.float32)


def rank_skills_for_text(
    evidence: str,
    skill_names: Sequence[str],
    skill_vectors: np.ndarray,
    model: SentenceTransformer,
    top_k: int = 5,
) -> List[Tuple[int, str, float]]:
    evidence_vector = np.asarray(
        model.encode(
            [evidence],
            normalize_embeddings=True,
            convert_to_numpy=True,
            show_progress_bar=False,
        ),
        dtype=np.float32,
    ).reshape(1, -1)

    normalized_skills = normalize_rows(skill_vectors)
    normalized_evidence = normalize_rows(evidence_vector)
    similarities = normalized_skills @ normalized_evidence.T
    scores = similarities[:, 0]
    ranked_indices = np.argsort(scores)[::-1]

    output: List[Tuple[int, str, float]] = []
    for rank, idx in enumerate(ranked_indices[:top_k], start=1):
        output.append((rank, skill_names[int(idx)], float(scores[int(idx)])))
    return output


def top_k_accuracy(predictions: Sequence[Sequence[str]], expected: Sequence[Sequence[str]], k: int) -> float:
    correct = 0
    for pred_list, exp_list in zip(predictions, expected):
        exp_set = set(exp_list)
        if not exp_set:
            continue
        top_k_preds = set(pred_list[:k])
        if exp_set & top_k_preds:
            correct += 1
    return correct / max(len(expected), 1)


def precision_recall_at_k(predictions: Sequence[Sequence[str]], expected: Sequence[Sequence[str]], k: int) -> Tuple[float, float]:
    precisions: List[float] = []
    recalls: List[float] = []

    for pred_list, exp_list in zip(predictions, expected):
        exp_set = set(exp_list)
        if not exp_set:
            continue
        top_k_preds = set(pred_list[:k])
        hits = exp_set & top_k_preds
        precision = len(hits) / max(len(top_k_preds), 1)
        recall = len(hits) / max(len(exp_set), 1)
        precisions.append(precision)
        recalls.append(recall)

    precision_avg = float(np.mean(precisions)) if precisions else 0.0
    recall_avg = float(np.mean(recalls)) if recalls else 0.0
    return precision_avg, recall_avg


def collect_predictions(
    records: Sequence[dict],
    skill_names: Sequence[str],
    skill_vectors: np.ndarray,
    model: SentenceTransformer,
) -> Tuple[List[List[str]], List[List[str]], List[Tuple[str, List[Tuple[int, str, float]], List[str]]]]:
    predictions: List[List[str]] = []
    expected_lists: List[List[str]] = []
    failures: List[Tuple[str, List[Tuple[int, str, float]], List[str]]] = []

    for item in records:
        text = str(item.get("text", "")).strip()
        expected = item.get("expected", [])
        if not text:
            continue
        if not isinstance(expected, list):
            raise ValueError(f"Expected field must be a list in evaluation record: {item!r}")

        ranked = rank_skills_for_text(text, skill_names, skill_vectors, model=model, top_k=5)
        ranked_names = [skill for _, skill, _ in ranked]
        predictions.append(ranked_names)
        expected_lists.append([str(skill).strip() for skill in expected if str(skill).strip()])

        expected_set = set(expected_lists[-1])
        top1_prediction = ranked_names[:1]
        if not expected_set.intersection(top1_prediction):
            failures.append((text, ranked, expected_lists[-1]))

    return predictions, expected_lists, failures


def print_summary(results: Dict[str, float]) -> None:
    print("Evaluation summary")
    print("------------------")
    for metric_name, metric_value in results.items():
        print(f"{metric_name}: {metric_value:.4f}")


def print_failure_examples(failures: Sequence[Tuple[str, List[Tuple[int, str, float]], List[str]]], limit: int = 10) -> None:
    print("\nTop-1 failure examples (manual inspection)")
    print("-----------------------------------------")
    for idx, (text, ranked, expected) in enumerate(failures[:limit], start=1):
        print(f"\nExample {idx}: {text}")
        print(f"Expected: {expected}")
        print("Top-5 predicted:")
        for rank, skill, score in ranked:
            print(f"  {rank}. {skill} ({score:.4f})")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate the all-MiniLM-L6-v2 semantic skill-matching baseline on a technical evidence dataset.")
    parser.add_argument("--skills", default=str(DEFAULT_SKILLS_PATH), help="Path to the canonical skill catalog JSON.")
    parser.add_argument("--embeddings", default=str(DEFAULT_EMBEDDINGS_PATH), help="Path to the cached embedding artifact.")
    parser.add_argument("--dataset", default=str(DEFAULT_DATASET_PATH), help="Path to the evaluation dataset JSON.")
    parser.add_argument("--model", default=MODEL_NAME, help="Sentence-transformer model to use.")
    parser.add_argument("--max-failures", type=int, default=10, help="Number of incorrect predictions to display for manual review.")
    parser.add_argument("--seed", type=int, default=42, help="Seed for reproducible ordering or randomization.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    np.random.seed(args.seed)

    skills_path = resolve_path(args.skills)
    embeddings_path = resolve_path(args.embeddings)
    dataset_path = resolve_path(args.dataset)

    try:
        skill_names = load_skill_catalog(skills_path)
        cached_skills, skill_vectors = load_cached_embeddings(embeddings_path, skill_names)
        if cached_skills != skill_names:
            raise ValueError("Cached skill ordering does not match the canonical skill catalog")

        model = SentenceTransformer(args.model)

        dataset = load_json(dataset_path)
        if not isinstance(dataset, list):
            raise ValueError(f"Expected a list of evaluation records in {dataset_path}")

        predictions, expected, failures = collect_predictions(dataset, skill_names, skill_vectors, model)

        top1 = top_k_accuracy(predictions, expected, 1)
        top3 = top_k_accuracy(predictions, expected, 3)
        top5 = top_k_accuracy(predictions, expected, 5)

        p_at_1, r_at_1 = precision_recall_at_k(predictions, expected, 1)
        p_at_3, r_at_3 = precision_recall_at_k(predictions, expected, 3)
        p_at_5, r_at_5 = precision_recall_at_k(predictions, expected, 5)

        summary = {
            "Top-1 accuracy": top1,
            "Top-3 accuracy": top3,
            "Top-5 accuracy": top5,
            "Precision@1": p_at_1,
            "Recall@1": r_at_1,
            "Precision@3": p_at_3,
            "Recall@3": r_at_3,
            "Precision@5": p_at_5,
            "Recall@5": r_at_5,
        }

        print(f"Evaluation dataset: {dataset_path}")
        print(f"Skill catalog: {skills_path}")
        print(f"Embedding artifact: {embeddings_path}")
        print(f"Model: {args.model}")
        print(f"Records: {len(dataset)}")
        print_summary(summary)
        print_failure_examples(failures, limit=args.max_failures)
        return 0
    except (FileNotFoundError, ValueError, json.JSONDecodeError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    import sys

    raise SystemExit(main())
