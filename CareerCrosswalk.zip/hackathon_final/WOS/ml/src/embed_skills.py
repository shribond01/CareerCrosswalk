#!/usr/bin/env python3
"""Create and persist sentence-transformer embeddings for canonical skill names.

This phase is intentionally limited to the baseline semantic skill embedding layer.
It loads a small development skill catalog, encodes the skills with the pretrained
all-MiniLM-L6-v2 model, and saves the embeddings to disk for later matching tasks.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Iterable, List

import numpy as np
from sentence_transformers import SentenceTransformer

DEFAULT_MODEL = "all-MiniLM-L6-v2"
DEFAULT_INPUT = "data/test_skills.json"
DEFAULT_OUTPUT = "embeddings/skill_embeddings.json"


def project_root() -> Path:
    """Return the ML project root, independent of the current working directory."""
    return Path(__file__).resolve().parents[1]


def resolve_path(path_value: str) -> Path:
    """Resolve a path from the project root when the input is relative."""
    path = Path(path_value)
    if not path.is_absolute():
        path = project_root() / path
    return path


def load_skill_catalog(path: Path) -> List[str]:
    """Load a canonical skill catalog from JSON.

    Supports a simple list of strings, and a list of objects with common naming keys
    such as skill, name, or canonical_skill.
    """
    try:
        with path.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)
    except FileNotFoundError as exc:
        raise FileNotFoundError(f"Skill catalog not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Malformed JSON in {path}: {exc}") from exc

    if not isinstance(payload, list):
        raise ValueError(f"Expected a JSON list of skills in {path}, got {type(payload).__name__}")

    skills: List[str] = []
    for item in payload:
        if isinstance(item, str):
            cleaned = item.strip()
            if cleaned:
                skills.append(cleaned)
        elif isinstance(item, dict):
            for key in ("skill", "name", "canonical_skill"):
                value = item.get(key)
                if isinstance(value, str):
                    cleaned = value.strip()
                    if cleaned:
                        skills.append(cleaned)
                    break
            else:
                raise ValueError(f"Unsupported skill object format: {item!r}")
        else:
            raise ValueError(f"Unsupported skill entry type: {type(item).__name__} ({item!r})")

    if not skills:
        raise ValueError(f"No valid skill names were found in {path}")

    return skills


def generate_embeddings(skills: Iterable[str], model_name: str = DEFAULT_MODEL) -> dict:
    """Encode a set of skill names into dense semantic vectors."""
    skill_list = list(skills)
    model = SentenceTransformer(model_name)
    vectors = model.encode(
        skill_list,
        normalize_embeddings=False,
        convert_to_numpy=True,
        show_progress_bar=False,
    )
    vectors = np.asarray(vectors, dtype=np.float32)

    if vectors.ndim != 2:
        raise ValueError(f"Embedding output must be 2D; received shape {vectors.shape}")

    return {
        "model_name": model_name,
        "embedding_dimension": int(vectors.shape[1]),
        "skills": skill_list,
        "vectors": vectors.tolist(),
    }


def save_embeddings(embeddings: dict, output_path: Path) -> None:
    """Persist the embedding artifact locally."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as handle:
        json.dump(embeddings, handle, indent=2)
        handle.write("\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate canonical skill embeddings using a pretrained sentence-transformer model.")
    parser.add_argument(
        "--input",
        default=DEFAULT_INPUT,
        help="Path to the JSON file containing canonical skill names.",
    )
    parser.add_argument(
        "--output",
        default=DEFAULT_OUTPUT,
        help="Path where the embeddings JSON artifact will be written.",
    )
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help="Sentence-transformer model name to use for embeddings.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    input_path = resolve_path(args.input)
    output_path = resolve_path(args.output)

    try:
        skills = load_skill_catalog(input_path)
        embeddings = generate_embeddings(skills, model_name=args.model)
        save_embeddings(embeddings, output_path)
    except (FileNotFoundError, ValueError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    print(f"Loaded {len(skills)} skills from {input_path}")
    print(f"Model: {args.model}")
    print(f"Embedding dimension: {embeddings['embedding_dimension']}")
    print(f"Saved embeddings to {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
