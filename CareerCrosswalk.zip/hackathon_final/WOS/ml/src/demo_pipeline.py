#!/usr/bin/env python3
"""Run one realistic WOS workforce-intelligence demo."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from workforce_pipeline import WorkforcePipeline

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SKILLS = ROOT / "data" / "test_skills.json"
DEFAULT_ARTIFACT = ROOT / "results" / "embeddings" / "intfloat-e5-base-v2" / "skill_embeddings.json"
DEFAULT_JSON = ROOT / "results" / "end_to_end_demo.json"
DEFAULT_MD = ROOT / "results" / "end_to_end_demo.md"

CANDIDATE = """Python developer with experience building FastAPI services, packaging applications with Docker, and applying Machine Learning models to product data."""
JOB = """Machine Learning Engineer requiring Python, Machine Learning, Docker, TensorFlow, and Kubernetes for production model services."""


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the WOS end-to-end workforce intelligence demo.")
    parser.add_argument("--skills", type=Path, default=DEFAULT_SKILLS)
    parser.add_argument("--artifact", type=Path, default=DEFAULT_ARTIFACT)
    parser.add_argument("--output-json", type=Path, default=DEFAULT_JSON)
    parser.add_argument("--output-md", type=Path, default=DEFAULT_MD)
    args = parser.parse_args()
    with args.skills.open("r", encoding="utf-8") as handle:
        skills = json.load(handle)
    pipeline = WorkforcePipeline(skills, skill_embedding_artifact=args.artifact, selection_threshold=0.60)
    result = pipeline.analyze_candidate(CANDIDATE, JOB)
    payload = {"phase": "6-8", "status": "completed", "knowledge_source_type": "development_fixture_not_official_onet", "inputs": {"candidate": CANDIDATE, "job_description": JOB}, "result": result}
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    paths = ", ".join(item["occupation"] for item in result["career_paths"]) or "No fixture career path surfaced"
    md = f"""# WOS End-to-End Workforce Intelligence Demo

**Status:** completed. This is a Phase 6–8 ML intelligence-layer demo only; Phase 9+ work was not performed.

> Knowledge source: `development_fixture_not_official_onet`. No official O*NET dataset/API configuration was available in the workspace. The fixture is derived from the canonical skill catalog and must not be presented as external labor-market data.

## Inputs

**Candidate:** {CANDIDATE}

**Job description:** {JOB}

## Output

| Field | Value |
|---|---|
| Candidate skills | {", ".join(result["candidate_skills"]) or "None"} |
| Matched required skills | {", ".join(result["matched_skills"]) or "None"} |
| Missing skills | {", ".join(result["missing_skills"]) or "None"} |
| Job relevance coverage | {result["job_relevance"]["coverage"]:.1%} |
| Readiness score | {result["readiness_score"]:.3f} ({result["readiness_score"]:.1%}) |
| Recommended career path | {paths} |
| Overall confidence | {result["confidence"]["level"]} |

## Evidence and confidence

"""
    for item in result["scoring_details"]["matched_skill_evidence"]:
        md += f"- **{item['skill']}**: lexical={item['lexical_score']:.1f}, semantic={item['semantic_score']:.3f}, hybrid={item['hybrid_score']:.3f}, confidence={item['confidence']}, fixture importance={item['importance']:.2f}.\n"
    md += "\n## Skill gaps\n\n"
    for gap in result["skill_gaps"]:
        md += f"- **{gap['skill']}**: required skill has no selected candidate evidence; fixture importance={gap['importance']:.2f}.\n"
    md += "\n## Limitations\n\nReadiness weights are transparent heuristics and are not scientifically validated. The knowledge base is a development fixture, not official O*NET data. No external market data, job scraping, feedback learning, LLM, or fine-tuning was used.\n"
    args.output_md.write_text(md, encoding="utf-8")
    print(json.dumps({"status": "completed", "readiness_score": result["readiness_score"], "matched_skills": result["matched_skills"], "missing_skills": result["missing_skills"], "career_paths": result["career_paths"][:3], "knowledge_source_type": payload["knowledge_source_type"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
