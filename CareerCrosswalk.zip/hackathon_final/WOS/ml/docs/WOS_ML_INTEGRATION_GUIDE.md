# WOS ML Integration Guide

## Scope

This guide documents the reconstructed WOS ML intelligence layer in `C:\innovation arena\WOS\ml`. It covers the benchmark audit and scoring protocol from Phase 4.5, the deterministic lexical plus E5 semantic matcher from Phase 5, and the development-time knowledge, scoring, and end-to-end pipeline layers from Phases 6–8.

The existing Phase 1–4 implementation remains the baseline. The original benchmark datasets, embedding artifacts, model-comparison code, and Phase 3/4 results are treated as frozen inputs. This reconstruction does not add Phase 9+ functionality, feedback learning, fine-tuning, scraping, an LLM, Qdrant, PostgreSQL, FastAPI, or a frontend.

## Workspace map

| Area | Artifact | Role |
|---|---|---|
| Phase 1–4 source | `src/embed_skills.py`, `src/similarity_test.py`, `src/evaluate.py`, `src/evaluate_model.py`, `src/model_registry.py`, `src/model_comparison.py` | Existing embedding, retrieval, evaluation, registry, and comparison baseline. |
| Frozen data | `data/evaluation_dataset.json`, `data/test_skills.json`, `embeddings/skill_embeddings.json` | Original benchmark inputs and baseline embedding artifact. |
| Phase 4.5 | `data/evaluation_dataset_v2.json`, `results/benchmark_v2_annotation_audit.json`, `results/benchmark_v2_scoring_protocol.md` | Explicit/inferred/ambiguous annotation audit and strict-track scoring definition. |
| Phase 5 | `src/hybrid_matcher.py`, `src/phase5_experiment.py` | Reusable lexical + E5 matcher and semantic-only versus hybrid experiment. |
| Phase 5 outputs | `results/phase5_results.json`, `results/phase5_report.md` | Measured comparison, qualitative tests, runtime, and ranking-difference analysis. |
| Phases 6–8 | `src/knowledge_base.py`, `src/workforce_scorer.py`, `src/workforce_pipeline.py`, `src/demo_pipeline.py` | Development knowledge adapter, transparent scorer, callable pipeline, and demo. |
| Demo outputs | `results/end_to_end_demo.json`, `results/end_to_end_demo.md` | Structured and human-readable end-to-end result. |

## Phase 4.5 benchmark policy

The v2 strict track includes the 58 records with at least one explicit expected label. Records R02, R03, and R13 are excluded because they have zero strict labels. Inferred and ambiguous classifications remain available in the audit artifacts but are not silently promoted to strict gold labels.

For strict evaluation, the gold set for record \(i\) is its explicit label set \(G_i\). Model outputs are deduplicated prediction sets. The protocol defines exact set match, per-record precision/recall/F1, micro and macro precision/recall/F1, and any-label Hit@1/3/5 as a separate retrieval diagnostic. Natural Language Processing and JavaScript have zero strict positive support and are excluded from the primary supported-label macro denominator.

## Phase 5 matcher

`HybridSkillMatcher` accepts a canonical skill catalog and loads `intfloat/e5-base-v2` once per matcher instance. Evidence is encoded with `query: <evidence>` and canonical skills with `passage: <skill>`. Embeddings are normalized before cosine similarity.

The lexical branch is deterministic, case-insensitive, whitespace-normalized, word-boundary-aware, and supports multi-word canonical skills and selected safe aliases. It only emits skills present in the supplied canonical catalog. The semantic branch ranks every canonical skill. The hybrid score is:

\[
H(s) = 0.65L(s) + 0.35\,C(s),
\]

where \(L(s)\) is 1.0 for a lexical match and 0.0 otherwise, and \(C(s)\) is normalized cosine similarity. The weights are initial heuristics and are not tuned or scientifically validated.

Confidence is `high` when a lexical match exists or semantic similarity is at least 0.60, `medium` when similarity is at least 0.40, and `low` otherwise. These thresholds are heuristic and not statistically calibrated.

## Knowledge layer

No official O*NET dataset or API configuration was available in the workspace. `knowledge_base.py` therefore exposes an adapter-shaped interface backed by a small development fixture derived from the canonical skills. The source marker is `development_fixture_not_official_onet`.

The interface provides:

```python
get_skill_context(skill)
get_related_occupations(skill)
get_skill_importance(skill)
```

The fixture maps skills to illustrative occupations, importance values, and workforce-relevance descriptions. These values are demo inputs only; they are not official O*NET observations or external labor-market facts.

## Workforce scorer

`workforce_scorer.py` uses a transparent rule-based calculation. For a selected candidate skill, the candidate contribution is:

\[
CandidateSkillScore(s) = ConfidenceValue(s) \times Importance(s).
\]

Readiness is the weighted matched required-skill contribution divided by total required-skill importance:

\[
Readiness = \frac{\sum_{s\in matched} ConfidenceValue(s)\times Importance(s)}{\sum_{s\in required} Importance(s)}.
\]

Missing required skills become skill gaps. Career paths are ranked by fixture occupation overlap and weighted overlap. The confidence mapping and readiness calculation are configurable heuristics and are not scientifically validated.

## End-to-end pipeline

`WorkforcePipeline` constructs one matcher, analyzes candidate and job-description text, selects explicit lexical matches plus hybrid matches above the configured threshold, extracts required canonical skills from the job description, and passes the candidate evidence to the scorer. The callable convenience function is:

```python
from workforce_pipeline import analyze_candidate

result = analyze_candidate(
    resume_text="...",
    job_description="...",
    skill_names=skills,
)
```

The JSON-compatible output includes candidate skills, matched and missing required skills, skill gaps, readiness score, career paths, job relevance, confidence, and evidence details.

## Running the demo

From the `ml` directory on a Python environment with the existing Phase 5 dependencies installed:

```text
python src/demo_pipeline.py
```

The demo writes `results/end_to_end_demo.json` and `results/end_to_end_demo.md`. The verified sample candidate contains Python, FastAPI, Docker, and Machine Learning. The sample job requires Python, Machine Learning, Docker, TensorFlow, and Kubernetes.

The measured demo output is:

| Field | Result |
|---|---|
| Candidate skills detected | Python, FastAPI, Docker, Machine Learning |
| Matched required skills | Python, Machine Learning, Docker |
| Missing required skills | TensorFlow, Kubernetes |
| Job relevance coverage | 60.0% |
| Readiness score | 0.6177156177, or 61.8% |
| Top career recommendation | Machine Learning Engineer |
| Overall confidence | high |

## Phase 5 measured reference

The verified Phase 5 experiment used 58 strict records and the unique top-5 prediction-set rule.

| Metric | E5 semantic-only | Hybrid lexical + E5 |
|---|---:|---:|
| Exact-match accuracy | 0.0000 | 0.0000 |
| Micro precision | 0.3483 | 0.3552 |
| Micro recall | 0.9806 | 1.0000 |
| Micro F1 | 0.5140 | 0.5242 |
| Macro precision | 0.4685 | 0.4753 |
| Macro recall | 0.9850 | 1.0000 |
| Macro F1 | 0.5857 | 0.5963 |
| Any-label Hit@1 | 0.9483 | 1.0000 |
| Any-label Hit@3 | 1.0000 | 1.0000 |
| Any-label Hit@5 | 1.0000 | 1.0000 |

The hybrid method improved several measured metrics in this development experiment, but exact-match accuracy remained zero for both approaches. This table is a reference to the existing result artifact and not a production validation claim.

## Verification and limitations

The reconstruction verification includes Python syntax checks for all Phase 6–8 modules, the complete demo execution, required lexical examples for Python, FastAPI, Docker, and PostgreSQL, word-boundary false-positive checks, JSON/Markdown output validation, and frozen-file fingerprint checks. The knowledge fixture is explicitly non-official O*NET data. The readiness score, career paths, confidence, and matcher thresholds are heuristic. The benchmark lacks complete positive support for Natural Language Processing and JavaScript and should remain a development prototype until those evaluation limitations are resolved.

No work beyond the requested Phase 4.5–8 artifact reconstruction is included.
