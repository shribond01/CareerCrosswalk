export type PiiKind = "email" | "phone" | "address" | "personal-id" | "other";

export interface PiiFinding {
  kind: PiiKind;
  start: number;
  end: number;
  value: string;
  replacement: string;
}

export interface PiiMinimizationResult {
  text: string;
  findings: PiiFinding[];
}

const patterns: Array<{ kind: PiiKind; pattern: RegExp; replacement: string }> = [
  {
    kind: "email",
    pattern: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi,
    replacement: "[EMAIL REDACTED]",
  },
  {
    kind: "phone",
    pattern: /(?<!\w)(?:\+?\d[\d .()\-]{7,}\d)(?!\w)/g,
    replacement: "[PHONE REDACTED]",
  },
  {
    kind: "personal-id",
    pattern: /\b(?:SSN|social security|aadhaar|passport|national id)\s*[:#-]?\s*[A-Z0-9 -]{4,}\b/gi,
    replacement: "[PERSONAL ID REDACTED]",
  },
  {
    kind: "address",
    pattern: /\b(?:address|resides at|street|road|avenue|apt\.?|suite)\s*[:#-]?\s*[^\n]{5,100}/gi,
    replacement: "[ADDRESS REDACTED]",
  },
];

/**
 * Removes high-confidence identifiers from text before an external-model call.
 * It is intentionally conservative and not a document security scanner.
 */
export function minimizePii(text: string): PiiMinimizationResult {
  const findings: PiiFinding[] = [];
  let sanitized = text;

  for (const { kind, pattern, replacement } of patterns) {
    sanitized = sanitized.replace(pattern, (value, offset: number) => {
      findings.push({
        kind,
        start: offset,
        end: offset + value.length,
        value,
        replacement,
      });
      return replacement;
    });
  }

  return { text: sanitized, findings };
}

export function hasPii(text: string): boolean {
  return minimizePii(text).findings.length > 0;
}
