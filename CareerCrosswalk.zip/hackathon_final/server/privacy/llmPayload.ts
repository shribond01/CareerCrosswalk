import { minimizePii } from "./pii.ts";

export interface ExternalLlmPayload {
  messages: Array<{ role: "user" | "assistant"; content: string }>;
  context: string;
  piiRedacted: boolean;
}

/** Builds an external-model payload only after minimizing high-confidence PII. */
export function buildExternalLlmPayload(input: {
  messages: Array<{ role: "user" | "assistant"; content: string }>;
  context: string;
}): ExternalLlmPayload {
  const sanitizedMessages = input.messages.map((message) => ({
    ...message,
    content: minimizePii(message.content).text,
  }));
  const sanitizedContext = minimizePii(input.context);

  return {
    messages: sanitizedMessages,
    context: sanitizedContext.text,
    piiRedacted:
      sanitizedContext.findings.length > 0 ||
      sanitizedMessages.some((message, index) => message.content !== input.messages[index].content),
  };
}
