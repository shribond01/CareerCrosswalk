import assert from "node:assert/strict";
import { test } from "node:test";
import { randomBytes } from "node:crypto";
import { decryptResume, encryptResume, parseEnvelope, serializeEnvelope } from "./crypto.ts";
import { buildExternalLlmPayload } from "./llmPayload.ts";
import { minimizePii } from "./pii.ts";
import { shouldPersistResume } from "./storage.ts";

const key = { getKey: () => randomBytes(32) };
const stableKey = randomBytes(32);
const stableProvider = { getKey: () => stableKey };

test("encrypts and decrypts resume content with AES-256-GCM", () => {
  const original = "Resume content with private details";
  const envelope = encryptResume(original, stableProvider, "user:user-1");
  const roundTrip = decryptResume(parseEnvelope(serializeEnvelope(envelope)), stableProvider).toString("utf8");
  assert.equal(roundTrip, original);
  assert.notEqual(envelope.ciphertext, Buffer.from(original).toString("base64"));
});

test("rejects tampered ciphertext", () => {
  const envelope = encryptResume("private resume", stableProvider);
  envelope.ciphertext = Buffer.from("tampered").toString("base64");
  assert.throws(() => decryptResume(envelope, stableProvider));
});

test("uses a fresh IV for each encryption", () => {
  const one = encryptResume("same", key);
  const two = encryptResume("same", key);
  assert.notEqual(one.iv, two.iv);
});

test("requires explicit storage preference", () => {
  assert.equal(shouldPersistResume({ preference: "store" }), true);
  assert.equal(shouldPersistResume({ preference: "do-not-store" }), false);
});

test("minimizes high-confidence PII", () => {
  const result = minimizePii("Email me at jane@example.com or call +1 (555) 123-4567.");
  assert.equal(result.findings.length, 2);
  assert.match(result.text, /EMAIL REDACTED/);
  assert.match(result.text, /PHONE REDACTED/);
  assert.doesNotMatch(result.text, /jane@example.com/);
});

test("builds external LLM payload without detected PII", () => {
  const payload = buildExternalLlmPayload({
    messages: [{ role: "user", content: "My email is jane@example.com" }],
    context: "Phone: 555-123-4567",
  });
  assert.equal(payload.piiRedacted, true);
  assert.doesNotMatch(JSON.stringify(payload), /jane@example.com|555-123-4567/);
});
