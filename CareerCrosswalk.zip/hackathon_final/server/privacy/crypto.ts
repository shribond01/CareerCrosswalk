import {
  createCipheriv,
  createDecipheriv,
  randomBytes,
} from "node:crypto";

const ALGORITHM = "aes-256-gcm" as const;
const IV_BYTES = 12;
const KEY_BYTES = 32;
const VERSION = 1;

export interface EncryptedResumeEnvelope {
  version: typeof VERSION;
  algorithm: typeof ALGORITHM;
  iv: string;
  ciphertext: string;
  authTag: string;
  aad?: string;
}

export interface ResumeKeyProvider {
  getKey(): Buffer;
}

function decodeBase64Key(value: string): Buffer {
  const key = Buffer.from(value, "base64");
  if (key.length !== KEY_BYTES) {
    throw new Error("RESUME_ENCRYPTION_KEY must be a base64-encoded 32-byte key");
  }
  return key;
}

/** Loads the resume encryption key from the server process environment only. */
export function serverResumeKeyFromEnv(
  env: NodeJS.ProcessEnv = process.env,
): ResumeKeyProvider {
  const encoded = env.RESUME_ENCRYPTION_KEY;
  if (!encoded) {
    throw new Error("RESUME_ENCRYPTION_KEY is not configured on the server");
  }
  const key = decodeBase64Key(encoded);
  return { getKey: () => key };
}

export function encryptResume(
  plaintext: string | Buffer,
  keyProvider: ResumeKeyProvider,
  associatedData?: string,
): EncryptedResumeEnvelope {
  const iv = randomBytes(IV_BYTES);
  const cipher = createCipheriv(ALGORITHM, keyProvider.getKey(), iv);
  if (associatedData) cipher.setAAD(Buffer.from(associatedData, "utf8"));
  const ciphertext = Buffer.concat([
    cipher.update(plaintext),
    cipher.final(),
  ]);

  return {
    version: VERSION,
    algorithm: ALGORITHM,
    iv: iv.toString("base64"),
    ciphertext: ciphertext.toString("base64"),
    authTag: cipher.getAuthTag().toString("base64"),
    ...(associatedData ? { aad: associatedData } : {}),
  };
}

export function decryptResume(
  envelope: EncryptedResumeEnvelope,
  keyProvider: ResumeKeyProvider,
): Buffer {
  if (envelope.version !== VERSION || envelope.algorithm !== ALGORITHM) {
    throw new Error("Unsupported encrypted resume envelope");
  }
  const decipher = createDecipheriv(
    ALGORITHM,
    keyProvider.getKey(),
    Buffer.from(envelope.iv, "base64"),
  );
  if (envelope.aad) decipher.setAAD(Buffer.from(envelope.aad, "utf8"));
  decipher.setAuthTag(Buffer.from(envelope.authTag, "base64"));
  return Buffer.concat([
    decipher.update(Buffer.from(envelope.ciphertext, "base64")),
    decipher.final(),
  ]);
}

export function serializeEnvelope(envelope: EncryptedResumeEnvelope): string {
  return JSON.stringify(envelope);
}

export function parseEnvelope(serialized: string): EncryptedResumeEnvelope {
  return JSON.parse(serialized) as EncryptedResumeEnvelope;
}
