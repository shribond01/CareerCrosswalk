export type ResumeStoragePreference = "store" | "do-not-store";

export interface ResumeStorageRecord {
  id: string;
  userId: string;
  encryptedResume: string;
  createdAt: string;
  updatedAt: string;
}

export interface ResumeStorageAdapter {
  save(record: ResumeStorageRecord): Promise<void>;
  getById(userId: string, id: string): Promise<ResumeStorageRecord | null>;
  listForUser(userId: string): Promise<ResumeStorageRecord[]>;
  deleteById(userId: string, id: string): Promise<void>;
}

export interface ResumeStoragePolicy {
  preference: ResumeStoragePreference;
}

/**
 * Storage decisions are explicit. This layer deliberately does not schedule or
 * perform automatic deletion; deletion must be an explicit user action or an
 * authenticated retention-policy job owned by the backend.
 */
export function shouldPersistResume(policy: ResumeStoragePolicy): boolean {
  return policy.preference === "store";
}

export function createNoStoragePolicy(): ResumeStoragePolicy {
  return { preference: "do-not-store" };
}

export function createStorePolicy(): ResumeStoragePolicy {
  return { preference: "store" };
}
