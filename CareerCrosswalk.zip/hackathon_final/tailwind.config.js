/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        display: ["system-ui", "-apple-system", "BlinkMacSystemFont", "'Segoe UI'", "sans-serif"],
        body: ["system-ui", "-apple-system", "BlinkMacSystemFont", "'Segoe UI'", "sans-serif"],
        mono: ["ui-monospace", "SFMono-Regular", "Consolas", "monospace"],
      },
      colors: {
        ink: {
          950: "rgb(var(--ink-950) / <alpha-value>)",
          900: "rgb(var(--ink-900) / <alpha-value>)",
          800: "rgb(var(--ink-800) / <alpha-value>)",
          700: "rgb(var(--ink-700) / <alpha-value>)",
        },
        crosswalk: {
          400: "#5C8DFF",
          500: "#3A6EF0",
          600: "#2A57D6",
        },
        surface: {
          DEFAULT: "rgb(var(--surface) / <alpha-value>)",
          raised: "rgb(var(--surface-raised) / <alpha-value>)",
          sunken: "rgb(var(--surface-sunken) / <alpha-value>)",
        },
        stone: {
          150: "rgb(var(--stone-150) / <alpha-value>)",
        },
        matched: { DEFAULT: "#10B981", bg: "rgba(16, 185, 129, 0.1)" },
        partial: { DEFAULT: "#F59E0B", bg: "rgba(245, 158, 11, 0.1)" },
        missing: { DEFAULT: "#EF4444", bg: "rgba(239, 68, 68, 0.1)" },
        transfer: { DEFAULT: "#06B6D4", bg: "rgba(6, 182, 212, 0.1)" },
      },
      boxShadow: {
        card: "0 4px 20px rgba(0, 0, 0, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.05)",
        raised: "0 10px 30px rgba(0, 0, 0, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.05)",
        pop: "0 20px 50px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.1)",
      },
      backgroundImage: {
        "crosswalk-stripes":
          "repeating-linear-gradient(115deg, rgba(255,255,255,0.055) 0px, rgba(255,255,255,0.055) 14px, transparent 14px, transparent 42px)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: 0, transform: "translateY(8px)" },
          "100%": { opacity: 1, transform: "translateY(0)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.5s cubic-bezier(0.16,1,0.3,1) both",
      },
    },
  },
  plugins: [],
};
