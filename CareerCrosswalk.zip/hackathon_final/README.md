# CareerCrosswalk

CareerCrosswalk is a React + TypeScript and FastAPI application that analyzes an uploaded resume, extracts skills, matches them against O*NET workplace software skills, ranks potential occupations, and presents skill gaps with a learning-oriented roadmap.

The repository contains a working local application and synthetic/demo UI data. Resume analysis is routed to the FastAPI service. Jobs, market insights, salary figures, and the “what if” simulator are explicitly illustrative until connected to a licensed, production data source.

## Features

- PDF, DOCX, TXT, Markdown, and image resume extraction.
- Native PDF/DOCX/TXT extraction with OCR fallback for images and scanned PDFs when Tesseract and Poppler are installed.
- Hybrid lexical and E5 semantic skill matching.
- O*NET-based occupation ranking and evidence-backed skill gaps.
- Optional server-side Gemini chat; the provider key is never sent to the browser.
- Privacy-oriented PII minimization before optional external-model requests.
- Responsive React dashboard with career, skills, roadmap, jobs, and market views.

## Technology stack

- Frontend: React 19, TypeScript, Vite, React Router, Tailwind CSS, Recharts, Framer Motion, and Lucide.
- Backend: Python, FastAPI, Uvicorn, Pydantic, pdfplumber, pdf2image, pytesseract, Pillow, NumPy, and sentence-transformers.
- Data: O*NET occupation and software-skills source files included under `data/`.

## Architecture

```text
Browser (React/Vite)
        │ /api proxy in development; nginx proxy in Docker
        ▼
FastAPI (`backend/server.py`)
        ├── resume extraction (`backend/resume_extractor.py`)
        ├── generated O*NET profiles (`backend/job_profiles.json`)
        └── WOS matching/scoring (`WOS/ml/src/`)
```

`backend/buildonetvectors.py` regenerates `backend/job_profiles.json` from the included tab-separated O*NET source files. The semantic embedding artifact is generated at startup when a compatible cached artifact is not present.

## Local setup

### Frontend

```bash
npm install
npm run build
npm run dev
```

The Vite development server runs at `http://localhost:5173` and proxies `/api` to `http://127.0.0.1:8000`.

### Backend

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r backend/requirements.txt
python backend/buildonetvectors.py
uvicorn server:app --app-dir backend --reload --port 8000
```

Copy `backend/.env.example` to `backend/.env` only when you need optional provider configuration. Never commit `backend/.env`. OCR for images or scanned PDFs additionally requires system installations of Tesseract and Poppler; set `TESSERACT_CMD` or `POPPLER_PATH` when automatic discovery is unavailable.

### Docker

```bash
docker compose up --build
```

The frontend is served on port 5173 and the API on port 8000.

## Verification commands

```bash
npm run build
npm run lint
npm run typecheck:server
npm run test:privacy
python -m compileall -q backend WOS/ml/src
```

These commands validate the checked-in source. A full resume-analysis smoke test also requires the Python dependencies and the E5 model download.

## Limitations and demo boundaries

- Jobs, market insights, salary figures, and the what-if projection are demo/illustrative features, not live labor-market data.
- Analysis is local to the running API process; there is no authenticated multi-user session or persistent database.
- The optional Gemini chat requires a user-provided `GEMINI_API_KEY`.
- OCR depends on external system binaries and can vary by document quality.
- The included O*NET files and derived profiles should be reviewed for applicable licensing and redistribution requirements before public release.

## Security and privacy

Do not upload real resumes to a public demo unless the deployment has appropriate access control, retention, and privacy notices. The API limits upload size to 10 MB, restricts supported extensions, deletes temporary upload files after processing, and does not expose provider keys to the browser. Review CORS settings and add authentication before production deployment.

Please report suspected vulnerabilities privately to the repository owner rather than opening a public issue with sensitive details.
