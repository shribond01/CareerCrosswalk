import type { User } from "../types";

/** Synthetic profile used only for the landing-page preview. */
export const demoUser: User = {
  name: "Alex Morgan",
  headline: "Computer Science Student",
  education: "Computer Science",
  degree: "Synthetic demo profile",
  experienceYears: 1,
  preferredLocation: "Remote",
  preferredWork: "Hybrid",
  targetRoles: ["Software Developer", "Data Analyst", "AI Engineer"],
  careerReadiness: 78,
  readinessDelta: 8,
};
