import type { SkillDemand, LocationDemand } from "../types";

export const skillDemand: SkillDemand[] = [
  { skill: "Python", demandPercent: 82 },
  { skill: "SQL", demandPercent: 76 },
  { skill: "Power BI", demandPercent: 54 },
  { skill: "AWS", demandPercent: 48 },
  { skill: "Docker", demandPercent: 42 },
  { skill: "React", demandPercent: 39 },
];

export const growingSkills = ["Generative AI", "Cloud Infrastructure", "Data Engineering", "Cybersecurity"];

export const locationDemand: LocationDemand[] = [
  { city: "Bengaluru", demandIndex: 94 },
  { city: "Hyderabad", demandIndex: 89 },
  { city: "Chennai", demandIndex: 82 },
  { city: "Pune", demandIndex: 81 },
  { city: "Mumbai", demandIndex: 77 },
];

export const domainDemand = [
  { domain: "Software Dev", jan: 62, apr: 68, jul: 71, oct: 74 },
  { domain: "Data", jan: 48, apr: 55, jul: 63, oct: 69 },
  { domain: "AI/ML", jan: 35, apr: 44, jul: 56, oct: 66 },
  { domain: "Cybersecurity", jan: 30, apr: 36, jul: 41, oct: 49 },
];
