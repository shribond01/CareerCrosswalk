import type { RoadmapStep, PriorityGap, SkillGapItem } from "../types";

export const roadmapSteps: RoadmapStep[] = [
  {
    id: "r1",
    skill: "Python",
    effort: "Completed",
    status: "completed",
    completionPercent: 100,
    resources: ["NPTEL: Python for Data Science"],
  },
  {
    id: "r2",
    skill: "SQL",
    effort: "~2 weeks",
    status: "in-progress",
    completionPercent: 70,
    resources: ["Mode Analytics: SQL Tutorial", "NPTEL: Database Management Systems"],
  },
  {
    id: "r3",
    skill: "Power BI",
    effort: "~3 weeks",
    status: "in-progress",
    completionPercent: 20,
    resources: ["Coursera: Data Visualization with Power BI"],
  },
  {
    id: "r4",
    skill: "Advanced SQL & Data Warehousing",
    effort: "~4 weeks",
    status: "not-started",
    completionPercent: 0,
    resources: ["Udemy: Advanced SQL for Analytics"],
  },
  {
    id: "r5",
    skill: "Portfolio Projects",
    effort: "~3 weeks",
    status: "not-started",
    completionPercent: 0,
    resources: ["Build 2 end-to-end BI dashboards"],
  },
  {
    id: "r6",
    skill: "Interview Preparation",
    effort: "~2 weeks",
    status: "not-started",
    completionPercent: 0,
    resources: ["Mock interviews", "Case-study practice"],
  },
];

export const priorityGaps: PriorityGap[] = [
  {
    rank: 1,
    skill: "Power BI",
    priority: "HIGH",
    reason: "Required by 4 of your top 5 target roles.",
  },
  {
    rank: 2,
    skill: "Advanced SQL",
    priority: "HIGH",
    reason: "Foundational for most data-analysis workflows you're matched to.",
  },
  {
    rank: 3,
    skill: "Cloud Fundamentals",
    priority: "MEDIUM",
    reason: "Opens up Data Engineer and Systems Analyst pathways.",
  },
  {
    rank: 4,
    skill: "Tableau",
    priority: "LOW",
    reason: "Transferable from Power BI once that's stronger; lower urgency.",
  },
];

export const skillGapBreakdown: SkillGapItem[] = [
  { skill: "Python", currentPercent: 95, status: "matched" },
  { skill: "SQL", currentPercent: 88, status: "matched" },
  { skill: "Statistics", currentPercent: 76, status: "matched" },
  { skill: "Power BI", currentPercent: 61, status: "partial" },
  { skill: "Excel", currentPercent: 94, status: "matched" },
  { skill: "Tableau", currentPercent: 0, status: "transferable", transferableFrom: "Power BI" },
  { skill: "AWS", currentPercent: 0, status: "missing" },
];
