import { useSyncExternalStore } from "react";
import { analysisStore } from "../services/analysisStore";
import { analysisCareers, analysisEvidence, analysisGaps, analysisRoadmap, analysisSkills } from "../services/analysisAdapters";

export function useAnalysis() {
  const session = useSyncExternalStore(analysisStore.subscribe, analysisStore.getSnapshot, analysisStore.getSnapshot);
  return {
    session,
    isReal: session?.status === "real_analysis",
    skills: session ? analysisSkills(session) : null,
    careers: session ? analysisCareers(session) : null,
    gaps: session ? analysisGaps(session) : null,
    roadmap: session ? analysisRoadmap(session) : null,
    evidence: session ? analysisEvidence(session) : null,
    readiness: session ? session.result.readiness_score * 100 : null,
  };
}
