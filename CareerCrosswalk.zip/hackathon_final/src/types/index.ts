export type EvidenceStatus = "verified" | "detected" | "inferred" | "missing";
export type GapStatus = "matched" | "partial" | "missing" | "transferable";
export type Proficiency = "Beginner" | "Intermediate" | "Advanced";
export type Priority = "HIGH" | "MEDIUM" | "LOW";

export interface User {
  name: string;
  headline: string;
  education: string;
  degree: string;
  experienceYears: number;
  preferredLocation: string;
  preferredWork: "Remote" | "Hybrid" | "On-site";
  targetRoles: string[];
  careerReadiness: number;
  readinessDelta: number;
}

export interface SkillEvidence {
  label: string;
  status: EvidenceStatus;
}

export interface Skill {
  id: string;
  name: string;
  category: "Programming" | "Data" | "Web" | "Cloud/Infra" | "Tools" | "Soft Skills";
  proficiency: Proficiency;
  confidence: number; // 0-100
  status: "verified" | "developing" | "missing";
  evidence: SkillEvidence[];
  relatedSkills: string[];
}

export interface CareerSkillMatch {
  skill: string;
  status: GapStatus;
  note?: string;
  transferableFrom?: string;
}

export interface Career {
  id: string;
  socCode: string;
  title: string;
  domain: string;
  matchPercent: number;
  matchLabel: "Strong Match" | "Good Match" | "Skills Required";
  matchingSkills: string[];
  missingSkills: string[];
  skillBreakdown: CareerSkillMatch[];
  description: string;
  medianSalaryINR: string;
  demandTrend: "Rising" | "Stable" | "Declining" | "Not available";
}

export interface SkillGapItem {
  skill: string;
  currentPercent: number;
  status: GapStatus;
  transferableFrom?: string;
}

export interface PriorityGap {
  rank: number;
  skill: string;
  priority: Priority;
  reason: string;
}

export interface RoadmapStep {
  id: string;
  skill: string;
  effort: string;
  status: "completed" | "in-progress" | "not-started";
  completionPercent: number;
  resources: string[];
}

export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salaryRange: string;
  matchPercent: number;
  jobType: "Full-time" | "Internship" | "Contract";
  experience: "0-1 yrs" | "1-3 yrs" | "3-5 yrs";
  careerId: string;
  skills: { name: string; status: GapStatus }[];
  postedDaysAgo: number;
}

export interface SkillDemand {
  skill: string;
  demandPercent: number;
}

export interface LocationDemand {
  city: string;
  demandIndex: number;
}

export interface ProcessingStep {
  label: string;
  status: "pending" | "active" | "done";
}

export interface AIMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
}
