export interface WosEvidence {
  skill: string;
  confidence: string;
  confidence_value: number;
  numeric_confidence: number;
  semantic_score: number;
  lexical_score: number;
  hybrid_score: number;
  lexical_match: boolean;
  importance: number;
  candidate_skill_score: number;
  context?: { workforce_relevance?: string; source_type?: string };
}

export interface WosCareerPath {
  soc_code?: string;
  occupation: string;
  overlap: number;
  weighted_overlap: number;
  skills: string[];
  source_type: string;
  match_pct?: number;
  missing_skills?: string[];
}

export interface WosSkillGap {
  skill: string;
  importance: number;
  reason: string;
  context?: { workforce_relevance?: string; source_type?: string };
}

export interface WosAnalysisResult {
  candidate_skills: string[];
  matched_skills: string[];
  missing_skills: string[];
  readiness_score: number;
  career_paths: WosCareerPath[];
  skill_gaps: WosSkillGap[];
  evidence: {
    selected_candidate_matches: Array<Record<string, unknown>>;
  };
  job_relevance: {
    required_skills: string[];
    matched_skills: string[];
    missing_skills: string[];
    coverage: number;
  };
  confidence: { level: string; mean_numeric_confidence: number; selection_threshold: number };
  scoring_details?: Record<string, unknown>;
}

export interface AnalysisSession {
  id: string;
  status: "real_analysis" | "demo";
  fileName: string;
  resumeText?: string;
  result: WosAnalysisResult;
}
