import { BrowserRouter, Routes, Route } from "react-router-dom";
import { DashboardLayout } from "./components/layout/DashboardLayout";
import Landing from "./pages/Landing";
import Dashboard from "./pages/Dashboard";
import ResumeUpload from "./pages/ResumeUpload";
import Skills from "./pages/Skills";
import Careers from "./pages/Careers";
import CareerDetail from "./pages/CareerDetail";
import SkillGap from "./pages/SkillGap";
import Roadmap from "./pages/Roadmap";
import Jobs from "./pages/Jobs";
import Market from "./pages/Market";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";

import { AIProvider } from "./components/ai/AIProvider";
import { AppStateProvider } from "./components/app/AppStateProvider";

export default function App() {
  return (
    <BrowserRouter>
      <AppStateProvider>
        <AIProvider>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route element={<DashboardLayout />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/resume" element={<ResumeUpload />} />
            <Route path="/skills" element={<Skills />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/career/:id" element={<CareerDetail />} />
            <Route path="/skill-gap" element={<SkillGap />} />
            <Route path="/roadmap" element={<Roadmap />} />
            <Route path="/jobs" element={<Jobs />} />
            <Route path="/market" element={<Market />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/settings" element={<Settings />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
        </AIProvider>
      </AppStateProvider>
    </BrowserRouter>
  );
}
