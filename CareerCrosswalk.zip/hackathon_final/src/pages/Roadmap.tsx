import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, X, Plus } from "lucide-react";
import { PageHeader } from "../components/shared/PageHeader";
import { Card, Button, Badge } from "../components/ui/primitives";
import { RoadmapStepCard } from "../components/shared/RoadmapStep";
import { ReadinessRing } from "../components/shared/ReadinessScore";
import { roadmapSteps } from "../data/roadmap";
import { demoUser } from "../data/users";
import { simulateReadiness } from "../services/careerService";

import { useAI } from "../components/ai/AIProvider";
import { useAnalysis } from "../hooks/useAnalysis";

const simulatorOptions = ["Python", "SQL", "Power BI", "AWS", "Advanced SQL", "Tableau"];

export default function Roadmap() {
  const { setIsOpen, sendMessage } = useAI();
  const { roadmap: analyzedRoadmap, readiness } = useAnalysis();
  const visibleRoadmap = analyzedRoadmap ?? roadmapSteps;
  const currentReadiness = readiness ?? demoUser.careerReadiness;
  const [selected, setSelected] = useState<string[]>([]);
  const [simResult, setSimResult] = useState<{ readiness: number; roles: string[] } | null>(null);
  const [loading, setLoading] = useState(false);

  const toggle = (skill: string) => {
    setSimResult(null);
    setSelected((prev) => (prev.includes(skill) ? prev.filter((s) => s !== skill) : [...prev, skill]));
  };

  const runSimulation = async () => {
    setLoading(true);
    const readiness = await simulateReadiness(currentReadiness, selected);
    const roleBank = ["Data Analyst", "BI Analyst", "Junior Data Engineer", "Cloud Support Analyst"];
    setSimResult({ readiness, roles: roleBank.slice(0, Math.max(1, Math.min(3, selected.length))) });
    setLoading(false);
  };

  return (
    <div>
      <PageHeader title="Career Roadmap" subtitle="Your prioritized path from current skills to job-ready." />

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="relative pl-1">
            {visibleRoadmap.map((step, i) => (
              <RoadmapStepCard key={step.id} step={step} isLast={i === visibleRoadmap.length - 1} />
            ))}
          </div>
        </div>

        <div className="lg:sticky lg:top-6 lg:self-start">
          <Card className="p-6">
            <div className="flex items-center gap-2">
              <Sparkles size={18} className="text-crosswalk-500" />
              <h2 className="font-display text-base font-semibold text-ink-900">"What If I Learn?"</h2>
            </div>
            <p className="mt-1 text-sm text-ink-700/60">Pick a few skills to see your recalculated readiness.</p>

            <div className="mt-4 flex flex-wrap gap-2">
              {simulatorOptions.map((s) => {
                const isSelected = selected.includes(s);
                return (
                  <button
                    key={s}
                    onClick={() => toggle(s)}
                    className={`inline-flex items-center gap-1 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
                      isSelected
                        ? "border-crosswalk-500 bg-crosswalk-500/25 text-crosswalk-400"
                        : "border-white/5 bg-white/5 text-ink-700 hover:bg-white/10"
                    }`}
                  >
                    {isSelected ? <X size={12} /> : <Plus size={12} />}
                    {s}
                  </button>
                );
              })}
            </div>

            <Button className="mt-5 w-full" disabled={selected.length === 0 || loading} onClick={runSimulation}>
              {loading ? "Recalculating…" : "Recalculate Readiness"}
            </Button>

            <AnimatePresence>
              {simResult && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-5 overflow-hidden border-t border-stone-150 pt-5"
                >
                  <div className="flex items-center justify-around">
                    <div className="text-center">
                      <p className="text-xs text-ink-700/50">Current</p>
                      <ReadinessRing value={currentReadiness} size={90} />
                    </div>
                    <div className="text-crosswalk-500">→</div>
                    <div className="text-center">
                      <p className="text-xs text-ink-700/50">After Learning</p>
                      <ReadinessRing value={simResult.readiness} size={90} />
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">New career opportunities</p>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {simResult.roles.map((r) => (
                        <Badge key={r} tone="matched">
                          + {r}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </Card>

          {/* AI Milestone Guide Contextual Widget */}
          <Card className="p-4 border-crosswalk-500/10 bg-[#0d1424]/40 mt-5">
            <div className="flex items-center gap-2 text-cyan-400 mb-2">
              <Sparkles size={15} />
              <h3 className="font-display font-semibold text-xs uppercase tracking-wider">AI Milestone Guide</h3>
            </div>
            <p className="text-xs text-ink-700/60 leading-relaxed font-sans">
              You are currently focusing on SQL. Fulfilling intermediate SQL capability and solving Power BI gaps should be prioritized first before diving into new topics like AWS.
            </p>
            <button
              onClick={() => {
                setIsOpen(true);
                sendMessage("Give me a milestone study plan for SQL and Power BI");
              }}
              className="mt-3 text-xs text-crosswalk-450 hover:text-crosswalk-300 font-semibold flex items-center gap-0.5 bg-white/5 border border-white/5 rounded-lg px-2.5 py-1.5 hover:bg-white/10 transition-colors"
            >
              Review Milestone Details →
            </button>
          </Card>
        </div>
      </div>
    </div>
  );
}
