import { PageHeader } from "../components/shared/PageHeader";
import { Card, Badge } from "../components/ui/primitives";
import { skillDemand, growingSkills, locationDemand, domainDemand } from "../data/market";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, CartesianGrid, LineChart, Line, Legend, Tooltip } from "recharts";
import { TrendingUp } from "lucide-react";

export default function Market() {
  return (
    <div>
      <PageHeader
        title="Labor Market Intelligence"
        subtitle="Demonstration values, not live labor-market data."
        action={<Badge tone="partial">Demo data</Badge>}
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="p-6 font-sans">
          <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50 mb-3">Skill Demand</p>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={skillDemand} layout="vertical" margin={{ left: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.05)" horizontal={false} />
              <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={{ stroke: "rgba(255,255,255,0.05)" }} />
              <YAxis type="category" dataKey="skill" tick={{ fontSize: 12, fill: "#9CA3AF" }} width={70} axisLine={{ stroke: "rgba(255,255,255,0.05)" }} />
              <Tooltip contentStyle={{ backgroundColor: "#101727", borderColor: "rgba(255,255,255,0.08)", color: "#fff" }} />
              <Bar dataKey="demandPercent" fill="#3A6EF0" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6 font-sans">
          <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50 mb-3">Demand Trend by Domain</p>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={[
              { period: "Jan", ...Object.fromEntries(domainDemand.map((d) => [d.domain, d.jan])) },
              { period: "Apr", ...Object.fromEntries(domainDemand.map((d) => [d.domain, d.apr])) },
              { period: "Jul", ...Object.fromEntries(domainDemand.map((d) => [d.domain, d.jul])) },
              { period: "Oct", ...Object.fromEntries(domainDemand.map((d) => [d.domain, d.oct])) },
            ]}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.05)" />
              <XAxis dataKey="period" tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={{ stroke: "rgba(255,255,255,0.05)" }} />
              <YAxis tick={{ fontSize: 11, fill: "#9CA3AF" }} axisLine={{ stroke: "rgba(255,255,255,0.05)" }} />
              <Tooltip contentStyle={{ backgroundColor: "#101727", borderColor: "rgba(255,255,255,0.08)", color: "#fff" }} />
              <Legend wrapperStyle={{ fontSize: 11, color: "#cbd5e1" }} />
              {domainDemand.map((d, i) => (
                <Line key={d.domain} type="monotone" dataKey={d.domain} stroke={["#3A6EF0", "#10B981", "#F59E0B", "#EF4444"][i]} strokeWidth={2} dot={false} />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="p-6">
          <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">Growing Skills</p>
          <div className="mt-4 space-y-2.5">
            {growingSkills.map((s) => (
              <div key={s} className="flex items-center justify-between rounded-lg bg-surface-sunken px-3 py-2.5">
                <span className="text-sm font-medium text-ink-900">{s}</span>
                <TrendingUp size={14} className="text-matched" />
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">Location Demand</p>
          <div className="mt-4 grid grid-cols-2 gap-3">
            {locationDemand.map((l) => (
              <div key={l.city} className="rounded-lg border border-stone-150 p-3 text-center">
                <p className="font-mono text-xl font-bold text-ink-900">{l.demandIndex}%</p>
                <p className="text-xs text-ink-700/60">{l.city}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
