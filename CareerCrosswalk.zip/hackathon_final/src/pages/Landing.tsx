import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Upload,
  Sparkles,
  Target,
  GraduationCap,
  Radar,
  ShieldCheck,
  BarChart3,
} from "lucide-react";
import { ReadinessRing } from "../components/shared/ReadinessScore";
import { Badge } from "../components/ui/primitives";

const steps = [
  { icon: Upload, title: "Upload Resume", desc: "PDF, DOCX, or a photo — we extract what's actually there." },
  { icon: Sparkles, title: "Discover Your Skills", desc: "Explicit, detected, and inferred skills, each with a confidence score." },
  { icon: Target, title: "Find Matching Careers", desc: "Scored against real occupational skill requirements, not guesswork." },
  { icon: Radar, title: "Close Your Skill Gaps", desc: "See exactly what's missing, and what's transferable." },
  { icon: GraduationCap, title: "Become Job Ready", desc: "A prioritized roadmap that tracks your progress." },
];

const features = [
  { icon: Sparkles, title: "Skill Intelligence", desc: "Every skill tagged verified, detected, or inferred — never a black-box guess." },
  { icon: Target, title: "Career Matching", desc: "Occupation-grounded scoring, weighted by required vs. preferred skills." },
  { icon: BarChart3, title: "Explainable Skill Gaps", desc: "Matched, partial, missing, transferable — with a reason for every number." },
  { icon: Radar, title: "Labor-Market Insights", desc: "See what's rising in demand, and where, before you commit to a path." },
  { icon: GraduationCap, title: "Personalized Learning", desc: "A roadmap ordered by what actually unlocks the most opportunity." },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-surface relative">
      {/* Background Cyber Grid */}
      <div className="cyber-grid" />
      
      {/* Top bar */}
      <header className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6 border-b border-white/5 relative z-10">
        <span className="font-display text-lg font-bold text-white">
          Career<span className="text-crosswalk-450">Crosswalk</span>
        </span>
        <div className="flex items-center gap-3">
          <Link to="/dashboard" className="hidden text-sm font-medium text-ink-750 hover:text-white sm:block transition-colors">
            Sign in
          </Link>
          <Link
            to="/resume"
            className="rounded-lg bg-crosswalk-500 px-4 py-2 text-sm font-bold text-white hover:bg-crosswalk-400 transition-all hover:shadow-[0_0_15px_rgba(58,110,240,0.3)]"
          >
            Get Started
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-white/5">
        <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 px-6 pb-24 pt-16 lg:grid-cols-2 lg:pt-24 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          >
            <Badge tone="brand" className="bg-crosswalk-500/15 border border-crosswalk-500/30 text-crosswalk-400">
              O*NET-grounded · India-localized
            </Badge>
            <h1 className="mt-5 font-display text-4xl font-bold leading-[1.08] text-white sm:text-5xl lg:text-[3.4rem]">
              Turn your skills into your career path.
            </h1>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-ink-900 sm:text-lg">
              CareerCrosswalk connects your skills with the requirements employers actually seek —
              helping you find opportunities, map skill gaps, and explore a personalized
              learning path forward.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                to="/resume"
                className="inline-flex items-center justify-center gap-2 rounded-lg bg-crosswalk-500 px-6 py-3.5 text-sm font-semibold text-white transition-all hover:bg-crosswalk-400 hover:shadow-[0_0_15 px_rgba(58,110,240,0.3)]"
              >
                Analyze My Resume <ArrowRight size={16} />
              </Link>
              <Link
                to="/careers"
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/5 bg-white/5 px-6 py-3.5 text-sm font-semibold text-white transition-all hover:bg-white/10"
              >
                Explore Careers
              </Link>
            </div>
          </motion.div>

          {/* Dashboard preview */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="relative"
          >
            <div className="rounded-xl2 border border-white/5 bg-[#0b1020]/90 p-6 shadow-pop backdrop-blur-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 h-40 w-40 bg-crosswalk-500/10 rounded-full blur-3xl -z-10" />
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">Career Readiness</p>
                  <p className="mt-0.5 font-display text-sm font-semibold text-white">Alex Morgan</p>
                </div>
                <Badge tone="matched">+8 this month</Badge>
              </div>
              <div className="mt-4 flex items-center justify-center">
                <ReadinessRing value={78} size={140} />
              </div>
              <div className="mt-4 space-y-2 border-t border-white/5 pt-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-ink-905">Business Intelligence Analyst</span>
                  <span className="font-mono font-semibold text-matched">88%</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-ink-905">Software Developer</span>
                  <span className="font-mono font-semibold text-transfer">82%</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-7xl px-6 py-20 relative z-10">
        <p className="text-xs font-semibold uppercase tracking-widest text-crosswalk-450">How it works</p>
        <h2 className="mt-2 font-display text-2xl font-bold text-white sm:text-3xl">
          One continuous path, from resume to job-ready.
        </h2>

        <div className="relative mt-12">
          <div className="crosswalk-divider absolute left-0 right-0 top-6 hidden lg:block border-t border-dashed border-white/10" />
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-5">
            {steps.map((s, i) => (
              <div key={s.title} className="relative group">
                <div className="relative z-10 flex h-12 w-12 items-center justify-center rounded-full border-4 border-[#070a12] bg-[#101727] text-cyan-400 group-hover:text-white group-hover:bg-crosswalk-500 transition-colors shadow-lg">
                  <s.icon size={18} />
                </div>
                <p className="mt-4 font-mono text-xs text-ink-700/40">0{i + 1}</p>
                <h3 className="mt-1 font-display text-sm font-semibold text-white">{s.title}</h3>
                <p className="mt-1 text-xs text-ink-700/60 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why CareerCrosswalk */}
      <section className="border-y border-white/5 bg-[#0b1020]/30 py-20 relative z-10">
        <div className="mx-auto max-w-7xl px-6">
          <p className="text-xs font-semibold uppercase tracking-widest text-crosswalk-450">Why CareerCrosswalk</p>
          <h2 className="mt-2 font-display text-2xl font-bold text-white sm:text-3xl">
            Built to explain itself, not just impress you.
          </h2>
          <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-5">
            {features.map((f) => (
              <div key={f.title} className="rounded-xl2 border border-white/5 bg-[#101727]/80 p-5 hover:border-crosswalk-500/20 transition-all hover:translate-y-[-2px] duration-300">
                <f.icon className="text-cyan-400" size={20} />
                <h3 className="mt-3 font-display text-sm font-semibold text-white">{f.title}</h3>
                <p className="mt-1.5 text-xs leading-relaxed text-ink-750">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust section */}
      <section className="mx-auto max-w-7xl px-6 py-20 relative z-10">
        <div className="grid grid-cols-1 items-center gap-10 rounded-xl2 border border-white/5 bg-[#101727]/40 p-8 lg:grid-cols-2 lg:p-12">
          <div>
            <ShieldCheck className="text-crosswalk-450 animate-pulse" size={28} />
            <h2 className="mt-4 font-display text-2xl font-bold text-white">Grounded, not generative.</h2>
            <p className="mt-3 text-xs leading-relaxed text-ink-700/70">
              Recommendations are structured and grounded in realistic skill taxonomies,
              not free-form AI assumptions. We expose exact score breakdowns and alignment evidence
              so you can trust the direction.
            </p>
          </div>
          <div className="rounded-xl border border-white/5 bg-black/40 p-5 font-mono text-xs text-ink-700 space-y-1">
            <PipelineStep label="Resume Skills" />
            <PipelineArrow />
            <PipelineStep label="Skill Normalization" />
            <PipelineArrow />
            <PipelineStep label="Occupation Mapping" />
            <PipelineArrow />
            <PipelineStep label="Job Requirement Comparison" />
            <PipelineArrow />
            <PipelineStep label="Career Match" highlight />
          </div>
        </div>
      </section>

      <footer className="border-t border-white/5 py-8 text-center text-xs text-ink-700/40 relative z-10">
        CareerCrosswalk &middot; a hackathon prototype for Innovators Arena 2026, Team Neural Vanguard.
      </footer>
    </div>
  );
}

function PipelineStep({ label, highlight }: { label: string; highlight?: boolean }) {
  return (
    <div
      className={`rounded-md border px-3 py-2 text-center transition-all ${
        highlight
          ? "border-crosswalk-500 bg-crosswalk-500/20 text-crosswalk-400 font-bold shadow-[0_0_15px_rgba(58,110,240,0.15)]"
          : "border-white/5 bg-white/5 text-ink-850"
      }`}
    >
      {label}
    </div>
  );
}
function PipelineArrow() {
  return <div className="my-0.5 text-center text-ink-700/30">↓</div>;
}
