import { Link } from "react-router-dom";
import { Sparkles, Target, Milestone, ArrowUpRight, ArrowRight } from "lucide-react";
import { PageHeader } from "../components/shared/PageHeader";
import { StatCard } from "../components/shared/StatCard";
import { Card, Badge, EmptyState } from "../components/ui/primitives";
import { ReadinessRing } from "../components/shared/ReadinessScore";
import { CareerCard } from "../components/shared/CareerCard";
import { useAI } from "../components/ai/AIProvider";
import { useAnalysis } from "../hooks/useAnalysis";
import { useAppState } from "../components/app/AppStateProvider";

export default function Dashboard() {
  const { nextBestAction, setIsOpen, sendMessage } = useAI();
  const { profile } = useAppState();
  const { careers: analyzedCareers, skills: analyzedSkills, session, gaps: analyzedGaps, readiness } = useAnalysis();
  const visibleCareers = analyzedCareers ?? [];
  const visibleGaps = analyzedGaps ?? [];
  const currentReadiness = readiness ?? profile.careerReadiness;
  const strongMatches = visibleCareers.filter((c) => c.matchLabel === "Strong Match").length;
  const highPriorityGaps = session?.result.skill_gaps.length ?? 0;

  const handleAskAIAboutAction = async () => {
    if (!nextBestAction) return;
    setIsOpen(true);
    await sendMessage(`Help me understand how to fulfill: ${nextBestAction.title}. Reason: ${nextBestAction.reason}`);
  };

  return (
    <div>
      <PageHeader
        title={`Welcome, ${profile.name.split(" ")[0]} 👋`}
        subtitle="Here's your current career readiness overview."
      />

      {nextBestAction && (
        <div className="mb-6 rounded-xl2 border border-crosswalk-500/20 bg-[#0b1020]/65 p-4 backdrop-blur-sm relative overflow-hidden transition-all hover:border-crosswalk-500/30">
          <div className="absolute top-0 right-0 h-32 w-32 bg-crosswalk-500/10 rounded-full blur-2xl -z-10" />
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="flex h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse" />
                <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400">Next Best Action Recommended by AI</span>
                {nextBestAction.priority === "high" && (
                  <Badge tone="missing" className="text-[9px] px-1.5 py-0">Critical Priority</Badge>
                )}
              </div>
              <h3 className="text-sm font-semibold text-white mt-1">{nextBestAction.title}</h3>
              <p className="text-xs text-ink-700/60 max-w-3xl leading-relaxed">{nextBestAction.reason}</p>
            </div>
            <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
              <button
                onClick={handleAskAIAboutAction}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/5 bg-white/5 px-2.5 py-1.5 text-xs text-white hover:bg-white/10 transition-all font-medium"
              >
                <Sparkles size={11} className="text-cyan-400" /> Ask AI
              </button>
              <Link
                to={nextBestAction.actionPath}
                className="inline-flex items-center gap-1 rounded-lg bg-crosswalk-500 hover:bg-crosswalk-400 text-white px-2.5 py-1.5 text-xs font-semibold hover:shadow-lg transition-all"
              >
                {nextBestAction.action} <ArrowRight size={11} />
              </Link>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Career Readiness" value={`${Math.round(currentReadiness)}/100`} trend={session ? "From current job description" : "Upload a resume to calculate"} icon={<ArrowUpRight size={16} />} />
        <StatCard label="Skills Identified" value={analyzedSkills?.length ?? 0} sublabel={session ? "From current resume" : "No analysis yet"} icon={<Sparkles size={16} />} />
        <StatCard label="Career Matches" value={visibleCareers.length} sublabel={`${strongMatches} strong matches`} icon={<Target size={16} />} />
        <StatCard label="Skill Gaps" value={visibleGaps.length} sublabel={`${highPriorityGaps} high priority`} icon={<Milestone size={16} />} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-5">
        <Card className="p-6 lg:col-span-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">Career Readiness</p>
          <div className="mt-4 flex justify-center">
            <ReadinessRing value={currentReadiness} />
          </div>
          <p className="mt-4 border-t border-stone-150 pt-4 text-center text-xs text-ink-700/60">{session ? "Readiness is calculated from the uploaded resume and target job description." : "Upload a resume to calculate readiness."}</p>
        </Card>

        <Card className="p-6 lg:col-span-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">What to learn first</p>
            <Link to="/roadmap" className="flex items-center gap-1 text-xs font-medium text-crosswalk-600 hover:underline">
              Full roadmap <ArrowRight size={12} />
            </Link>
          </div>
          <div className="mt-4 space-y-3">
            {visibleGaps.length ? visibleGaps.map((g, index) => (
              <div key={"rank" in g ? g.rank : `${g.skill}-${index}`} className="flex items-start justify-between gap-3 rounded-lg border border-stone-150 p-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-ink-700/40">0{"rank" in g ? g.rank : index + 1}</span>
                    <span className="font-medium text-ink-900">{g.skill}</span>
                  </div>
                  <p className="mt-1 text-xs text-ink-700/60">{"reason" in g ? g.reason : "Derived from the current analysis."}</p>
                </div>
                <Badge tone="missing">GAP</Badge>
              </div>
            )) : <p className="text-sm text-ink-700/60">Upload a resume to generate learning priorities from the O*NET analysis.</p>}
          </div>
        </Card>
      </div>

      <div className="mt-8">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold text-ink-900">Recommended Career Paths</h2>
          <Link to="/careers" className="flex items-center gap-1 text-sm font-medium text-crosswalk-600 hover:underline">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        <div className="mt-4 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {visibleCareers.length ? visibleCareers.slice(0, 3).map((c) => (
            <CareerCard key={c.id} career={c} />
          )) : <EmptyState title="No career analysis yet" description="Upload a resume to get O*NET-grounded career paths." action={<Link to="/resume"><Badge tone="brand">Analyze resume</Badge></Link>} />}
        </div>
      </div>
    </div>
  );
}
