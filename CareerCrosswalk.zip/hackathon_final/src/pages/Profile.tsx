import { useState } from "react";
import { PageHeader } from "../components/shared/PageHeader";
import { Card, Badge, Button, Modal } from "../components/ui/primitives";
import { GraduationCap, MapPin, Briefcase } from "lucide-react";
import type { User } from "../types";
import { useAppState } from "../components/app/AppStateProvider";
import { useAnalysis } from "../hooks/useAnalysis";

const inputClass = "mt-1 w-full rounded-lg border border-stone-150 bg-surface-sunken px-3 py-2 text-sm text-ink-900 outline-none focus:border-crosswalk-500 focus:ring-1 focus:ring-crosswalk-500/50";

export default function Profile() {
  const { profile, updateProfile } = useAppState();
  const { skills: analyzedSkills, readiness } = useAnalysis();
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<User>(profile);

  const save = () => {
    updateProfile({
      ...draft,
      name: draft.name.trim() || "Your Profile",
      targetRoles: draft.targetRoles.map((role) => role.trim()).filter(Boolean),
      careerReadiness: readiness ?? draft.careerReadiness,
    });
    setOpen(false);
  };
  const initial = profile.name.split(" ").map((name) => name[0]).join("").slice(0, 2);

  return (
    <div>
      <PageHeader title="Profile" subtitle="Your locally saved preferences and career goals." />
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="p-6 lg:col-span-1">
          <div className="flex flex-col items-center text-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-ink-900 font-display text-2xl font-semibold text-white">{initial || "YP"}</div>
            <h2 className="mt-4 font-display text-lg font-semibold text-ink-900">{profile.name}</h2>
            <p className="text-sm text-ink-700/60">{profile.headline}</p>
          </div>
          <div className="mt-6 space-y-3 border-t border-stone-150 pt-5 text-sm">
            <div className="flex items-center gap-2 text-ink-700"><GraduationCap size={15} className="text-ink-700/40" /> {profile.education} · {profile.degree}</div>
            <div className="flex items-center gap-2 text-ink-700"><MapPin size={15} className="text-ink-700/40" /> {profile.preferredLocation}</div>
            <div className="flex items-center gap-2 text-ink-700"><Briefcase size={15} className="text-ink-700/40" /> {profile.preferredWork}</div>
          </div>
          <Button variant="outline" className="mt-6 w-full" onClick={() => { setDraft(profile); setOpen(true); }}>Edit Profile</Button>
        </Card>

        <div className="space-y-6 lg:col-span-2">
          <Card className="p-6">
            <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">Career Preferences</p>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div><p className="text-xs text-ink-700/50">Preferred Location</p><p className="mt-0.5 font-medium text-ink-900">{profile.preferredLocation}</p></div>
              <div><p className="text-xs text-ink-700/50">Preferred Work</p><p className="mt-0.5 font-medium text-ink-900">{profile.preferredWork}</p></div>
              <div className="sm:col-span-2">
                <p className="text-xs text-ink-700/50">Target Roles</p>
                {profile.targetRoles.length ? <div className="mt-1.5 flex flex-wrap gap-1.5">{profile.targetRoles.map((role) => <Badge key={role} tone="brand">{role}</Badge>)}</div> : <p className="mt-1 text-sm text-ink-700/60">Add target roles to personalize your profile.</p>}
              </div>
            </div>
          </Card>
          <Card className="p-6">
            <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">Skills Summary</p>
            {analyzedSkills ? <div className="mt-3 flex flex-wrap gap-1.5">{analyzedSkills.map((skill) => <span key={skill.id} className="rounded-full bg-surface-sunken px-2.5 py-1 text-xs text-ink-700">{skill.name}</span>)}</div> : <p className="mt-3 text-sm text-ink-700/60">Upload a resume to populate this section with real O*NET analysis results.</p>}
          </Card>
        </div>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Edit Profile">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <label className="text-sm text-ink-700">Name<input className={inputClass} value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} /></label>
          <label className="text-sm text-ink-700">Headline<input className={inputClass} value={draft.headline} onChange={(event) => setDraft({ ...draft, headline: event.target.value })} /></label>
          <label className="text-sm text-ink-700">Education<input className={inputClass} value={draft.education} onChange={(event) => setDraft({ ...draft, education: event.target.value })} /></label>
          <label className="text-sm text-ink-700">Degree / institution<input className={inputClass} value={draft.degree} onChange={(event) => setDraft({ ...draft, degree: event.target.value })} /></label>
          <label className="text-sm text-ink-700">Preferred location<input className={inputClass} value={draft.preferredLocation} onChange={(event) => setDraft({ ...draft, preferredLocation: event.target.value })} /></label>
          <label className="text-sm text-ink-700">Work preference<select className={inputClass} value={draft.preferredWork} onChange={(event) => setDraft({ ...draft, preferredWork: event.target.value as User["preferredWork"] })}><option>Remote</option><option>Hybrid</option><option>On-site</option></select></label>
          <label className="text-sm text-ink-700 sm:col-span-2">Target roles (comma-separated)<input className={inputClass} value={draft.targetRoles.join(", ")} onChange={(event) => setDraft({ ...draft, targetRoles: event.target.value.split(",") })} /></label>
        </div>
        <div className="mt-5 flex justify-end gap-2"><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save}>Save Profile</Button></div>
      </Modal>
    </div>
  );
}
