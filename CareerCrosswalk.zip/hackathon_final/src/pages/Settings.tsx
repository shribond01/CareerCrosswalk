import { PageHeader } from "../components/shared/PageHeader";
import { Card, Select } from "../components/ui/primitives";
import { PrivacyStatusCard } from "../components/privacy/PrivacyStatusCard";
import { Bell, Lock, Database, Palette, User } from "lucide-react";
import { useAppState } from "../components/app/AppStateProvider";

function Toggle({ checked, onChange }: { checked: boolean; onChange: (value: boolean) => void }) {
  return <button onClick={() => onChange(!checked)} className={`relative h-6 w-11 rounded-full transition-colors ${checked ? "bg-crosswalk-500" : "bg-stone-150"}`} aria-pressed={checked}><span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${checked ? "translate-x-5" : "translate-x-0.5"}`} /></button>;
}

const sections = [
  { icon: User, title: "Profile Settings", rows: [{ label: "Show profile to institutions", key: "profileVisible" as const }] },
  { icon: Bell, title: "Notification Preferences", rows: [{ label: "New job matches", key: "notifJobs" as const }, { label: "Roadmap reminders", key: "notifRoadmap" as const }] },
  { icon: Lock, title: "Privacy", rows: [{ label: "Allow anonymized data for market insights", key: "privacyAnon" as const }] },
  { icon: Database, title: "Data Management", rows: [{ label: "Keep resume on file for re-analysis", key: "keepResume" as const }] },
  { icon: Palette, title: "Layout", rows: [{ label: "Use compact layout", key: "compact" as const }] },
];

export default function Settings() {
  const { settings, updateSetting, theme, setTheme } = useAppState();
  return <div className="max-w-2xl">
    <PageHeader title="Settings" subtitle="Manage locally saved display, notification, and data preferences." />
    <div className="space-y-5">
      <PrivacyStatusCard storeResume={settings.keepResume} onStoreResumeChange={(value) => updateSetting("keepResume", value)} />
      <Card className="p-5"><div className="flex items-center gap-2"><Palette size={16} className="text-crosswalk-500" /><h3 className="font-display text-sm font-semibold text-ink-900">Color Theme</h3></div><div className="mt-3 flex items-center justify-between"><span className="text-sm text-ink-700">Application appearance</span><Select value={theme} onChange={(value) => setTheme(value as "dark" | "light")} options={[{ value: "dark", label: "Dark" }, { value: "light", label: "Light" }]} /></div></Card>
      {sections.map((section) => <Card key={section.title} className="p-5"><div className="flex items-center gap-2"><section.icon size={16} className="text-crosswalk-500" /><h3 className="font-display text-sm font-semibold text-ink-900">{section.title}</h3></div><div className="mt-3 divide-y divide-stone-150">{section.rows.map((row) => <div key={row.key} className="flex items-center justify-between py-3"><span className="text-sm text-ink-700">{row.label}</span><Toggle checked={settings[row.key]} onChange={(value) => updateSetting(row.key, value)} /></div>)}</div></Card>)}
    </div>
  </div>;
}
