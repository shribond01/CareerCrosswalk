import { useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { UploadCloud, FileText, CheckCircle2, ArrowRight, Sparkles } from "lucide-react";
import { PageHeader } from "../components/shared/PageHeader";
import { Card, Button, ErrorState } from "../components/ui/primitives";
import { ProcessingTimeline } from "../components/shared/RoadmapStep";
import { ConfidenceScore } from "../components/shared/EvidenceBadge";
import { analyzeResume, type ResumeAnalysisResult } from "../services/resumeService";
import type { ProcessingStep } from "../types";
import { useAI } from "../components/ai/AIProvider";
import { analysisStore } from "../services/analysisStore";

type Stage = "idle" | "processing" | "done" | "error";
const ACCEPTED_EXTENSIONS = new Set(["pdf", "docx", "txt", "md", "png", "jpg", "jpeg", "webp"]);
const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;

export default function ResumeUpload() {
  const { setIsOpen, sendMessage } = useAI();
  const [stage, setStage] = useState<Stage>("idle");
  const [dragOver, setDragOver] = useState(false);
  const [steps, setSteps] = useState<ProcessingStep[]>([]);
  const [result, setResult] = useState<ResumeAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [jobDescription, setJobDescription] = useState("");
  const [lastFile, setLastFile] = useState<File | null>(null);
  const navigate = useNavigate();

  const handleFile = useCallback(async (file: File) => {
    const extension = file.name.split(".").pop()?.toLowerCase() ?? "";
    if (!ACCEPTED_EXTENSIONS.has(extension)) {
      setError("Choose a PDF, DOCX, TXT, Markdown, PNG, JPG, JPEG, or WEBP resume.");
      setStage("error");
      return;
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      setError("This resume exceeds the 10 MB upload limit.");
      setStage("error");
      return;
    }
    setLastFile(file);
    setError(null);
    setStage("processing");
    analysisStore.clear();
    try {
      const r = await analyzeResume(file, jobDescription, setSteps);
      analysisStore.set(r.session);
      setResult(r);
      setStage("done");
    } catch (analysisError) {
      setError(analysisError instanceof Error ? analysisError.message : "Resume analysis failed.");
      setStage("error");
    }
  }, [jobDescription]);

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Analyze Your Resume" subtitle="Upload your resume and we'll build your career skill profile." />

      <AnimatePresence mode="wait">
        {stage === "idle" && (
          <motion.div key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <label
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={onDrop}
              className={`flex cursor-pointer flex-col items-center justify-center gap-3 rounded-xl2 border-2 border-dashed px-6 py-16 text-center transition-colors ${
                dragOver ? "border-crosswalk-500 bg-crosswalk-500/10" : "border-white/5 bg-[#0d1424]/10"
              }`}
            >
              <input
                type="file"
                className="hidden"
                accept=".pdf,.docx,.png,.jpg,.jpeg"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFile(file);
                }}
              />
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-crosswalk-500/10 text-crosswalk-500">
                <UploadCloud size={26} />
              </div>
              <p className="font-medium text-ink-900">Drag and drop your resume here</p>
              <p className="text-sm text-ink-700/60">or click to browse · PDF, DOCX, PNG, JPG</p>
              <p className="text-xs text-ink-700/40">Maximum file size: 10 MB</p>
            </label>
            <label className="mt-4 block text-sm font-medium text-ink-900">
              Target job description <span className="font-normal text-ink-700/60">(optional, for readiness and job-specific gaps)</span>
              <textarea
                value={jobDescription}
                onChange={(event) => setJobDescription(event.target.value)}
                onClick={(event) => event.stopPropagation()}
                rows={4}
                placeholder="Example: Python, SQL, FastAPI, Docker, PostgreSQL, machine learning"
                className="mt-2 w-full rounded-lg border border-stone-150 bg-surface-raised px-3 py-2 text-sm text-ink-900 outline-none placeholder:text-ink-700/40 focus:border-crosswalk-500 focus:ring-1 focus:ring-crosswalk-500/50"
              />
            </label>
          </motion.div>
        )}

        {stage === "processing" && (
          <motion.div key="processing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <Card className="p-8">
              <div className="flex items-center gap-3">
                <FileText className="text-crosswalk-500" size={20} />
                <p className="font-medium text-ink-900">Processing your resume…</p>
              </div>
              <div className="mt-6">
                <ProcessingTimeline steps={steps} />
              </div>
            </Card>
          </motion.div>
        )}

        {stage === "done" && result && (
          <motion.div key="done" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <Card className="p-6">
                <div className="flex items-center gap-2 text-matched">
                  <CheckCircle2 size={20} />
                  <h3 className="font-display text-lg font-semibold text-ink-900">Resume Successfully Analyzed</h3>
                </div>
                <p className="mt-2 text-xs font-medium uppercase tracking-wide text-ink-700/60">
                  REAL ANALYSIS · O*NET + WorkforcePipeline
                </p>
              <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
                {result.sections.map((s) => (
                  <div key={s.name} className="flex items-center gap-1.5 text-sm text-ink-700">
                    <CheckCircle2 size={14} className="text-matched shrink-0" /> {s.name}
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6">
              <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">Skills Detected</p>
              {result.detectedSkills.length === 0 ? (
                <p className="mt-3 text-sm text-ink-700/70">The resume text was extracted, but no skills matched the scoped O*NET workplace software catalogue. Try a resume that explicitly names tools or technologies.</p>
              ) : <div className="mt-3 space-y-2">
                {result.detectedSkills.map((s) => (
                  <div key={s.name} className="flex items-center justify-between rounded-lg bg-surface-sunken px-3 py-2">
                    <span className="text-sm font-medium text-ink-900">{s.name}</span>
                    <ConfidenceScore value={s.confidence} />
                  </div>
                ))}
              </div>}
            </Card>

            {/* AI Resume Critiquer Widget */}
            <Card className="p-4 border-crosswalk-500/10 bg-[#0d1424]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="mt-0.5 rounded-lg bg-crosswalk-500/10 p-2 text-cyan-400 border border-crosswalk-500/20">
                  <Sparkles size={16} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400">AI Resume Critiquer</span>
                  </div>
                  <p className="mt-1 text-xs text-ink-700/60 max-w-xl leading-relaxed">
                    {result.session.result.career_paths[0]
                      ? `Ask for resume keywords and projects relevant to ${result.session.result.career_paths[0].occupation}.`
                      : "Ask for ways to make the skills in your resume more explicit and measurable."}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsOpen(true);
                  sendMessage("Critique my uploaded resume keywords using the current O*NET analysis context.");
                }}
                className="shrink-0 text-xs text-crosswalk-450 hover:text-crosswalk-300 font-semibold bg-white/5 border border-white/5 rounded-lg px-3 py-1.5 hover:bg-white/10 transition-colors"
                type="button"
              >
                Critique Keywords →
              </button>
            </Card>

            <Button className="w-full" size="lg" onClick={() => navigate("/skills")}>
              Build My Skill Profile <ArrowRight size={16} />
            </Button>
          </motion.div>
        )}

        {stage === "error" && (
          <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <ErrorState message={error ?? "Resume analysis failed."} />
            <div className="mt-4 flex justify-center gap-3">
              {lastFile && <Button onClick={() => handleFile(lastFile)}>Try Again</Button>}
              <Button variant="outline" onClick={() => { setStage("idle"); setError(null); }}>Choose Another File</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
