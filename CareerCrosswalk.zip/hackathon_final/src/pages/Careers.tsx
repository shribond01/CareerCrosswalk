import { useMemo, useState } from "react";
import { PageHeader } from "../components/shared/PageHeader";
import { CareerCard } from "../components/shared/CareerCard";
import { Select } from "../components/ui/primitives";
import { EmptyState } from "../components/ui/primitives";
import { useAnalysis } from "../hooks/useAnalysis";
import { Link } from "react-router-dom";

export default function Careers() {
  const { careers: analyzedCareers, isReal } = useAnalysis();
  const visibleCareers = analyzedCareers ?? [];
  const domains = ["All Domains", ...Array.from(new Set(visibleCareers.map((c) => c.domain)))];
  const [domain, setDomain] = useState("All Domains");
  const [sort, setSort] = useState("match");

  const filtered = useMemo(() => {
    let list = domain === "All Domains" ? visibleCareers : visibleCareers.filter((c) => c.domain === domain);
    list = [...list].sort((a, b) => (sort === "match" ? b.matchPercent - a.matchPercent : a.title.localeCompare(b.title)));
    return list;
  }, [domain, sort, visibleCareers]);

  return (
    <div>
      <PageHeader
        title="Career Matches"
        subtitle="Ranked against your current skill profile, using O*NET occupational requirements."
        action={
          <div className="flex gap-2">
            <Select value={domain} onChange={setDomain} options={domains.map((d) => ({ label: d, value: d }))} />
            <Select
              value={sort}
              onChange={setSort}
              options={[
                { label: "Sort: Best match", value: "match" },
                { label: "Sort: A–Z", value: "alpha" },
              ]}
            />
          </div>
        }
      />
      {isReal && <p className="mb-4 text-xs font-medium uppercase tracking-wide text-crosswalk-500">REAL ANALYSIS · WOS WorkforcePipeline</p>}

      {!isReal ? (
        <EmptyState title="No career analysis yet" description="Upload a resume to receive career paths from the real O*NET-backed pipeline." action={<Link to="/resume" className="text-sm font-medium text-crosswalk-500 hover:underline">Analyze resume</Link>} />
      ) : filtered.length === 0 ? (
        <EmptyState title="No careers match this filter" description="Try a different domain or upload a resume with explicit technologies." />
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((c) => (
            <CareerCard key={c.id} career={c} />
          ))}
        </div>
      )}
    </div>
  );
}
