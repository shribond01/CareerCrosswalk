import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeft, TrendingUp, IndianRupee, Sparkles } from "lucide-react";
import { PageHeader } from "../components/shared/PageHeader";
import { Card, Badge, ProgressBar, Button } from "../components/ui/primitives";
import { GapBadge } from "../components/shared/EvidenceBadge";
import { CareerCard } from "../components/shared/CareerCard";
import { getCareer, getGroundedExplanation, searchSimilarRoles } from "../services/careerService";
import type { Career } from "../types";
import { LoadingState, ErrorState } from "../components/ui/primitives";
import { useAI } from "../components/ai/AIProvider";
import { useAnalysis } from "../hooks/useAnalysis";
import { ResumeEvidence } from "../components/shared/ResumeEvidence";

export default function CareerDetail() {
  const { setIsOpen, sendMessage } = useAI();
  const { id } = useParams();
  const { careers: analyzedCareers, session, evidence } = useAnalysis();
  const [career, setCareer] = useState<Career | null | undefined>(undefined);
  const [explanation, setExplanation] = useState("");
  const [similar, setSimilar] = useState<Career[]>([]);

  useEffect(() => {
    if (!id) return;
    if (analyzedCareers) {
      const analyzedCareer = analyzedCareers.find((item) => item.id === id);
      setCareer(analyzedCareer ?? null);
      setExplanation(analyzedCareer ? `This WOS career path overlaps with ${analyzedCareer.matchingSkills.length} analyzed skills.` : "");
      setSimilar([]);
      return;
    }
    setCareer(undefined);
    getCareer(id).then((c) => setCareer(c ?? null));
    getGroundedExplanation(id).then(setExplanation);
    searchSimilarRoles(id).then(setSimilar);
  }, [id, analyzedCareers]);

  if (career === undefined) return <LoadingState label="Loading career details" />;
  if (career === null) return <ErrorState message="We couldn't find this career." />;

  return (
    <div>
      <Link to="/careers" className="mb-4 inline-flex items-center gap-1.5 text-sm text-ink-700/60 hover:text-ink-900 border-b border-transparent hover:border-ink-750/30 pb-0.5 transition-all">
        <ArrowLeft size={14} /> Back to Career Matches
      </Link>

      <PageHeader
        title={career.title}
        subtitle={`${career.domain} · SOC ${career.socCode}`}
        action={
          <div className="text-right">
            <div className="font-mono text-3xl font-bold text-ink-900">{career.matchPercent}%</div>
            <Badge tone={career.matchLabel === "Strong Match" ? "matched" : career.matchLabel === "Good Match" ? "transfer" : "partial"}>
              {career.matchLabel}
            </Badge>
          </div>
        }
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card className="p-6">
            <p className="text-sm leading-relaxed text-ink-700">{career.description}</p>
            <div className="mt-4 flex flex-wrap gap-4 text-sm text-ink-700/70">
              <span className="flex items-center gap-1.5">
                <IndianRupee size={14} /> {career.medianSalaryINR}
              </span>
              <span className="flex items-center gap-1.5">
                <TrendingUp size={14} /> Demand {career.demandTrend.toLowerCase()}
              </span>
            </div>
          </Card>

          {session && evidence && <ResumeEvidence text={session.resumeText} evidence={evidence} />}
          <Card className="p-6">
            <h2 className="font-display text-lg font-semibold text-ink-900">Why this career matches you</h2>
            <p className="mt-1.5 text-sm text-ink-700/70">{explanation}</p>

            <div className="mt-5 space-y-3">
              {career.skillBreakdown.map((s) => (
                <div key={s.skill} className="flex items-center justify-between rounded-lg border border-white/5 bg-[#0d1424]/20 p-3">
                  <div>
                    <p className="font-medium text-ink-900">{s.skill}</p>
                    {s.note && <p className="mt-0.5 text-xs text-ink-700/50">{s.note}</p>}
                    {s.transferableFrom && (
                      <p className="mt-0.5 text-xs text-transfer">Transferable from {s.transferableFrom}</p>
                    )}
                  </div>
                  <GapBadge status={s.status} />
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="mb-2 font-display text-sm font-semibold text-ink-900">How this recommendation was generated</h2>
            <div className="grid grid-cols-1 gap-2 font-mono text-xs text-ink-700 sm:grid-cols-5 sm:gap-0">
              {["Resume Skills", "Normalization", "Occupation Mapping", "Requirement Comparison", "Career Match"].map((step, i, arr) => (
                <div key={step} className="flex items-center gap-2 sm:flex-col sm:text-center">
                  <div
                    className={`w-full rounded-md border px-2 py-2 ${
                      i === arr.length - 1 ? "border-crosswalk-500 bg-crosswalk-500/10 text-crosswalk-400 font-semibold" : "border-white/5 bg-surface-sunken"
                    }`}
                  >
                    {step}
                  </div>
                  {i < arr.length - 1 && <span className="text-ink-700/30 sm:hidden">→</span>}
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="p-5">
            <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">Match strength</p>
            <ProgressBar value={career.matchPercent} className="mt-3" height="h-2.5" />
            <p className="mt-2 text-right font-mono text-sm font-semibold text-ink-900">{career.matchPercent}%</p>
            <Link to="/skill-gap">
              <Button variant="outline" className="mt-4 w-full">
                See full skill gap
              </Button>
            </Link>
          </Card>

          <Card className="p-4 border-crosswalk-500/10 bg-[#0d1424]/40">
            <div className="flex items-center gap-2 text-cyan-400 mb-2">
              <Sparkles size={14} />
              <span className="text-[10px] font-bold uppercase tracking-wider">AI Assistant Insights</span>
            </div>
            <p className="text-xs text-ink-700/60 leading-relaxed font-sans">
              To reach 100% readiness for {career.title}, prioritize SQL evidence logging and initiate the Power BI learning roadmap module.
            </p>
            <button
              onClick={() => {
                setIsOpen(true);
                sendMessage(`How can I reach 100% match readiness for ${career.title}?`);
              }}
              className="mt-3 w-full text-center text-xs text-crosswalk-450 hover:text-crosswalk-300 font-semibold bg-white/5 border border-white/5 rounded-lg py-1.5 hover:bg-white/10 transition-colors"
            >
              Analyze Readiness Path →
            </button>
          </Card>

          {similar.length > 0 && (
            <div>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-ink-700/50">Similar roles</p>
              <div className="space-y-4">
                {similar.slice(0, 2).map((c) => (
                  <CareerCard key={c.id} career={c} />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
