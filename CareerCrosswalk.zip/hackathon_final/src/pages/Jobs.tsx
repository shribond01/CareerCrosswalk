import { useEffect, useState } from "react";
import { Search, Sparkles } from "lucide-react";
import { PageHeader } from "../components/shared/PageHeader";
import { JobCard } from "../components/shared/JobCard";
import { Select, EmptyState, LoadingState, Badge, Card } from "../components/ui/primitives";
import { getJobs } from "../services/jobService";
import { jobLocations, jobTypes, jobExperience } from "../data/jobs";
import type { Job } from "../types";
import { useAI } from "../components/ai/AIProvider";

export default function Jobs() {
  const { setIsOpen, sendMessage } = useAI();
  const [jobsList, setJobsList] = useState<Job[] | null>(null);
  const [location, setLocation] = useState("All Locations");
  const [jobType, setJobType] = useState("All Types");
  const [experience, setExperience] = useState("All Experience");
  const [query, setQuery] = useState("");

  useEffect(() => {
    setJobsList(null);
    getJobs({
      location: location === "All Locations" ? undefined : location,
      jobType: jobType === "All Types" ? undefined : jobType,
      experience: experience === "All Experience" ? undefined : experience,
      query: query || undefined,
    }).then(setJobsList);
  }, [location, jobType, experience, query]);

  return (
    <div>
      <PageHeader
        title="Job Opportunities"
        subtitle="Matched to your skill profile. Demo data — not a live feed."
        action={<Badge tone="partial">Demo data</Badge>}
      />

      {/* AI Job Optimizer Widget */}
      <Card className="p-4 border-crosswalk-500/10 bg-[#0d1424]/40 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="mt-0.5 rounded-lg bg-crosswalk-500/10 p-2 text-cyan-400 border border-crosswalk-500/20">
            <Sparkles size={16} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400">AI Job Matcher</span>
            </div>
            <p className="mt-1 text-xs text-ink-700/60 max-w-2xl leading-relaxed">
              Find out which target roles match your resume best. AI detects missing technical tags like Docker/Kubernetes.
            </p>
          </div>
        </div>
        <button
          onClick={() => {
            setIsOpen(true);
            sendMessage("What credentials or resume updates do I need to land Chennai-based Data Analyst positions?");
          }}
          className="shrink-0 text-xs text-crosswalk-450 hover:text-crosswalk-300 font-semibold bg-white/5 border border-white/5 rounded-lg px-3 py-1.5 hover:bg-white/10 transition-colors"
        >
          Check Job Match details →
        </button>
      </Card>

      <div className="flex flex-col gap-3 rounded-xl2 border border-white/5 bg-[#0d1424]/20 p-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-700/40" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search job titles…"
            className="w-full bg-black/25 text-white rounded-lg border border-white/5 py-2 pl-9 pr-3 text-sm focus:border-crosswalk-500/50 outline-none focus:ring-1 focus:ring-crosswalk-500/30"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={location} onChange={setLocation} options={["All Locations", ...jobLocations].map((l) => ({ label: l, value: l }))} />
          <Select value={jobType} onChange={setJobType} options={["All Types", ...jobTypes].map((l) => ({ label: l, value: l }))} />
          <Select value={experience} onChange={setExperience} options={["All Experience", ...jobExperience].map((l) => ({ label: l, value: l }))} />
        </div>
      </div>

      <div className="mt-6">
        {jobsList === null ? (
          <LoadingState label="Finding jobs" />
        ) : jobsList.length === 0 ? (
          <EmptyState title="No jobs found" description="Try widening your filters." />
        ) : (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {jobsList.map((j) => (
              <JobCard key={j.id} job={j} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
