import { useState } from "react";
import { PageHeader } from "../components/shared/PageHeader";
import { StatCard } from "../components/shared/StatCard";
import { SkillCard, SkillDetailPanel } from "../components/shared/SkillCard";
import { Sparkles } from "lucide-react";
import { useAI } from "../components/ai/AIProvider";
import { useAnalysis } from "../hooks/useAnalysis";
import { Card, Badge } from "../components/ui/primitives";
import { EmptyState } from "../components/ui/primitives";
import { Link } from "react-router-dom";

export default function Skills() {
  const { setIsOpen, sendMessage } = useAI();
  const { skills: analyzedSkills, isReal } = useAnalysis();
  const visibleSkills = analyzedSkills ?? [];
  const visibleSummary = analyzedSkills
    ? {
        total: visibleSkills.length,
        verified: visibleSkills.filter((s) => s.status === "verified").length,
        developing: visibleSkills.filter((s) => s.status === "developing").length,
      }
    : { total: 0, verified: 0, developing: 0 };
  const visibleCategories = Array.from(new Set(visibleSkills.map((skill) => skill.category)));
  const [activeId, setActiveId] = useState(visibleSkills[0]?.id);
  const active = visibleSkills.find((s) => s.id === activeId) ?? visibleSkills[0];

  return (
    <div>
      <PageHeader title="My Skills" subtitle="Every skill, tagged with proficiency, confidence, and the evidence behind it." />
      {isReal && <p className="mb-4 text-xs font-medium uppercase tracking-wide text-crosswalk-500">REAL ANALYSIS · WOS WorkforcePipeline</p>}

      {!isReal && <EmptyState title="Upload a resume to build your skill profile" description="Skills on this page are shown only after real O*NET analysis." action={<Link to="/resume"><Badge tone="brand">Analyze resume</Badge></Link>} />}

      {isReal && <>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard label="Skills Identified" value={visibleSummary.total} />
        <StatCard label="Verified" value={visibleSummary.verified} className="border-matched/20" />
        <StatCard label="Developing" value={visibleSummary.developing} />
      </div>

      {/* AI Contextual Widget */}
      <Card className="p-4 border-crosswalk-500/10 bg-[#0d1424]/40 mt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="mt-0.5 rounded-lg bg-crosswalk-500/10 p-2 text-cyan-400 border border-crosswalk-500/20">
            <Sparkles size={16} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400">AI Skill Indexer</span>
              <Badge tone="brand" className="text-[9px] px-1.5 py-0">Analysis context</Badge>
            </div>
            <p className="mt-1 text-xs text-ink-700/60 max-w-3xl">
              {active ? `Your ${active.name} skill is evaluated with ${active.confidence}% confidence. Need to boost this? Add a Github project in evidence or log an active certificate.` : "Select a skill to analyze its relative gap impact."}
            </p>
          </div>
        </div>
        {active && (
          <button
            onClick={() => {
              setIsOpen(true);
              sendMessage(`Design a study path to take my ${active.name} skill to ${active.proficiency === 'Advanced' ? 'expert' : 'advanced'} level.`);
            }}
            className="shrink-0 text-xs text-crosswalk-450 hover:text-crosswalk-300 font-semibold flex items-center gap-1 self-end sm:self-center bg-white/5 border border-white/5 rounded-lg px-3 py-1.5 hover:bg-white/10 transition-colors"
          >
            Plan {active.name} Path →
          </button>
        )}
      </Card>

      <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-3">
        <div className="space-y-8 lg:col-span-2">
          {visibleCategories.map((cat) => (
            <div key={cat}>
              <h2 className="mb-3 font-display text-base font-semibold text-ink-900">{cat}</h2>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {visibleSkills
                  .filter((s) => s.category === cat)
                  .map((s) => (
                    <SkillCard key={s.id} skill={s} active={s.id === active?.id} onClick={() => setActiveId(s.id)} />
                  ))}
              </div>
            </div>
          ))}
        </div>

        <div className="lg:sticky lg:top-6 lg:self-start">
          {active && <SkillDetailPanel skill={active} />}
        </div>
      </div>
      </>}
    </div>
  );
}
