import { useState } from "react";
import { PageHeader } from "../components/shared/PageHeader";
import { Card, Select, Button } from "../components/ui/primitives";
import { GapBadge } from "../components/shared/EvidenceBadge";
import { ReadinessRing } from "../components/shared/ReadinessScore";
import { careers } from "../data/careers";
import { skillGapBreakdown, priorityGaps } from "../data/roadmap";
import { Link } from "react-router-dom";
import { ArrowRight, Sparkles } from "lucide-react";
import { useAI } from "../components/ai/AIProvider";
import { useAnalysis } from "../hooks/useAnalysis";

export default function SkillGap() {
  const { setIsOpen, sendMessage } = useAI();
  const { careers: analyzedCareers, gaps: analyzedGaps, session, isReal } = useAnalysis();
  const visibleCareers = analyzedCareers ?? careers;
  const visibleGaps = analyzedGaps ?? skillGapBreakdown;
  const visiblePriorities = session
    ? session.result.skill_gaps.map((gap, index) => ({ rank: index + 1, skill: gap.skill, priority: "HIGH" as const, reason: gap.reason }))
    : priorityGaps;
  const [careerId, setCareerId] = useState(careers[0].id);
  const selectedCareerId = visibleCareers.some((item) => item.id === careerId) ? careerId : visibleCareers[0]?.id;
  const career = visibleCareers.find((c) => c.id === selectedCareerId) ?? visibleCareers[0];

  return (
    <div>
      <PageHeader title="Skill Gap Analysis" subtitle="See exactly what stands between you and your target career." />
      {isReal && <p className="mb-4 text-xs font-medium uppercase tracking-wide text-crosswalk-500">REAL ANALYSIS · WOS WorkforcePipeline</p>}

      <Card className="p-5">
        <label className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">Target Career</label>
        <div className="mt-2 max-w-xs">
          <Select
            value={selectedCareerId}
            onChange={setCareerId}
            options={visibleCareers.map((c) => ({ label: c.title, value: c.id }))}
            className="w-full"
          />
        </div>
      </Card>

      {/* AI Gap Analyzer Widget */}
      <Card className="p-4 border-crosswalk-500/10 bg-[#0d1424]/40 mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="mt-0.5 rounded-lg bg-crosswalk-500/10 p-2 text-cyan-400 border border-crosswalk-500/20">
            <Sparkles size={16} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400">AI Gap Analyzer</span>
            </div>
            <p className="mt-1 text-xs text-ink-700/60 max-w-2xl leading-relaxed">
              Comparing your skills to {career.title}. Power BI represents your primary gap, followed by Advanced SQL modules.
            </p>
          </div>
        </div>
        <button
          onClick={() => {
            setIsOpen(true);
            sendMessage(`Create a customized 30-day plan to bridge my skill gaps for the ${career.title} career path`);
          }}
          className="shrink-0 text-xs text-crosswalk-450 hover:text-crosswalk-300 font-semibold bg-white/5 border border-white/5 rounded-lg px-3 py-1.5 hover:bg-white/10 transition-colors"
        >
          Draft 30-Day Plan →
        </button>
      </Card>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="flex flex-col items-center justify-center p-6 text-center">
          <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">Job Readiness</p>
          <div className="mt-3">
            <ReadinessRing value={career.matchPercent} size={130} />
          </div>
          <p className="mt-2 text-sm text-ink-700/60">for {career.title}</p>
        </Card>

        <Card className="p-6 lg:col-span-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">Skill Breakdown</p>
          <div className="mt-4 space-y-3">
            {visibleGaps.map((s) => (
              <div key={s.skill}>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <span className="font-medium text-ink-900">{s.skill}</span>
                  <span className="font-mono text-ink-700/60">{s.currentPercent}%</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-surface-sunken">
                  <div
                    className={`h-full rounded-full ${
                      s.status === "matched" ? "bg-matched" : s.status === "partial" ? "bg-partial" : s.status === "transferable" ? "bg-transfer" : "bg-missing"
                    }`}
                    style={{ width: `${s.currentPercent}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="mt-6 p-6">
        <p className="text-xs font-semibold uppercase tracking-wide text-ink-700/50">Gap Classification</p>
        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
          {visibleGaps.map((s) => (
            <div key={s.skill} className="flex items-center justify-between rounded-lg border border-stone-150 p-3">
              <div>
                <p className="font-medium text-ink-900">{s.skill}</p>
                {s.transferableFrom && <p className="text-xs text-transfer">↗ {s.transferableFrom} → {s.skill} transferable</p>}
              </div>
              <GapBadge status={s.status} />
            </div>
          ))}
        </div>
      </Card>

      <div className="mt-6">
        <h2 className="font-display text-lg font-semibold text-ink-900">What Should You Learn First?</h2>
        <div className="mt-4 space-y-3">
          {visiblePriorities.map((g) => (
            <Card key={g.rank} className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3">
                <span className="font-mono text-lg font-bold text-ink-700/30">{String(g.rank).padStart(2, "0")}</span>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-medium text-ink-900">{g.skill}</h3>
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                        g.priority === "HIGH" ? "bg-missing-bg text-missing" : g.priority === "MEDIUM" ? "bg-partial-bg text-partial" : "bg-surface-sunken text-ink-700/60"
                      }`}
                    >
                      {g.priority}
                    </span>
                  </div>
                  <p className="mt-0.5 text-sm text-ink-700/60">{g.reason}</p>
                </div>
              </div>
              <Link to="/roadmap">
                <Button variant="outline" size="sm">
                  Start Learning <ArrowRight size={13} />
                </Button>
              </Link>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
