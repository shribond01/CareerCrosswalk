import { Link } from "react-router-dom";
import { Button } from "../components/ui/primitives";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-surface text-center px-6">
      <span className="font-display text-6xl font-bold text-ink-900">404</span>
      <p className="text-ink-700/60">This page doesn't exist yet.</p>
      <Link to="/dashboard">
        <Button>Back to Dashboard</Button>
      </Link>
    </div>
  );
}
