export type ClientPiiKind = "email" | "phone" | "address" | "personal-id";

const patterns: Array<{ kind: ClientPiiKind; pattern: RegExp; replacement: string }> = [
  { kind: "email", pattern: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi, replacement: "[EMAIL REDACTED]" },
  { kind: "phone", pattern: /(?<!\w)(?:\+?\d[\d .()\-]{7,}\d)(?!\w)/g, replacement: "[PHONE REDACTED]" },
  { kind: "personal-id", pattern: /\b(?:SSN|social security|aadhaar|passport|national id)\s*[:#-]?\s*[A-Z0-9 -]{4,}\b/gi, replacement: "[PERSONAL ID REDACTED]" },
  { kind: "address", pattern: /\b(?:address|resides at|street|road|avenue|apt\.?|suite)\s*[:#-]?\s*[^\n]{5,100}/gi, replacement: "[ADDRESS REDACTED]" },
];

/** Client-side defense-in-depth for outbound AI context; this is not a security scanner. */
export function minimizePiiForExternalModel(text: string): string {
  return patterns.reduce(
    (value, { pattern, replacement }) => value.replace(pattern, replacement),
    text,
  );
}
