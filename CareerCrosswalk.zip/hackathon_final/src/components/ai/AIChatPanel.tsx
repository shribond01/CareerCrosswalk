import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAI } from "./AIProvider";
import { Send, X, Trash2, Copy, Check, Sparkles, ArrowRight } from "lucide-react";
import { cn } from "../../lib/utils";

export function AIChatPanel() {
  const {
    messages,
    isOpen,
    setIsOpen,
    loading,
    error,
    sendMessage,
    clearConversation,
    getSuggestedPrompts,
  } = useAI();

  const navigate = useNavigate();
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen, loading]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;
    const textToSend = input;
    setInput("");
    await sendMessage(textToSend);
  };

  const handlePromptClick = async (prompt: string) => {
    if (loading) return;
    await sendMessage(prompt);
  };

  return (
    <div
      className={cn(
        "fixed right-0 z-50 flex flex-col border border-white/5 bg-[#0b1020]/95 backdrop-blur-md shadow-2xl transition-all duration-300",
        // Desktop: floating side panel
        "md:bottom-6 md:right-6 md:top-auto md:h-[600px] md:w-[420px] md:rounded-2xl",
        // Mobile: full bottom sheet
        "bottom-0 left-0 right-0 top-16 h-auto w-full rounded-t-2xl md:top-auto"
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/5 px-4 py-3 bg-[#0d152c]">
        <div className="flex items-center gap-2">
          <div className="relative">
            <span className="flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
          </div>
          <div>
            <h3 className="font-display font-semibold text-sm text-white">Career Intelligence Assistant</h3>
            <p className="text-[10px] text-ink-700/60 uppercase tracking-wider font-medium">Server-side AI chat</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          {messages.length > 0 && (
            <button
              onClick={clearConversation}
              title="Clear Conversation"
              className="rounded-lg p-1.5 text-ink-700/60 hover:bg-white/5 hover:text-white transition-colors"
            >
              <Trash2 size={15} />
            </button>
          )}
          <button
            onClick={() => setIsOpen(false)}
            className="rounded-lg p-1.5 text-ink-700/60 hover:bg-white/5 hover:text-white transition-colors"
          >
            <X size={16} />
          </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-6 space-y-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-crosswalk-500/10 text-crosswalk-450 border border-crosswalk-500/20 shadow-[0_0_15px_rgba(58,110,240,0.15)] animate-pulse">
              <Sparkles size={20} />
            </div>
            <h4 className="font-display font-medium text-sm text-white">Welcome to your Career Command Center</h4>
            <p className="text-xs text-ink-700/60 max-w-[280px]">
              Ask me about your skill gaps, customized learning paths, resume keywords, target jobs, or career alignment.
            </p>
          </div>
        ) : (
          messages.map((m) => (
            <div
              key={m.id}
              className={cn(
                "flex max-w-[85%] flex-col rounded-2xl px-4 py-2.5 text-sm",
                m.role === "user"
                  ? "ml-auto bg-crosswalk-500 text-white rounded-br-none"
                  : "bg-surface-raised border border-white/5 text-ink-900 rounded-bl-none"
              )}
            >
              {m.role === "assistant" ? (
                <div className="space-y-1 font-sans">
                  {formatMessageContent(m.content, navigate)}
                </div>
              ) : (
                <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>
              )}
            </div>
          ))
        )}

        {/* Loading State */}
        {loading && (
          <div className="flex max-w-[85%] bg-surface-raised border border-white/5 rounded-2xl rounded-bl-none px-4 py-3 space-x-1 items-center">
            <span className="h-1.5 w-1.5 rounded-full bg-crosswalk-450 animate-bounce" style={{ animationDelay: "0ms" }} />
            <span className="h-1.5 w-1.5 rounded-full bg-crosswalk-450 animate-bounce" style={{ animationDelay: "150ms" }} />
            <span className="h-1.5 w-1.5 rounded-full bg-crosswalk-450 animate-bounce" style={{ animationDelay: "300ms" }} />
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="rounded-xl border border-red-500/20 bg-red-500/10 p-3 text-xs text-red-400">
            {error}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompts */}
      {!loading && getSuggestedPrompts().length > 0 && (
        <div className="px-4 py-2 border-t border-white/5 bg-black/10">
          <p className="text-[10px] uppercase font-bold text-ink-700/40 tracking-wider mb-1.5">Suggested Prompts</p>
          <div className="flex flex-wrap gap-1.5 max-h-[85px] overflow-y-auto scrollbar-none py-0.5">
            {getSuggestedPrompts().map((p) => (
              <button
                key={p}
                onClick={() => handlePromptClick(p)}
                className="text-[11px] font-medium text-ink-750 bg-white/5 hover:bg-crosswalk-500/10 hover:text-white border border-white/5 hover:border-crosswalk-500/20 rounded-full px-2.5 py-1 text-left transition-colors whitespace-nowrap"
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="border-t border-white/5 p-3 flex gap-2 bg-[#0c1224]">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about your careers or skill gaps..."
          disabled={loading}
          className="flex-1 bg-surface-sunken border border-white/5 rounded-lg px-3 py-2 text-sm text-white placeholder-ink-700/40 focus:border-crosswalk-500/50 outline-none focus:ring-1 focus:ring-crosswalk-500/30"
        />
        <button
          type="submit"
          disabled={!input.trim() || loading}
          className="flex items-center justify-center h-9 w-9 rounded-lg bg-crosswalk-500 hover:bg-crosswalk-400 text-white disabled:bg-white/5 disabled:text-ink-700/40 transition-colors shadow-[0_0_10px_rgba(58,110,240,0.1)]"
        >
          <Send size={15} />
        </button>
      </form>
    </div>
  );
}

// ------ Helper for Markdown and Inline styles ------

function formatMessageContent(content: string, navigate: (p: string) => void) {
  const blocks = content.split("```");
  return blocks.map((block, index) => {
    const isCode = index % 2 === 1;
    if (isCode) {
      const lines = block.split("\n");
      const firstLine = lines[0].trim();
      const hasLang = /^[a-zA-Z0-9_-]+$/.test(firstLine);
      const codeText = hasLang ? lines.slice(1).join("\n") : block;
      return <CodeBlock key={index} code={codeText} language={hasLang ? firstLine : undefined} />;
    }

    const lines = block.split("\n");
    return lines.map((line, lineIndex) => {
      if (line.trim().startsWith("###")) {
        const text = line.trim().replace(/^###\s*/, "");
        return (
          <h4 key={lineIndex} className="font-display font-medium text-xs text-cyan-400 mt-3 mb-1 uppercase tracking-wider">
            {parseInlineStyles(text, navigate)}
          </h4>
        );
      }
      if (line.trim().startsWith("##")) {
        const text = line.trim().replace(/^##\s*/, "");
        return (
          <h3 key={lineIndex} className="font-display font-semibold text-sm text-white mt-4 mb-1 border-b border-white/5 pb-1">
            {parseInlineStyles(text, navigate)}
          </h3>
        );
      }

      if (line.trim().startsWith("- ") || line.trim().startsWith("* ")) {
        const text = line.trim().replace(/^[-*]\s*/, "");
        return (
          <li key={lineIndex} className="ml-3 list-disc text-ink-900 text-xs leading-relaxed mb-0.5">
            {parseInlineStyles(text, navigate)}
          </li>
        );
      }

      if (line.trim() === "") {
        return <div key={lineIndex} className="h-1.5" />;
      }

      return (
        <p key={lineIndex} className="text-ink-900 text-xs leading-relaxed mb-1.5">
          {parseInlineStyles(line, navigate)}
        </p>
      );
    });
  });
}

function parseInlineStyles(text: string, navigate: (p: string) => void) {
  const boldParts = text.split(/\*\*([^*]+)\*\*/g);
  return boldParts.map((bPart, bIndex) => {
    const isBold = bIndex % 2 === 1;
    const content = bPart;
    
    // Parse link parts inside content
    const linkParts = content.split(/\[([^\]]+)\]\(([^)]+)\)/g);
    const jsxParts = linkParts.map((lPart, lIndex) => {
      // split returns [textBefore, label, path, textAfter, label, path, ...]
      // so if index % 3 === 0, it is plain text
      // if index % 3 === 1, it is link label
      // if index % 3 === 2, it is path
      if (lIndex % 3 === 0) {
        return lPart;
      }
      if (lIndex % 3 === 1) {
        const path = linkParts[lIndex + 1] || "";
        return (
          <button
            key={lIndex}
            onClick={() => {
              if (path.startsWith("/")) {
                navigate(path);
              } else {
                window.open(path, "_blank");
              }
            }}
            className="mx-1 inline-flex items-center gap-0.5 rounded bg-crosswalk-500/10 px-1.5 py-0.5 text-[10px] text-crosswalk-450 border border-crosswalk-500/20 font-medium hover:bg-crosswalk-500/20 active:bg-crosswalk-500/30 transition-colors"
          >
            {lPart} <ArrowRight size={8} />
          </button>
        );
      }
      return null;
    });

    if (isBold) {
      return <strong key={bIndex} className="font-semibold text-white">{jsxParts}</strong>;
    }
    return <span key={bIndex}>{jsxParts}</span>;
  });
}

function CodeBlock({ code, language }: { code: string; language?: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="my-2 rounded-lg border border-white/5 bg-black/45 overflow-hidden font-mono text-[10px]">
      <div className="flex items-center justify-between bg-black/30 px-3 py-1.5 text-ink-700/60 border-b border-white/5">
        <span>{language || "code"}</span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1 hover:text-white transition-colors"
          type="button"
        >
          {copied ? <Check size={10} className="text-matched" /> : <Copy size={10} />}
          {copied ? "Copied" : "Copy"}
        </button>
      </div>
      <pre className="p-2 overflow-x-auto text-[#cbd5e1] leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  );
}
