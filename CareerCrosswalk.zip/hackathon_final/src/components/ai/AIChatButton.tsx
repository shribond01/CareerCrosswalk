import { useAI } from "./AIProvider";
import { Sparkles, MessageSquare } from "lucide-react";
import { cn } from "../../lib/utils";

export function AIChatButton() {
  const { isOpen, setIsOpen } = useAI();

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Glow Rings background */}
      {!isOpen && (
        <span className="absolute -inset-1.5 rounded-full bg-crosswalk-500/25 blur-md animate-pulse duration-3000" />
      )}
      
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "relative flex h-14 w-14 items-center justify-center rounded-full text-white shadow-xl transition-all duration-300",
          "hover:scale-105 active:scale-95",
          isOpen
            ? "bg-stone-800 hover:bg-stone-700 shadow-stone-900/40"
            : "bg-crosswalk-500 hover:bg-crosswalk-400 shadow-[0_0_20px_rgba(58,110,240,0.35)]"
        )}
        title={isOpen ? "Close Assistant" : "Ask Career AI"}
      >
        {isOpen ? (
          <Sparkles className="animate-spin text-cyan-400" size={22} style={{ animationDuration: "3s" }} />
        ) : (
          <MessageSquare className="animate-pulse" size={22} style={{ animationDuration: "2s" }} />
        )}
      </button>
    </div>
  );
}
export default AIChatButton;
