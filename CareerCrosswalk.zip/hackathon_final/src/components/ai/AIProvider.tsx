import React, { createContext, useContext, useState, useEffect, useSyncExternalStore } from "react";
import { useLocation } from "react-router-dom";
import type { AIMessage } from "../../types";
import { getAIContextForPage } from "../../services/aiContextService";
import { sendChatMessage } from "../../services/aiService";
import { analysisStore } from "../../services/analysisStore";

export interface AIRecommendation {
  title: string;
  reason: string;
  priority: "high" | "medium" | "low";
  action: string;
  actionPath: string;
  relatedSkill?: string;
  relatedCareer?: string;
}

interface AIContextType {
  messages: AIMessage[];
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  loading: boolean;
  error: string | null;
  sendMessage: (text: string) => Promise<void>;
  clearConversation: () => void;
  getSuggestedPrompts: () => string[];
  nextBestAction: AIRecommendation | null;
}

const AIProviderContext = createContext<AIContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = "careercrosswalk_chat_history";

export function AIProvider({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const analysis = useSyncExternalStore(analysisStore.subscribe, analysisStore.getSnapshot, analysisStore.getSnapshot);
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<AIMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [nextBestAction, setNextBestAction] = useState<AIRecommendation | null>(null);

  // Load chat history from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        setMessages(JSON.parse(saved));
      }
    } catch (e) {
      console.error("Failed to load chat history:", e);
    }
  }, []);

  // Recommendations are derived from the real analysis when one exists.
  useEffect(() => {
    const topCareer = analysis?.result.career_paths[0];
    const priorityGap = analysis?.result.skill_gaps[0]?.skill ?? topCareer?.missing_skills?.[0];
    if (analysis && priorityGap) {
      setNextBestAction({
        title: `Work on ${priorityGap}`,
        reason: topCareer
          ? `${priorityGap} is missing from the highest-ranked O*NET occupation: ${topCareer.occupation}.`
          : "This skill was returned as a gap by the backend analysis.",
        priority: "high",
        action: "View skill gap",
        actionPath: "/skill-gap",
        relatedSkill: priorityGap,
        relatedCareer: topCareer?.occupation,
      });
    } else {
      setNextBestAction({
        title: "Analyze your resume",
        reason: "Upload a resume to generate a real O*NET skill profile and career ranking.",
        priority: "medium",
        action: "Upload resume",
        actionPath: "/resume",
      });
    }
  }, [analysis, location.pathname]);

  const saveHistory = (newHistory: AIMessage[]) => {
    setMessages(newHistory);
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newHistory));
    } catch (e) {
      console.error("Failed to save chat history:", e);
    }
  };

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;
    setError(null);
    setLoading(true);

    const userMessage: AIMessage = {
      id: `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      role: "user",
      content: text,
      timestamp: Date.now(),
    };

    const updatedHistory = [...messages, userMessage];
    saveHistory(updatedHistory);

    try {
      // Extract active entities from path
      const pathParts = location.pathname.split("/");
      const lastPart = pathParts[pathParts.length - 1];
      const activeId = lastPart !== "skills" && lastPart !== "careers" && lastPart !== "jobs" ? lastPart : undefined;

      const pageContext = getAIContextForPage(location.pathname, activeId);
      const reply = await sendChatMessage({
        history: updatedHistory,
        context: pageContext,
      });

      const assistantMessage: AIMessage = {
        id: `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        role: "assistant",
        content: reply,
        timestamp: Date.now(),
      };

      saveHistory([...updatedHistory, assistantMessage]);
    } catch (err: any) {
      setError(err?.message || "An error occurred while calling the AI assistant.");
    } finally {
      setLoading(false);
    }
  };

  const clearConversation = () => {
    saveHistory([]);
    setError(null);
  };

  const getSuggestedPrompts = (): string[] => {
    const p = location.pathname;
    if (p.includes("dashboard")) {
      return [
        "What should I focus on next?",
        "How can I improve my readiness score?",
        "Which career is my strongest match?",
      ];
    }
    if (p.includes("skills")) {
      return [
        "Which skill should I improve first?",
        "What skills am I missing?",
        "How can I prove my Python skills?",
      ];
    }
    if (p.includes("career/")) {
      return [
        "Why am I a good match for this career?",
        "How can I reach 90% match?",
        "Which missing skill would most improve this match?",
      ];
    }
    if (p.includes("careers")) {
      return [
        "Compare my target career matches",
        "Which career should I choose?",
        "Which match has the fewest missing skills?",
      ];
    }
    if (p.includes("skill-gap")) {
      return [
        "Which gap should I fix first?",
        "Create a 30-day plan to bridge these gaps",
        "Which missing skill has the highest impact?",
      ];
    }
    if (p.includes("roadmap")) {
      return [
        "What is my next best milestone?",
        "Suggest a portfolio project for this stage",
        "Give me a 30-day study guideline",
      ];
    }
    if (p.includes("jobs")) {
      return [
        "Should I apply to the Software Developer role?",
        "How do I increase my job match score?",
        "What should I change in my resume?",
      ];
    }
    if (p.includes("market")) {
      return [
        "Which skills are growing fastest?",
        "What should I learn for the Chennai market?",
      ];
    }
    if (p.includes("resume")) {
      return [
        "Suggest improvements for my resume keywords",
        "What projects can I add to show SQL evidence?",
      ];
    }
    return [
      "Suggest some career directions for me",
      "Which missing skill has the highest impact?",
    ];
  };

  return (
    <AIProviderContext.Provider
      value={{
        messages,
        isOpen,
        setIsOpen,
        loading,
        error,
        sendMessage,
        clearConversation,
        getSuggestedPrompts,
        nextBestAction,
      }}
    >
      {children}
    </AIProviderContext.Provider>
  );
}

export function useAI() {
  const context = useContext(AIProviderContext);
  if (context === undefined) {
    throw new Error("useAI must be used within an AIProvider");
  }
  return context;
}
