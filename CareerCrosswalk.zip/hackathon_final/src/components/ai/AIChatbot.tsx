import { AIChatButton } from "./AIChatButton";
import { AIChatPanel } from "./AIChatPanel";

export function AIChatbot() {
  return (
    <>
      <AIChatButton />
      <AIChatPanel />
    </>
  );
}
export default AIChatbot;
