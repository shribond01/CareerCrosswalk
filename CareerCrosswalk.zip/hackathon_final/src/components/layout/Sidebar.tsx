import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Sparkles,
  Target,
  Map,
  Briefcase,
  TrendingUp,
  User,
  Settings,
  ChevronsLeft,
  ChevronsRight,
  Milestone,
} from "lucide-react";
import { cn } from "../../lib/utils";
import { useState } from "react";
import { useAppState } from "../app/AppStateProvider";

export const navSections = [
  {
    label: "Overview",
    items: [{ to: "/dashboard", label: "Dashboard", icon: LayoutDashboard }],
  },
  {
    label: "Career Intelligence",
    items: [
      { to: "/skills", label: "My Skills", icon: Sparkles },
      { to: "/careers", label: "Career Matches", icon: Target },
      { to: "/skill-gap", label: "Skill Gap", icon: Milestone },
      { to: "/roadmap", label: "Career Roadmap", icon: Map },
    ],
  },
  {
    label: "Opportunities",
    items: [
      { to: "/jobs", label: "Jobs", icon: Briefcase },
      { to: "/market", label: "Market Insights", icon: TrendingUp },
    ],
  },
  {
    label: "Account",
    items: [
      { to: "/profile", label: "Profile", icon: User },
      { to: "/settings", label: "Settings", icon: Settings },
    ],
  },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const { profile } = useAppState();

  return (
    <aside
      className={cn(
        "hidden lg:flex flex-col shrink-0 border-r border-stone-150 bg-surface-sunken transition-[width] duration-200",
        collapsed ? "w-[76px]" : "w-64"
      )}
    >
      <div className="flex h-16 items-center justify-between px-4">
        {!collapsed && (
          <span className="font-display text-lg font-bold text-white">
            Career<span className="text-crosswalk-400">Crosswalk</span>
          </span>
        )}
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="ml-auto rounded-md p-1.5 text-ink-700 hover:bg-white/5"
          aria-label="Toggle sidebar"
        >
          {collapsed ? <ChevronsRight size={16} /> : <ChevronsLeft size={16} />}
        </button>
      </div>

      <nav className="flex-1 space-y-6 overflow-y-auto px-3 py-4 scrollbar-thin">
        {navSections.map((section) => (
          <div key={section.label}>
            {!collapsed && (
              <p className="mb-1.5 px-2 text-[11px] font-semibold uppercase tracking-wide text-ink-700/30">
                {section.label}
              </p>
            )}
            <div className="space-y-0.5">
              {section.items.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={({ isActive }) =>
                    cn(
                      "flex items-center gap-3 rounded-lg px-2.5 py-2 text-sm font-medium transition-all relative group",
                      isActive
                        ? "bg-crosswalk-500/10 text-crosswalk-400 border-l-[3px] border-crosswalk-500"
                        : "text-ink-700 hover:bg-white/5 hover:text-ink-950"
                    )
                  }
                >
                  <item.icon size={18} className="shrink-0" />
                  {!collapsed && item.label}
                </NavLink>
              ))}
            </div>
          </div>
        ))}
      </nav>

      {/* AI Online Status Indicator */}
      <div className="px-3 py-2 border-t border-stone-150/40">
        <div className={cn(
          "flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-emerald-400 bg-emerald-500/5 border border-emerald-500/10 uppercase tracking-wider",
          collapsed && "justify-center"
        )}>
          <span className="relative flex h-2 w-2 shrink-0">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          {!collapsed && <span className="font-mono text-[10px]">AI ASSISTANT</span>}
        </div>
      </div>

      <div className="border-t border-stone-150 p-3">
        <div className="flex items-center gap-2.5 rounded-lg px-2 py-2 bg-white/5">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-crosswalk-500 font-display text-sm font-semibold text-white">
            {profile.name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
          </div>
          {!collapsed && (
            <div className="min-w-0">
              <p className="truncate text-sm font-medium text-white">{profile.name}</p>
              <p className="truncate text-xs text-ink-700">{profile.headline}</p>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}

export function MobileDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 lg:hidden">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="absolute inset-y-0 left-0 w-72 overflow-y-auto bg-surface-sunken p-4 border-r border-white/5 shadow-pop">
        <div className="mb-4 flex items-center justify-between">
          <span className="font-display text-lg font-bold text-white">
            Career<span className="text-crosswalk-400">Crosswalk</span>
          </span>
          <button onClick={onClose} className="rounded-md p-1.5 text-ink-700 hover:bg-white/5" aria-label="Close menu">
            ✕
          </button>
        </div>
        <nav className="space-y-6">
          {navSections.map((section) => (
            <div key={section.label}>
              <p className="mb-1.5 px-2 text-[11px] font-semibold uppercase tracking-wide text-ink-700/30">{section.label}</p>
              <div className="space-y-0.5">
                {section.items.map((item) => (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    onClick={onClose}
                    className={({ isActive }) =>
                      cn(
                        "flex items-center gap-3 rounded-lg px-2.5 py-2 text-sm font-medium",
                        isActive
                          ? "bg-crosswalk-500/10 text-crosswalk-400 border-l-[3px] border-crosswalk-500"
                          : "text-ink-700 hover:bg-white/5 hover:text-ink-950"
                      )
                    }
                  >
                    <item.icon size={18} />
                    {item.label}
                  </NavLink>
                ))}
              </div>
            </div>
          ))}
        </nav>
      </div>
    </div>
  );
}

export function MobileNav() {
  const items = [
    { to: "/dashboard", label: "Home", icon: LayoutDashboard },
    { to: "/careers", label: "Careers", icon: Target },
    { to: "/skill-gap", label: "Gaps", icon: Milestone },
    { to: "/jobs", label: "Jobs", icon: Briefcase },
    { to: "/profile", label: "Profile", icon: User },
  ];
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 flex border-t border-stone-150 bg-surface-sunken/95 backdrop-blur lg:hidden">
      {items.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          className={({ isActive }) =>
            cn(
              "flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium",
              isActive ? "text-crosswalk-400" : "text-ink-700"
            )
          }
        >
          <item.icon size={19} />
          {item.label}
        </NavLink>
      ))}
    </nav>
  );
}
