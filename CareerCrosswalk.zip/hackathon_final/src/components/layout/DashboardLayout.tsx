import { useState } from "react";
import { Outlet, Link } from "react-router-dom";
import { Sidebar, MobileNav, MobileDrawer } from "./Sidebar";
import { Menu } from "lucide-react";
import { AIChatbot } from "../ai/AIChatbot";

export function DashboardLayout() {
  const [drawerOpen, setDrawerOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-surface relative overflow-x-hidden">
      {/* Background Cyber Grid */}
      <div className="cyber-grid" />
      
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-16 items-center justify-between border-b border-stone-150 bg-surface-sunken px-4 lg:hidden">
          <Link to="/" className="font-display text-base font-bold text-white">
            Career<span className="text-crosswalk-400">Crosswalk</span>
          </Link>
          <button
            onClick={() => setDrawerOpen(true)}
            className="rounded-md p-2 text-ink-700 hover:bg-white/5"
            aria-label="Open menu"
          >
            <Menu size={20} />
          </button>
        </header>
        <main className="flex-1 px-4 pb-20 pt-6 sm:px-6 lg:px-8 lg:pb-8">
          <div className="mx-auto max-w-7xl">
            <Outlet />
          </div>
        </main>
      </div>
      <MobileNav />
      <MobileDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)} />
      
      {/* Cybernetic AI Floating Chat Assistant */}
      <AIChatbot />
    </div>
  );
}
