import React from "react";
import { cn } from "../../lib/utils";
import { AlertTriangle, Inbox, Loader2 } from "lucide-react";

// ---------- Card ----------
export function Card({ className, children, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("rounded-xl2 border border-stone-150 bg-surface-raised shadow-card", className)}
      {...props}
    >
      {children}
    </div>
  );
}

// ---------- Button ----------
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "outline";
  size?: "sm" | "md" | "lg";
}
export function Button({
  className,
  variant = "primary",
  size = "md",
  children,
  ...props
}: ButtonProps) {
  const variants: Record<string, string> = {
    primary: "bg-crosswalk-500 text-white hover:bg-crosswalk-400 active:bg-crosswalk-600 shadow-[0_0_15px_rgba(58,110,240,0.15)]",
    secondary: "bg-white/10 text-white hover:bg-white/20 active:bg-white/30 border border-white/5",
    outline: "border border-stone-150 bg-white/5 text-white hover:bg-white/10",
    ghost: "text-ink-700 hover:bg-white/5 hover:text-white",
  };
  const sizes: Record<string, string> = {
    sm: "text-xs px-3 py-1.5 gap-1.5",
    md: "text-sm px-4 py-2.5 gap-2",
    lg: "text-base px-6 py-3.5 gap-2",
  };
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center rounded-lg font-medium transition-colors duration-150 disabled:opacity-40 disabled:pointer-events-none",
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}

// ---------- Badge ----------
type BadgeTone = "neutral" | "matched" | "partial" | "missing" | "transfer" | "brand";
export function Badge({
  tone = "neutral",
  className,
  children,
}: {
  tone?: BadgeTone;
  className?: string;
  children: React.ReactNode;
}) {
  const tones: Record<BadgeTone, string> = {
    neutral: "bg-surface-sunken text-ink-700",
    matched: "bg-matched-bg text-matched",
    partial: "bg-partial-bg text-partial",
    missing: "bg-missing-bg text-missing",
    transfer: "bg-transfer-bg text-transfer",
    brand: "bg-crosswalk-500/10 text-crosswalk-600",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium",
        tones[tone],
        className
      )}
    >
      {children}
    </span>
  );
}

// ---------- ProgressBar ----------
export function ProgressBar({
  value,
  className,
  barClassName,
  height = "h-2",
}: {
  value: number;
  className?: string;
  barClassName?: string;
  height?: string;
}) {
  return (
    <div className={cn("w-full rounded-full bg-surface-sunken overflow-hidden", height, className)}>
      <div
        className={cn("h-full rounded-full bg-crosswalk-500 transition-all duration-700 ease-out", barClassName)}
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}

// ---------- EmptyState ----------
export function EmptyState({
  title,
  description,
  action,
  icon,
}: {
  title: string;
  description?: string;
  action?: React.ReactNode;
  icon?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-xl2 border border-dashed border-stone-150 bg-surface-sunken/50 px-6 py-14 text-center">
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white/5 text-ink-700 border border-white/5 shadow-card">
        {icon ?? <Inbox size={20} />}
      </div>
      <h3 className="font-display text-base font-semibold text-ink-900">{title}</h3>
      {description && <p className="max-w-sm text-sm text-ink-700/70">{description}</p>}
      {action}
    </div>
  );
}

// ---------- LoadingState ----------
export function LoadingState({ label = "Loading" }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-14 text-ink-700/70">
      <Loader2 className="animate-spin text-crosswalk-500" size={22} />
      <span className="text-sm">{label}…</span>
    </div>
  );
}

// ---------- ErrorState ----------
export function ErrorState({ message = "Something went wrong." }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-xl2 border border-missing-bg bg-missing-bg/40 px-6 py-14 text-center">
      <AlertTriangle className="text-missing" size={22} />
      <p className="text-sm text-ink-900">{message}</p>
    </div>
  );
}

// ---------- Modal ----------
export function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-up" onClick={onClose} />
      <div className="relative z-10 w-full max-w-lg animate-fade-up rounded-xl2 bg-surface-raised border border-white/5 p-6 shadow-pop">
        {title && (
          <h3 className="mb-4 font-display text-lg font-semibold text-ink-900">{title}</h3>
        )}
        {children}
      </div>
    </div>
  );
}

// ---------- Select ----------
export function Select({
  value,
  onChange,
  options,
  className,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { label: string; value: string }[];
  className?: string;
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className={cn(
        "rounded-lg border border-stone-150 bg-surface-raised px-3 py-2 text-sm text-ink-900 focus:border-crosswalk-500 outline-none focus:ring-1 focus:ring-crosswalk-500/50",
        className
      )}
    >
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}
