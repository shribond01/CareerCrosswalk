import type { Job } from "../../types";
import { Card, Button } from "../ui/primitives";
import { MapPin, Clock } from "lucide-react";

export function JobCard({ job }: { job: Job }) {
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-base font-semibold text-ink-900">{job.title}</h3>
          <p className="text-sm text-ink-700/70">{job.company}</p>
        </div>
        <div className="text-right shrink-0">
          <div className="font-mono text-xl font-bold text-crosswalk-600">{job.matchPercent}%</div>
          <p className="text-[11px] text-ink-700/50">match</p>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-ink-700/60">
        <span className="flex items-center gap-1">
          <MapPin size={12} /> {job.location}
        </span>
        <span className="flex items-center gap-1">
          <Clock size={12} /> {job.postedDaysAgo}d ago
        </span>
        <span>{job.jobType}</span>
        <span>{job.experience}</span>
      </div>

      <p className="mt-2 font-mono text-sm font-semibold text-ink-900">{job.salaryRange}</p>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {job.skills.map((s) => (
          <span key={s.name} className="inline-flex items-center gap-1 rounded-md bg-surface-sunken px-2 py-1 text-xs text-ink-700">
            {s.name}
            <GapBadgeIcon status={s.status} />
          </span>
        ))}
      </div>

      <Button variant="outline" className="mt-4 w-full">
        View Job
      </Button>
    </Card>
  );
}

function GapBadgeIcon({ status }: { status: Job["skills"][number]["status"] }) {
  const map = { matched: "text-matched", partial: "text-partial", missing: "text-missing", transferable: "text-transfer" };
  const symbol = { matched: "✓", partial: "◐", missing: "×", transferable: "↗" };
  return <span className={map[status]}>{symbol[status]}</span>;
}
