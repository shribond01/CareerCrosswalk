import React from "react";
import { Card } from "../ui/primitives";
import { cn } from "../../lib/utils";
import { ArrowUpRight } from "lucide-react";

export function StatCard({
  label,
  value,
  sublabel,
  trend,
  icon,
  className,
}: {
  label: string;
  value: string | number;
  sublabel?: string;
  trend?: string;
  icon?: React.ReactNode;
  className?: string;
}) {
  return (
    <Card className={cn("p-5", className)}>
      <div className="flex items-start justify-between">
        <span className="text-xs font-medium uppercase tracking-wide text-ink-700/60">{label}</span>
        {icon && <span className="text-crosswalk-500">{icon}</span>}
      </div>
      <div className="mt-2 flex items-baseline gap-2">
        <span className="font-display text-3xl font-semibold text-ink-900">{value}</span>
      </div>
      {(sublabel || trend) && (
        <div className="mt-1.5 flex items-center gap-1.5 text-xs text-ink-700/60">
          {trend && (
            <span className="inline-flex items-center gap-0.5 font-medium text-matched">
              <ArrowUpRight size={12} />
              {trend}
            </span>
          )}
          {sublabel && <span>{sublabel}</span>}
        </div>
      )}
    </Card>
  );
}
