import { Link } from "react-router-dom";
import type { Career } from "../../types";
import { Card, Badge, ProgressBar } from "../ui/primitives";
import { ArrowRight, Check, X } from "lucide-react";
import { cn } from "../../lib/utils";

const labelTone: Record<Career["matchLabel"], "matched" | "transfer" | "partial"> = {
  "Strong Match": "matched",
  "Good Match": "transfer",
  "Skills Required": "partial",
};

export function CareerCard({ career }: { career: Career }) {
  return (
    <Card className="flex flex-col p-5 transition-shadow hover:shadow-raised">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase tracking-wide text-ink-700/50">{career.domain}</p>
          <h3 className="mt-0.5 font-display text-lg font-semibold text-ink-900">{career.title}</h3>
        </div>
        <div className="text-right">
          <div className="font-mono text-2xl font-bold text-ink-900">{career.matchPercent}%</div>
          <Badge tone={labelTone[career.matchLabel]} className="mt-1">
            {career.matchLabel}
          </Badge>
        </div>
      </div>

      <ProgressBar value={career.matchPercent} className="mt-4" />

      <div className="mt-4 space-y-1.5">
        {career.matchingSkills.slice(0, 3).map((s) => (
          <div key={s} className="flex items-center gap-1.5 text-sm text-ink-700">
            <Check size={14} className="text-matched shrink-0" /> {s}
          </div>
        ))}
        {career.missingSkills.slice(0, 1).map((s) => (
          <div key={s} className="flex items-center gap-1.5 text-sm text-ink-700/60">
            <X size={14} className="text-missing shrink-0" /> {s}
          </div>
        ))}
      </div>

      <Link
        to={`/career/${career.id}`}
        className={cn(
          "mt-5 inline-flex items-center justify-center gap-1.5 rounded-lg border border-stone-150 py-2.5 text-sm font-medium text-ink-900 transition-colors hover:bg-surface-sunken"
        )}
      >
        View Career <ArrowRight size={14} />
      </Link>
    </Card>
  );
}
