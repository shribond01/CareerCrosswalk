import type { RoadmapStep as RoadmapStepType, ProcessingStep } from "../../types";
import { ProgressBar, Card } from "../ui/primitives";
import { CheckCircle2, Circle, CircleDot, Loader2 } from "lucide-react";
import { cn } from "../../lib/utils";

export function RoadmapStepCard({ step, isLast }: { step: RoadmapStepType; isLast?: boolean }) {
  const statusIcon = {
    completed: <CheckCircle2 className="text-matched" size={20} />,
    "in-progress": <CircleDot className="text-crosswalk-500" size={20} />,
    "not-started": <Circle className="text-ink-700/30" size={20} />,
  }[step.status];

  const statusLabel = { completed: "Completed", "in-progress": "In Progress", "not-started": "Not Started" }[step.status];

  return (
    <div className="flex gap-4">
      <div className="flex flex-col items-center">
        {statusIcon}
        {!isLast && <div className="crosswalk-divider mt-1 w-0.5 flex-1 bg-stone-150" />}
      </div>
      <Card className="mb-6 flex-1 p-4">
        <div className="flex items-center justify-between">
          <h4 className="font-medium text-ink-900">{step.skill}</h4>
          <span className="text-xs text-ink-700/50">{step.effort}</span>
        </div>
        <ProgressBar value={step.completionPercent} className="mt-3" />
        <div className="mt-1.5 flex items-center justify-between text-xs text-ink-700/60">
          <span>{statusLabel}</span>
          <span>{step.completionPercent}%</span>
        </div>
        {step.resources.length > 0 && (
          <ul className="mt-2 space-y-0.5 text-xs text-ink-700/60">
            {step.resources.map((r) => (
              <li key={r}>· {r}</li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

export function ProcessingTimeline({ steps }: { steps: ProcessingStep[] }) {
  return (
    <div className="space-y-3">
      {steps.map((s) => (
        <div key={s.label} className="flex items-center gap-3">
          {s.status === "done" && <CheckCircle2 className="text-matched shrink-0" size={18} />}
          {s.status === "active" && <Loader2 className="animate-spin text-crosswalk-500 shrink-0" size={18} />}
          {s.status === "pending" && <Circle className="text-ink-700/25 shrink-0" size={18} />}
          <span
            className={cn(
              "text-sm",
              s.status === "done" && "text-ink-900",
              s.status === "active" && "font-medium text-ink-900",
              s.status === "pending" && "text-ink-700/40"
            )}
          >
            {s.label}
          </span>
        </div>
      ))}
    </div>
  );
}
