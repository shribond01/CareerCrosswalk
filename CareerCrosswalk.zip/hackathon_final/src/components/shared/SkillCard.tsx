import type { Skill } from "../../types";
import { Card } from "../ui/primitives";
import { ConfidenceScore } from "./EvidenceBadge";
import { cn } from "../../lib/utils";

const statusDot: Record<Skill["status"], string> = {
  verified: "bg-matched",
  developing: "bg-partial",
  missing: "bg-missing",
};

export function SkillCard({ skill, onClick, active }: { skill: Skill; onClick?: () => void; active?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full text-left",
        "rounded-xl border border-stone-150 bg-surface-raised p-4 transition-all hover:bg-white/[0.02] hover:shadow-raised",
        active && "border-crosswalk-500 ring-1 ring-crosswalk-500 shadow-[0_0_15px_rgba(58,110,240,0.1)]"
      )}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className={cn("h-2 w-2 rounded-full", statusDot[skill.status])} />
          <span className="font-medium text-ink-900">{skill.name}</span>
        </div>
        <ConfidenceScore value={skill.confidence} />
      </div>
      <div className="mt-2 flex items-center justify-between text-xs text-ink-700/60">
        <span>{skill.proficiency}</span>
        <span className="capitalize">{skill.status}</span>
      </div>
    </button>
  );
}

export function SkillDetailPanel({ skill }: { skill: Skill }) {
  return (
    <Card className="p-5">
      <div className="flex items-baseline justify-between">
        <h3 className="font-display text-xl font-semibold text-ink-900">{skill.name}</h3>
        <ConfidenceScore value={skill.confidence} />
      </div>
      <p className="mt-1 text-sm text-ink-700/70">
        Proficiency: <span className="font-medium text-ink-900">{skill.proficiency}</span>
      </p>

      <div className="mt-4">
        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-700/50">Evidence</p>
        {skill.evidence.length === 0 ? (
          <p className="text-sm text-ink-700/60">No evidence found for this skill yet.</p>
        ) : (
          <ul className="space-y-1.5">
            {skill.evidence.map((e, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-ink-700">
                <span className="mt-0.5 text-matched">✓</span>
                {e.label}
              </li>
            ))}
          </ul>
        )}
      </div>

      {skill.relatedSkills.length > 0 && (
        <div className="mt-5">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-700/50">Related skills</p>
          <div className="space-y-1.5 pl-1 font-mono text-sm text-ink-700">
            {skill.relatedSkills.map((r, i) => (
              <div key={r} className="flex items-center gap-2">
                <span className="text-ink-700/30">{i === skill.relatedSkills.length - 1 ? "└──" : "├──"}</span>
                {r}
              </div>
            ))}
          </div>
        </div>
      )}
    </Card>
  );
}
