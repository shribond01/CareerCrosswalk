import type { WosEvidence } from "../../types/analysis";

export function ResumeEvidence({ text, evidence }: { text?: string; evidence: WosEvidence[] }) {
  if (!text) return null;
  const skills = evidence.map((item) => item.skill).filter(Boolean);
  const pattern = skills.length ? new RegExp(`(${skills.map((skill) => skill.replace(/[.*+?^${}()|[\\]\\]/g, "\\\\$&")).join("|")})`, "gi") : null;
  const parts = pattern ? text.split(pattern) : [text];
  return (
    <div className="rounded-lg border border-stone-150 bg-surface-sunken/50 p-4">
      <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-700/50">Resume Evidence</p>
      <p className="whitespace-pre-wrap text-sm leading-6 text-ink-700">
        {parts.map((part, index) => {
          const match = skills.find((skill) => skill.toLowerCase() === part.toLowerCase());
          if (!match) return <span key={`${part}-${index}`}>{part}</span>;
          const item = evidence.find((candidate) => candidate.skill === match);
          return (
            <mark key={`${part}-${index}`} className="rounded bg-crosswalk-500/25 px-1 text-ink-900" title={`Confidence: ${item?.confidence ?? "available"}`}>
              {part}
            </mark>
          );
        })}
      </p>
    </div>
  );
}
