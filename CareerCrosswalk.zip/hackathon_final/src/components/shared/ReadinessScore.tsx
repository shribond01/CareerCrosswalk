import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer } from "recharts";

export function ReadinessRing({ value, size = 168 }: { value: number; size?: number }) {
  const stroke = 14;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (value / 100) * c;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255, 255, 255, 0.04)" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke="#3A6EF0"
          strokeWidth={stroke}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={c}
          strokeDashoffset={offset}
          className="transition-all duration-1000 ease-out"
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-4xl font-bold text-white">{value}</span>
        <span className="text-xs font-medium text-ink-700/60">/ 100</span>
      </div>
    </div>
  );
}

const breakdownData = [
  { area: "Technical", score: 84 },
  { area: "Experience", score: 62 },
  { area: "Projects", score: 74 },
  { area: "Tools", score: 70 },
  { area: "Communication", score: 88 },
  { area: "Education", score: 90 },
];

export function ReadinessRadar() {
  return (
    <ResponsiveContainer width="100%" height={220}>
      <RadarChart data={breakdownData} outerRadius="78%">
        <PolarGrid stroke="rgba(255, 255, 255, 0.08)" />
        <PolarAngleAxis dataKey="area" tick={{ fontSize: 11, fill: "#9CA3AF" }} />
        <Radar dataKey="score" stroke="#3A6EF0" fill="#3A6EF0" fillOpacity={0.22} strokeWidth={2} />
      </RadarChart>
    </ResponsiveContainer>
  );
}

export const readinessBreakdown = breakdownData;
