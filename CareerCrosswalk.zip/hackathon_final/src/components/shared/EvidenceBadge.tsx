import { CheckCircle2, Eye, Sparkles, XCircle } from "lucide-react";
import type { EvidenceStatus, GapStatus } from "../../types";
import { cn } from "../../lib/utils";

const evidenceConfig: Record<EvidenceStatus, { label: string; icon: React.ReactNode; className: string }> = {
  verified: { label: "Verified", icon: <CheckCircle2 size={12} />, className: "bg-matched-bg text-matched" },
  detected: { label: "Detected", icon: <Eye size={12} />, className: "bg-transfer-bg text-transfer" },
  inferred: { label: "Inferred", icon: <Sparkles size={12} />, className: "bg-partial-bg text-partial" },
  missing: { label: "Missing", icon: <XCircle size={12} />, className: "bg-missing-bg text-missing" },
};

export function EvidenceBadge({ status }: { status: EvidenceStatus }) {
  const c = evidenceConfig[status];
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium", c.className)}>
      {c.icon}
      {c.label}
    </span>
  );
}

export function ConfidenceScore({ value }: { value: number }) {
  const tone = value >= 80 ? "text-matched" : value >= 55 ? "text-partial" : "text-missing";
  return (
    <span className={cn("font-mono text-sm font-semibold tabular-nums", tone)}>{value}%</span>
  );
}

const gapConfig: Record<GapStatus, { label: string; symbol: string; className: string }> = {
  matched: { label: "Matched", symbol: "✓", className: "bg-matched-bg text-matched" },
  partial: { label: "Partial", symbol: "◐", className: "bg-partial-bg text-partial" },
  missing: { label: "Missing", symbol: "×", className: "bg-missing-bg text-missing" },
  transferable: { label: "Transferable", symbol: "↗", className: "bg-transfer-bg text-transfer" },
};

export function GapBadge({ status, className }: { status: GapStatus; className?: string }) {
  const c = gapConfig[status];
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold", c.className, className)}>
      <span aria-hidden>{c.symbol}</span>
      {c.label}
    </span>
  );
}

export function gapSymbol(status: GapStatus) {
  return gapConfig[status].symbol;
}
