import { LockKeyhole, ShieldCheck } from "lucide-react";
import { Card } from "../ui/primitives";

export function PrivacyStatusCard({
  storeResume,
  onStoreResumeChange,
}: {
  storeResume: boolean;
  onStoreResumeChange: (value: boolean) => void;
}) {
  return (
    <Card className="border-crosswalk-500/20 bg-crosswalk-500/5 p-5">
      <div className="flex items-start gap-3">
        <ShieldCheck size={18} className="mt-0.5 shrink-0 text-crosswalk-400" />
        <div className="min-w-0">
          <h3 className="font-display text-sm font-semibold text-ink-900">Privacy controls</h3>
          <p className="mt-1 text-xs leading-5 text-ink-700/75">
            Resume encryption is implemented on the server boundary. This browser never receives encryption keys.
          </p>
        </div>
      </div>
      <div className="mt-4 rounded-lg border border-stone-150 bg-surface-sunken/60 p-3">
        <div className="flex items-start gap-3">
          <LockKeyhole size={16} className="mt-0.5 shrink-0 text-ink-700" />
          <div>
            <p className="text-sm font-medium text-ink-900">Resume storage preference</p>
            <p className="mt-1 text-xs leading-5 text-ink-700/75">
              {storeResume
                ? "You allow the backend to retain an encrypted resume for re-analysis."
                : "The backend should not retain the uploaded resume after processing."}
            </p>
          </div>
          <button
            type="button"
            onClick={() => onStoreResumeChange(!storeResume)}
            className={`ml-auto relative h-6 w-11 shrink-0 rounded-full transition-colors ${storeResume ? "bg-crosswalk-500" : "bg-stone-150"}`}
            aria-label="Allow resume storage"
            aria-pressed={storeResume}
          >
            <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${storeResume ? "translate-x-5" : "translate-x-0.5"}`} />
          </button>
        </div>
      </div>
      <p className="mt-3 text-[11px] leading-4 text-ink-700/60">
        No automatic deletion is performed by this privacy layer. Deletion remains an explicit backend/user action.
      </p>
    </Card>
  );
}
