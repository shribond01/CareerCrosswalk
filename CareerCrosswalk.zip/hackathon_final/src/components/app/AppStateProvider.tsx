import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { User } from "../../types";

type Theme = "dark" | "light";
type Settings = {
  profileVisible: boolean;
  notifJobs: boolean;
  notifRoadmap: boolean;
  privacyAnon: boolean;
  keepResume: boolean;
  compact: boolean;
};

type AppState = {
  profile: User;
  updateProfile: (profile: User) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  settings: Settings;
  updateSetting: (key: keyof Settings, value: boolean) => void;
};

const PROFILE_KEY = "careercrosswalk_profile";
const PREFERENCES_KEY = "careercrosswalk_preferences";

const starterProfile: User = {
  name: "Your Profile",
  headline: "Career Explorer",
  education: "Not added yet",
  degree: "Add your education",
  experienceYears: 0,
  preferredLocation: "Not set",
  preferredWork: "Hybrid",
  targetRoles: [],
  careerReadiness: 0,
  readinessDelta: 0,
};

const defaultSettings: Settings = {
  profileVisible: false,
  notifJobs: true,
  notifRoadmap: false,
  privacyAnon: false,
  keepResume: false,
  compact: false,
};

const AppStateContext = createContext<AppState | undefined>(undefined);

function readStored<T extends object>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(key);
    return value ? { ...fallback, ...JSON.parse(value) } : fallback;
  } catch {
    return fallback;
  }
}

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<User>(() => readStored(PROFILE_KEY, starterProfile));
  const [preferences, setPreferences] = useState<{ theme: Theme; settings: Settings }>(() => readStored(PREFERENCES_KEY, { theme: "dark", settings: defaultSettings }));

  useEffect(() => {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  }, [profile]);
  useEffect(() => {
    localStorage.setItem(PREFERENCES_KEY, JSON.stringify(preferences));
    document.documentElement.dataset.theme = preferences.theme;
    document.documentElement.dataset.compact = String(preferences.settings.compact);
  }, [preferences]);

  const value = useMemo<AppState>(() => ({
    profile,
    updateProfile: setProfile,
    theme: preferences.theme,
    setTheme: (theme) => setPreferences((current) => ({ ...current, theme })),
    settings: preferences.settings,
    updateSetting: (key, settingValue) => setPreferences((current) => ({
      ...current,
      settings: { ...current.settings, [key]: settingValue },
    })),
  }), [profile, preferences]);

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState(): AppState {
  const state = useContext(AppStateContext);
  if (!state) throw new Error("useAppState must be used within AppStateProvider");
  return state;
}
