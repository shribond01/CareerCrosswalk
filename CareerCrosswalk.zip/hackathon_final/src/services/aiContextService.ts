import { demoUser } from "../data/users";
import { skills } from "../data/skills";
import { careers } from "../data/careers";
import { jobs } from "../data/jobs";
import { roadmapSteps, skillGapBreakdown, priorityGaps } from "../data/roadmap";
import { skillDemand, growingSkills } from "../data/market";

/**
 * Generates page-specific details from global and local state
 * to help Gemini construct highly precise responses.
 */
export function getAIContextForPage(pathname: string, activeId?: string): string {
  const verifiedNames = skills.filter((s) => s.status === "verified").map((s) => s.name);
  const developingNames = skills.filter((s) => s.status === "developing").map((s) => s.name);
  const missingNames = skills.filter((s) => s.status === "missing").map((s) => s.name);

  // Common context elements
  let context = `--- USER CONFIGURATION ---
User Name: ${demoUser.name}
Headline: ${demoUser.headline}
Education: ${demoUser.education} (${demoUser.degree})
Experience: ${demoUser.experienceYears} year(s)
Preferred Location: ${demoUser.preferredLocation} (Preferences: ${demoUser.preferredWork})
Target Career Roles: ${demoUser.targetRoles.join(", ")}
Overall Career Readiness Score: ${demoUser.careerReadiness}% (${demoUser.readinessDelta >= 0 ? "+" : ""}${demoUser.readinessDelta}% compared to last month)

--- SKILLS RESUME BACKGROUND ---
Verified Skills (Verified via project/resume/certificate): ${verifiedNames.join(", ") || "None"}
Developing Skills (In progress): ${developingNames.join(", ") || "None"}
Missing Skills: ${missingNames.join(", ") || "None"}
`;

  // Page specific details
  if (pathname.includes("dashboard")) {
    context += `
--- CURRENT VIEW: DASHBOARD (Career Command Center) ---
Focus Areas for User:
- Improving overall readiness score (${demoUser.careerReadiness}%).
- Primary skill gap target recommendation: SQL/Cloud fundamentals.
- Target careers comparison and match percentages: ${careers.map((c) => `${c.title} (${c.matchPercent}% Match)`).join(", ")}.
`;
  } else if (pathname.includes("skills")) {
    context += `
--- CURRENT VIEW: MY SKILLS ---
Details of user skill proficiencies, evidence logs, and certificates:
${skills.map((s) => `- ${s.name}: Status=${s.status}, Proficiency=${s.proficiency}, Confidence=${s.confidence}%, Evidence=${s.evidence.map((e) => e.label).join("; ")}`).join("\n")}
`;
    if (activeId) {
      const activeSkill = skills.find((s) => s.id === activeId || s.name.toLowerCase() === activeId.toLowerCase());
      if (activeSkill) {
        context += `\n[Focused Skill]:
ID: ${activeSkill.id}
Name: ${activeSkill.name}
Status: ${activeSkill.status}
Proficiency: ${activeSkill.proficiency}
Confidence: ${activeSkill.confidence}%
Evidence: ${activeSkill.evidence.map((e) => e.label).join(", ")}
Related skills in career maps: ${activeSkill.relatedSkills.join(", ")}
`;
      }
    }
  } else if (pathname.includes("careers") || pathname.includes("career/")) {
    context += `
--- CURRENT VIEW: CAREER MATCHES ---
Available occupation matches:
${careers.map((c) => `- ${c.title}: ${c.matchPercent}% Match (${c.matchLabel}). Demand Trend: ${c.demandTrend}. Salary: ${c.medianSalaryINR}. Matching Skills: ${c.matchingSkills.join(", ")}; Missing Skills: ${c.missingSkills.join(", ")}`).join("\n")}
`;
    if (activeId) {
      const activeCareer = careers.find((c) => c.id === activeId);
      if (activeCareer) {
        context += `\n[Focused Target Career]:
Title: ${activeCareer.title}
Domain: ${activeCareer.domain}
Salary Range: ${activeCareer.medianSalaryINR}
Match Percentage: ${activeCareer.matchPercent}% (${activeCareer.matchLabel})
Transferable Skills: ${activeCareer.skillBreakdown.filter(s => s.status === 'transferable').map(s => s.skill).join(', ') || 'None'}
Matching Skills: ${activeCareer.matchingSkills.join(", ")}
Missing Skills: ${activeCareer.missingSkills.join(", ")}
Explanation: ${activeCareer.description}
`;
      }
    }
  } else if (pathname.includes("skill-gap")) {
    context += `
--- CURRENT VIEW: SKILL GAP ---
Missing skills gap details in career roadmap:
${skillGapBreakdown.map((s) => `- ${s.skill}: Status=${s.status}, CurrentPercent=${s.currentPercent}%${s.transferableFrom ? `, TransferableFrom=${s.transferableFrom}` : ""}`).join("\n")}
Priority Gaps to bridge:
${priorityGaps.map((p) => `- ${p.skill}: Priority=${p.priority}, UrgencyReason=${p.reason}`).join("\n")}
`;
  } else if (pathname.includes("roadmap")) {
    context += `
--- CURRENT VIEW: CAREER ROADMAP (Career Milestone Plan) ---
Milestones and learning objectives:
${roadmapSteps.map((r) => `- Skill: ${r.skill}, Effort: ${r.effort}, Status: ${r.status}, Completion: ${r.completionPercent}%, Resources: ${r.resources.join(", ")}`).join("\n")}
`;
  } else if (pathname.includes("jobs")) {
    context += `
--- CURRENT VIEW: RECOMMENDED JOBS ---
Job matches for target careers:
${jobs.map((j) => `- JobID: ${j.id}, Title: ${j.title}, Company: ${j.company}, Match: ${j.matchPercent}%, Skills needed: ${j.skills.map((s) => `${s.name} (${s.status})`).join(", ")}`).join("\n")}
`;
    if (activeId) {
      const activeJob = jobs.find((j) => j.id === activeId);
      if (activeJob) {
        context += `\n[Focused Job Listing]:
Title: ${activeJob.title}
Company: ${activeJob.company}
Location: ${activeJob.location}
Salary Range: ${activeJob.salaryRange}
Match Level: ${activeJob.matchPercent}%
Required Skills Mapping: ${activeJob.skills.map((s) => `${s.name} (Your status: ${s.status})`).join(", ")}
`;
      }
    }
  } else if (pathname.includes("market")) {
    context += `
--- CURRENT VIEW: LABOR MARKET INSIGHTS ---
Skill Demands:
${skillDemand.map((s) => `- ${s.skill}: ${s.demandPercent}% Demand Index`).join("\n")}
Growing Skills in High Demand: ${growingSkills.join(", ")}
`;
  } else if (pathname.includes("resume")) {
    context += `
--- CURRENT VIEW: RESUME ANALYZER ---
The user can upload their resume to compare it with job structures. Currently simulated parse outputs are used for detected skills list.
`;
  } else if (pathname.includes("profile")) {
    context += `
--- CURRENT VIEW: USER PROFILE ---
Educational Background: ${demoUser.education}
Target Careers of choice: ${demoUser.targetRoles.join(", ")}
Preferred city: ${demoUser.preferredLocation}
`;
  } else if (pathname.includes("settings")) {
    context += `
--- CURRENT VIEW: CONFIGURATION SETTINGS ---
The user is viewing their configurations. They can manage AI prompts suggestions and clear chat history.
`;
  }

  return context;
}
