import type { AIMessage } from "../types";
import { minimizePiiForExternalModel } from "../lib/piiMinimizer";

export interface AIChatOptions {
  history: AIMessage[];
  context: string;
}

/**
 * AI transport intentionally delegates provider access to the server endpoint.
 * No provider secret or encryption key is read by the browser.
 */
export async function sendChatMessage(options: AIChatOptions): Promise<string> {
  const serverEndpoint = "/api/ai/chat";
  const sanitizedHistory = options.history.map((message) => ({
    ...message,
    content: minimizePiiForExternalModel(message.content),
  }));
  const sanitizedContext = minimizePiiForExternalModel(options.context);

  try {
    const response = await fetch(serverEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messages: sanitizedHistory,
        context: sanitizedContext,
      }),
    });

    const data = (await response.json().catch(() => null)) as { content?: unknown; detail?: unknown } | null;
    if (!response.ok) {
      const detail = typeof data?.detail === "string" ? data.detail : `AI server request failed (${response.status}).`;
      throw new Error(detail);
    }
    if (typeof data?.content === "string" && data.content.trim()) {
      return data.content;
    }
    throw new Error("AI server returned no response content.");
  } catch (error) {
    if (error instanceof Error) throw error;
    throw new Error("AI Service is unavailable. The server-side AI endpoint could not be reached.");
  }
}
