import { skills as demoSkills } from "../data/skills";
import type { Career, CareerSkillMatch, RoadmapStep, Skill, SkillGapItem } from "../types";
import type { AnalysisSession, WosEvidence } from "../types/analysis";

const categoryFor = (name: string): Skill["category"] => {
  const demo = demoSkills.find((skill) => skill.name.toLowerCase() === name.toLowerCase());
  return demo?.category ?? "Tools";
};

export function analysisSkills(session: AnalysisSession): Skill[] {
  const evidence = session.result.evidence.selected_candidate_matches as unknown as WosEvidence[];
  return session.result.candidate_skills.map((name) => {
    const demo = demoSkills.find((skill) => skill.name.toLowerCase() === name.toLowerCase());
    const match = evidence.find((item) => item.skill === name);
    return {
      id: demo?.id ?? name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
      name,
      category: categoryFor(name),
      proficiency: match?.confidence === "high" ? "Advanced" : "Intermediate",
      confidence: Math.round((match?.numeric_confidence ?? 0) * 100),
      status: "verified",
      evidence: [
        {
          label: `Resume evidence: ${name}`,
          status: match?.lexical_match ? "detected" : "inferred",
        },
      ],
      relatedSkills: demo?.relatedSkills ?? [],
    };
  });
}

export function analysisCareers(session: AnalysisSession): Career[] {
  return session.result.career_paths.map((path, index) => {
    const skillBreakdown: CareerSkillMatch[] = [
      ...path.skills.map((skill) => ({ skill, status: "matched" as const })),
      ...(path.missing_skills ?? []).map((skill) => ({ skill, status: "missing" as const })),
    ];
    const matchPercent = Math.round(Number((path as unknown as { match_pct?: number }).match_pct ?? 0));
    return {
      id: (path as unknown as { soc_code?: string }).soc_code ?? `onet-career-${index + 1}`,
      socCode: (path as unknown as { soc_code?: string }).soc_code ?? "O*NET",
      title: path.occupation,
      domain: "O*NET Software Skills",
      matchPercent,
      matchLabel: matchPercent >= 70 ? "Strong Match" : matchPercent >= 45 ? "Good Match" : "Skills Required",
      matchingSkills: path.skills,
      missingSkills: (path as unknown as { missing_skills?: string[] }).missing_skills ?? [],
      skillBreakdown,
      description: `Derived from ${path.overlap} O*NET workplace software skills explicitly found in the uploaded resume.`,
      medianSalaryINR: "Not available",
      demandTrend: "Not available",
    };
  });
}

export function analysisGaps(session: AnalysisSession): SkillGapItem[] {
  const matched = new Set(session.result.candidate_skills);
  const topCareerGaps = session.result.career_paths[0]?.missing_skills ?? [];
  const all = [...session.result.candidate_skills, ...session.result.missing_skills, ...topCareerGaps];
  return all.filter((skill, index) => all.indexOf(skill) === index).map((skill) => ({
    skill,
    currentPercent: matched.has(skill) ? 100 : 0,
    status: matched.has(skill) ? "matched" : "missing",
  }));
}

export function analysisRoadmap(session: AnalysisSession): RoadmapStep[] {
  const gaps = session.result.skill_gaps.length
    ? session.result.skill_gaps
    : (session.result.career_paths[0]?.missing_skills ?? []).map((skill) => ({
        skill,
        importance: 0,
        reason: "Missing from the highest-ranked O*NET occupation.",
      }));
  return gaps.map((gap, index) => {
    const context = "context" in gap
      ? (gap.context as { workforce_relevance?: string } | undefined)
      : undefined;
    return {
      id: `wos-gap-${index + 1}`,
      skill: gap.skill,
      effort: "Backend-provided priority",
      status: "not-started" as const,
      completionPercent: 0,
      resources: context?.workforce_relevance ? [context.workforce_relevance] : [],
    };
  });
}

export function analysisEvidence(session: AnalysisSession): WosEvidence[] {
  return session.result.evidence.selected_candidate_matches as unknown as WosEvidence[];
}
