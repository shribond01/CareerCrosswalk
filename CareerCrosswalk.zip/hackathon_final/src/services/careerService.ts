import { careers, getCareerById } from "../data/careers";
import { skillGapBreakdown, priorityGaps } from "../data/roadmap";
import { delay } from "../lib/utils";
import type { Career } from "../types";

/** FUTURE: GET /api/careers */
export async function getCareers(): Promise<Career[]> {
  await delay(200);
  return careers;
}

export async function getCareer(id: string): Promise<Career | undefined> {
  await delay(150);
  return getCareerById(id);
}

/**
 * FUTURE INTEGRATION POINT
 * Real implementation: bi-encoder semantic similarity (resume ↔ O*NET
 * occupation) + weighted scoring engine (R&D report Part 9). Currently
 * returns the already-computed mock matchPercent.
 */
export async function calculateSemanticMatch(careerId: string): Promise<number> {
  await delay(300);
  return getCareerById(careerId)?.matchPercent ?? 0;
}

/** FUTURE: GET /api/skill-gap?careerId= */
export async function getSkillGap(_careerId: string) {
  await delay(250);
  return { breakdown: skillGapBreakdown, priorities: priorityGaps };
}

/**
 * FUTURE INTEGRATION POINT
 * Real implementation: vector search over occupation embeddings
 * (pgvector ANN query, R&D report Part 7/8).
 */
export async function searchSimilarRoles(careerId: string): Promise<Career[]> {
  await delay(250);
  const current = getCareerById(careerId);
  if (!current) return [];
  return careers.filter((c) => c.domain === current.domain && c.id !== careerId);
}

/**
 * FUTURE INTEGRATION POINT
 * Real implementation: RAG pass over occupation/skill/task-statement
 * text to produce a grounded natural-language explanation (R&D report
 * Part 13). Currently composes a deterministic explanation from the
 * mock skill breakdown so the UI has real content to render.
 */
export async function getGroundedExplanation(careerId: string): Promise<string> {
  await delay(300);
  const career = getCareerById(careerId);
  if (!career) return "";
  const matched = career.skillBreakdown.filter((s) => s.status === "matched").map((s) => s.skill);
  const missing = career.skillBreakdown.filter((s) => s.status === "missing").map((s) => s.skill);
  return `Based on your verified and detected skills, you match ${matched.length} of ${career.skillBreakdown.length} core requirements for ${career.title}, most strongly in ${matched.slice(0, 2).join(" and ") || "a few areas"}. The largest remaining gaps are ${missing.slice(0, 2).join(" and ") || "minor"}.`;
}

/**
 * What-If integration seam. The backend can provide production recalculation;
 * the deterministic result remains the explicit demo fallback for this frontend prototype.
 */
export async function simulateReadiness(baseReadiness: number, addedSkills: string[]): Promise<number> {
  try {
    const response = await fetch("/api/whatif", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ baseReadiness, addedSkills }),
    });
    if (response.ok) {
      const data = (await response.json()) as { readiness?: unknown };
      if (typeof data.readiness === "number" && Number.isFinite(data.readiness)) {
        return Math.min(100, Math.max(0, Math.round(data.readiness)));
      }
    }
  } catch {
    // The frontend prototype intentionally falls back when the backend is unavailable.
  }

  await delay(500);
  const boost = Math.min(addedSkills.length * 3.5, 20);
  return Math.min(99, Math.round(baseReadiness + boost));
}
