import { skillDemand, growingSkills, locationDemand, domainDemand } from "../data/market";
import { delay } from "../lib/utils";

/**
 * FUTURE INTEGRATION POINT
 * Real implementation: GET /api/market backed by licensed labor-market
 * data (Lightcast-style aggregation or a compliant NCS/NSDC feed — see
 * R&D report Part 12). Values below are demonstration/mock only.
 */
export async function getSkillDemand() {
  await delay(200);
  return skillDemand;
}

export async function getGrowingSkills() {
  await delay(150);
  return growingSkills;
}

export async function getLocationDemand() {
  await delay(200);
  return locationDemand;
}

export async function getDomainDemand() {
  await delay(200);
  return domainDemand;
}
