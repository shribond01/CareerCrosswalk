import { jobs } from "../data/jobs";
import { delay } from "../lib/utils";
import type { Job } from "../types";

export interface JobFilters {
  location?: string;
  jobType?: string;
  experience?: string;
  query?: string;
}

/**
 * FUTURE INTEGRATION POINT
 * Real implementation: GET /api/jobs backed by a licensed job-posting
 * feed (not scraped — see R&D report Part 12 on data licensing). This
 * demo data is illustrative/mock and not live listings.
 */
export async function getJobs(filters: JobFilters = {}): Promise<Job[]> {
  await delay(200);
  return jobs.filter((j) => {
    if (filters.location && j.location !== filters.location) return false;
    if (filters.jobType && j.jobType !== filters.jobType) return false;
    if (filters.experience && j.experience !== filters.experience) return false;
    if (filters.query && !j.title.toLowerCase().includes(filters.query.toLowerCase())) return false;
    return true;
  });
}
