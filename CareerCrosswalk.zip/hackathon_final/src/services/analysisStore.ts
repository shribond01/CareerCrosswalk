import type { AnalysisSession } from "../types/analysis";

let currentSession: AnalysisSession | null = null;
const listeners = new Set<() => void>();

export const analysisStore = {
  getSnapshot: () => currentSession,
  set: (session: AnalysisSession) => {
    currentSession = session;
    listeners.forEach((listener) => listener());
  },
  clear: () => {
    currentSession = null;
    listeners.forEach((listener) => listener());
  },
  subscribe: (listener: () => void) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },
};
