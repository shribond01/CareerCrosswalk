import type { ProcessingStep } from "../types";
import type { AnalysisSession } from "../types/analysis";

export interface ResumeAnalysisResult {
  fileName: string;
  sections: { name: string; found: boolean }[];
  detectedSkills: { name: string; confidence: number }[];
  session: AnalysisSession;
}

export const processingStepLabels = [
  "Uploading resume",
  "Extracting text",
  "Identifying skills",
  "Mapping occupations",
  "Building skill profile",
];

export class ResumeAnalysisError extends Error {
  readonly status?: number;

  constructor(message: string, status?: number) {
    super(message);
    this.name = "ResumeAnalysisError";
    this.status = status;
  }
}

function updateSteps(
  labels: string[],
  completed: number,
  active: number | null,
  onStepChange?: (steps: ProcessingStep[]) => void
) {
  onStepChange?.(
    labels.map((label, index) => ({
      label,
      status: index < completed ? "done" : index === active ? "active" : "pending",
    }))
  );
}

async function responseMessage(response: Response): Promise<string> {
  try {
    const body = (await response.json()) as { detail?: string };
    if (typeof body.detail === "string" && body.detail.trim()) return body.detail;
  } catch {
    // A non-JSON error response still gets a useful status message below.
  }
  return `Resume analysis failed (${response.status} ${response.statusText || "server error"}).`;
}

/** Posts the uploaded file to the real FastAPI/O*NET pipeline. */
export async function analyzeResume(
  file: File,
  jobDescription = "",
  onStepChange?: (steps: ProcessingStep[]) => void
): Promise<ResumeAnalysisResult> {
  updateSteps(processingStepLabels, 0, 0, onStepChange);
  const form = new FormData();
  form.append("file", file);
  if (jobDescription.trim()) form.append("job_description", jobDescription.trim());
  try {
    const response = await fetch("/api/resume/analyze", { method: "POST", body: form });
    if (!response.ok) {
      throw new ResumeAnalysisError(await responseMessage(response), response.status);
    }
    updateSteps(processingStepLabels, 2, 2, onStepChange);
    const payload = (await response.json()) as {
      status?: "real_analysis";
      fileName?: string;
      result?: AnalysisSession["result"];
    };
    if (payload.status !== "real_analysis" || !payload.result) {
      throw new ResumeAnalysisError("The analysis server returned an incomplete result.");
    }
    const session: AnalysisSession = {
      id: `analysis-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      status: "real_analysis",
      fileName: payload.fileName ?? file.name,
      result: payload.result,
    };
    updateSteps(processingStepLabels, processingStepLabels.length, null, onStepChange);
    const evidence = session.result.evidence.selected_candidate_matches;
    return {
      fileName: session.fileName,
      sections: [
        { name: "Resume text extracted", found: true },
        { name: "O*NET skill matching", found: true },
        { name: "Occupation ranking", found: true },
      ],
      detectedSkills: session.result.candidate_skills.map((name) => {
        const item = evidence.find((entry) => entry.skill === name);
        return { name, confidence: Math.round((Number(item?.numeric_confidence) || 0) * 100) };
      }),
      session,
    };
  } catch (error) {
    updateSteps(processingStepLabels, 0, null, onStepChange);
    if (error instanceof ResumeAnalysisError) throw error;
    const message = error instanceof Error ? error.message : "The API could not be reached.";
    throw new ResumeAnalysisError(`Could not reach the analysis server: ${message}`);
  }
}
