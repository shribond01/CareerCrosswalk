import { skills, skillSummary, skillCategories } from "../data/skills";
import { delay } from "../lib/utils";
import type { Skill } from "../types";

/** FUTURE: GET /api/skills */
export async function getSkills(): Promise<Skill[]> {
  await delay(200);
  return skills;
}

export async function getSkillSummary() {
  await delay(150);
  return skillSummary;
}

export async function getSkillCategories() {
  return skillCategories;
}

/**
 * FUTURE INTEGRATION POINT
 * Real implementation calls a taxonomy/skill-graph service
 * (skillService.getRelatedSkills → vector search + O*NET relationship
 * table, see R&D report Part 7/9). Currently reads the static
 * `relatedSkills` field already attached to each mock skill.
 */
export async function getRelatedSkills(skillId: string): Promise<string[]> {
  await delay(150);
  return skills.find((s) => s.id === skillId)?.relatedSkills ?? [];
}
