"""
resume_extractor.py — Step 1 (Input) + Step 2 (Text Processing)
-------------------------------------------------------------------
Takes a resume file (PDF, image, or plain text) and returns clean,
normalized text ready for skill extraction / embedding.

Handles two cases:
  1. Text-based PDF (most resumes exported from Word/Google Docs/Canva)
     -> extracted directly via pdfplumber, no OCR needed.
  2. Scanned/image-based PDF or a photo of a resume
     -> falls back to OCR (pdf2image + pytesseract).

Run:
    pip install pdfplumber pytesseract pdf2image
    (also requires the `tesseract-ocr` and `poppler-utils` system packages,
     both already installed in most Linux/Colab environments; on Windows
     install Tesseract separately and set pytesseract.pytesseract.tesseract_cmd)

    python resume_extractor.py path/to/resume.pdf
"""

import re
import os
import shutil
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree

import pdfplumber
import pytesseract
from pdf2image import convert_from_path
from PIL import Image

# Minimum characters we expect from pdfplumber before deciding a page
# is "real text" rather than a scanned image with no text layer.
MIN_CHARS_PER_PAGE = 20


def _configure_tesseract() -> None:
    """Respect an explicit Windows installation path before OCR is invoked."""
    configured = os.getenv("TESSERACT_CMD", "").strip()
    if configured:
        executable = Path(configured)
        if not executable.exists():
            raise ValueError("OCR is unavailable: TESSERACT_CMD does not point to tesseract.exe.")
        pytesseract.pytesseract.tesseract_cmd = str(executable)
        return
    if not shutil.which("tesseract"):
        raise ValueError("OCR is unavailable: install Tesseract or set TESSERACT_CMD in backend/.env.")


def extract_text_native(pdf_path: str) -> str:
    """Try direct text extraction first — fast, accurate, no OCR errors."""
    text_chunks = []
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text() or ""
            text_chunks.append(page_text)
    return "\n".join(text_chunks)


def extract_text_ocr(pdf_path: str, dpi: int = 300) -> str:
    """Fallback: rasterize each page and run Tesseract OCR on it."""
    _configure_tesseract()
    poppler_path = os.getenv("POPPLER_PATH", "").strip() or None
    try:
        images = convert_from_path(pdf_path, dpi=dpi, poppler_path=poppler_path)
    except Exception as exc:
        raise ValueError("PDF OCR is unavailable: install Poppler or set POPPLER_PATH in backend/.env.") from exc
    text_chunks = []
    for img in images:
        text_chunks.append(pytesseract.image_to_string(img))
    return "\n".join(text_chunks)


def extract_text_from_image(image_path: str) -> str:
    """For a photo/screenshot of a resume rather than a PDF."""
    _configure_tesseract()
    img = Image.open(image_path)
    return pytesseract.image_to_string(img)


def extract_text_from_docx(docx_path: str) -> str:
    """Extract paragraphs from DOCX without requiring a heavyweight SDK."""
    try:
        with zipfile.ZipFile(docx_path) as archive:
            root = ElementTree.fromstring(archive.read("word/document.xml"))
    except (KeyError, zipfile.BadZipFile, ElementTree.ParseError) as exc:
        raise ValueError("Invalid DOCX resume") from exc
    paragraphs = []
    for paragraph in root.iter():
        if paragraph.tag.endswith("}p"):
            text = "".join(node.text or "" for node in paragraph.iter() if node.tag.endswith("}t"))
            if text.strip(): paragraphs.append(text.strip())
    return "\n".join(paragraphs)


def needs_ocr_fallback(native_text: str, num_pages: int) -> bool:
    """Decide whether the native extraction actually got usable text."""
    avg_chars_per_page = len(native_text.strip()) / max(num_pages, 1)
    return avg_chars_per_page < MIN_CHARS_PER_PAGE


def clean_text(raw_text: str) -> str:
    """
    Step 2: Cleaning + Normalization.
    Collapses whitespace, strips odd control characters and page-number
    noise, and normalizes bullet characters — without destroying real
    content (so this stays conservative).
    """
    text = raw_text.replace("\x0c", " ")               # form-feed from PDF page breaks
    text = re.sub(r"[•●▪◦‣]", "- ", text)                # normalize bullets
    text = re.sub(r"[ \t]+", " ", text)                  # collapse repeated spaces/tabs
    text = re.sub(r"\n{3,}", "\n\n", text)               # collapse 3+ blank lines to 1
    text = re.sub(r"^\s*\d+\s*$", "", text, flags=re.MULTILINE)  # stray page-number lines
    text = "\n".join(line.strip() for line in text.split("\n"))
    return text.strip()


def split_sentences(text: str) -> list[str]:
    """
    Step 2: Sentence splitting.
    Resumes are bullet-heavy, not full prose, so split on both sentence
    punctuation AND newlines/bullets rather than relying on a full NLP
    sentence splitter (spaCy sentence splitting is unreliable on resumes
    -- most "sentences" here are actually bullet fragments).
    """
    lines = [ln.strip(" -\u2022") for ln in text.split("\n") if ln.strip()]
    fragments = []
    for line in lines:
        # further split a line if it has multiple '.'-separated clauses
        parts = re.split(r"(?<=[.!?])\s+(?=[A-Z])", line)
        fragments.extend(p.strip() for p in parts if p.strip())
    return fragments


def extract_resume_text(file_path: str) -> dict:
    """
    Main entry point. Returns a dict with the raw text, cleaned text,
    sentence/bullet fragments, and which extraction path was used
    (useful for debugging + for logging in your pipeline).
    """
    path = Path(file_path)
    suffix = path.suffix.lower()

    if suffix in {".png", ".jpg", ".jpeg", ".webp"}:
        raw = extract_text_from_image(str(path))
        method = "ocr_image"

    elif suffix == ".pdf":
        with pdfplumber.open(str(path)) as pdf:
            num_pages = len(pdf.pages)
        native = extract_text_native(str(path))

        if needs_ocr_fallback(native, num_pages):
            raw = extract_text_ocr(str(path))
            method = "ocr_pdf_fallback"
        else:
            raw = native
            method = "native_pdf_text"

    elif suffix in {".txt", ".md"}:
        raw = path.read_text(encoding="utf-8", errors="ignore")
        method = "plain_text"

    elif suffix == ".docx":
        raw = extract_text_from_docx(str(path))
        method = "docx_text"

    else:
        raise ValueError(f"Unsupported file type: {suffix}")

    cleaned = clean_text(raw)
    fragments = split_sentences(cleaned)

    return {
        "file": str(path),
        "method": method,
        "raw_text": raw,
        "cleaned_text": cleaned,
        "fragments": fragments,
        "char_count": len(cleaned),
    }


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python resume_extractor.py <path_to_resume>")
        sys.exit(1)

    result = extract_resume_text(sys.argv[1])

    print(f"File: {result['file']}")
    print(f"Extraction method used: {result['method']}")
    print(f"Cleaned text length: {result['char_count']} chars\n")

    print("--- CLEANED TEXT (first 500 chars) ---")
    print(result["cleaned_text"][:500])

    print(f"\n--- FRAGMENTS ({len(result['fragments'])} total) ---")
    for i, frag in enumerate(result["fragments"][:15], 1):
        print(f"{i:2d}. {frag}")
