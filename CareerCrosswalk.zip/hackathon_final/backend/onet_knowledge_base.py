"""O*NET-backed skill context and occupation discovery."""
from __future__ import annotations
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence

SOURCE_TYPE = "onet_official_software_skills"

@dataclass(frozen=True)
class SkillContext:
    skill: str; related_occupations: List[str]; importance: float; workforce_relevance: str; source_type: str = SOURCE_TYPE

class OnetKnowledgeBase:
    source_type = SOURCE_TYPE
    def __init__(self, job_profiles_path: Path):
        self.job_profiles: Dict[str, dict] = json.loads(job_profiles_path.read_text(encoding="utf-8"))
        self._index = self._build_skill_index(self.job_profiles)

    @staticmethod
    def _build_skill_index(profiles: Mapping[str, dict]) -> Dict[str, SkillContext]:
        values: dict[str, dict[str, Any]] = {}
        for profile in profiles.values():
            title = str(profile.get("title", "Unknown occupation"))
            for item in profile.get("skills", []):
                name = str(item["name"])
                record = values.setdefault(name, {"occupations": [], "importance": 1.0, "categories": set()})
                record["occupations"].append(title)
                record["importance"] = max(record["importance"], float(item.get("weight", 1.0)))
                if item.get("category"): record["categories"].add(str(item["category"]))
        return {name: SkillContext(name, sorted(set(value["occupations"])), float(value["importance"]), "O*NET Software Skills workplace example" + (f" ({', '.join(sorted(value['categories']))})" if value["categories"] else "")) for name, value in values.items()}

    def _get(self, skill: str) -> SkillContext:
        return self._index.get(skill, SkillContext(skill, [], 1.0, "Not present in the scoped O*NET Software Skills data."))
    def get_skill_context(self, skill: str) -> Dict[str, object]:
        context = self._get(skill)
        return {"skill": context.skill, "related_occupations": list(context.related_occupations), "importance": context.importance, "workforce_relevance": context.workforce_relevance, "source_type": context.source_type}
    def get_related_occupations(self, skill: str) -> List[str]: return list(self._get(skill).related_occupations)
    def get_skill_importance(self, skill: str) -> float: return float(self._get(skill).importance)
    def canonical_skill_names(self) -> List[str]: return sorted(self._index, key=str.casefold)

    def rank_occupations(self, candidate_matches: Sequence[Mapping[str, Any]], limit: int = 10) -> list[dict[str, Any]]:
        evidence = {str(item["skill"]): item for item in candidate_matches if str(item.get("skill", "")) in self._index}
        ranked = []
        for soc, profile in self.job_profiles.items():
            requirements = profile.get("skills", [])
            matched = [item for item in requirements if item["name"] in evidence]
            if not matched: continue
            total = sum(float(item.get("weight", 1.0)) for item in requirements)
            overlap = sum(float(item.get("weight", 1.0)) * float(evidence[item["name"]].get("numeric_confidence", 0.5)) for item in matched)
            missing = [item["name"] for item in sorted(requirements, key=lambda item: float(item.get("weight", 1.0)), reverse=True) if item["name"] not in evidence][:8]
            ranked.append({"soc_code": soc, "occupation": profile.get("title", soc), "overlap": len(matched), "weighted_overlap": round(overlap, 4), "match_pct": round(100 * overlap / total, 1) if total else 0.0, "skills": [item["name"] for item in matched], "missing_skills": missing, "source_type": self.source_type})
        return sorted(ranked, key=lambda item: (-item["match_pct"], -item["overlap"], item["occupation"]))[:limit]
