"""Build the production O*NET technology catalog used by CareerCrosswalk.

``Workplace Example`` contains concrete technologies; ``Element Name`` is only
a broad classification. Resume matching must use the concrete technology.
"""
from __future__ import annotations

import csv
import json
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
OUTPUT = Path(__file__).resolve().parent / "job_profiles.json"
KEEP_SOC = {"15-2051.00", "15-2051.01", "15-1221.00", "15-2031.00", "15-1242.00", "15-1243.00", "15-1243.01", "15-1252.00", "15-1251.00", "15-1253.00", "15-1254.00", "15-1299.08", "15-1244.00", "15-1241.00", "15-1211.00", "15-1212.00", "15-1299.04", "15-1299.05"}


def _weight(row: dict[str, str]) -> float:
    value = 1.0
    if row.get("Hot Technology", "").strip().upper() == "Y":
        value *= 1.5
    if row.get("In Demand", "").strip().upper() == "Y":
        value *= 1.3
    return min(value, 1.8)


def build_profiles() -> dict[str, dict]:
    with (DATA_DIR / "Occupation Data.txt").open(encoding="latin-1", newline="") as handle:
        titles = {row["O*NET-SOC Code"].strip(): row["Title"].strip() for row in csv.DictReader(handle, delimiter="\t")}
    grouped: dict[str, dict[str, dict]] = defaultdict(dict)
    with (DATA_DIR / "Software Skills.txt").open(encoding="latin-1", newline="") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            soc, technology = row["O*NET-SOC Code"].strip(), row.get("Workplace Example", "").strip()
            if soc not in KEEP_SOC or not technology:
                continue
            entry = {"name": technology, "weight": _weight(row), "category": row.get("Element Name", "").strip(), "hot_technology": row.get("Hot Technology", "").strip().upper() == "Y", "in_demand": row.get("In Demand", "").strip().upper() == "Y"}
            existing = grouped[soc].get(technology)
            if existing is None or entry["weight"] > existing["weight"]:
                grouped[soc][technology] = entry
    return {soc: {"title": titles.get(soc, soc), "skills": sorted(entries.values(), key=lambda item: item["name"].casefold()), "skill_count": len(entries)} for soc, entries in sorted(grouped.items())}


if __name__ == "__main__":
    profiles = build_profiles()
    OUTPUT.write_text(json.dumps(profiles, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {OUTPUT} with {len(profiles)} occupations and {sum(p['skill_count'] for p in profiles.values())} role-skill records.")
