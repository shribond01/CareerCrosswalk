"""Production API bridge for the CareerCrosswalk frontend.

The application exposes the real O*NET-backed resume pipeline.  It never
returns fixture skills when extraction, matching, OCR, or an optional AI
provider fails; each failure is reported as an actionable HTTP error instead.
"""
from __future__ import annotations
import json
import logging
import os
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

try:
    from dotenv import load_dotenv
except ImportError:  # Keeps the core resume API usable if the optional AI extra is absent.
    load_dotenv = None  # type: ignore[assignment]

ROOT = Path(__file__).resolve().parent.parent
BACKEND = Path(__file__).resolve().parent
if load_dotenv is not None:
    load_dotenv(BACKEND / ".env")

logger = logging.getLogger("careercrosswalk.api")
sys.path.insert(0, str(ROOT / "WOS" / "ml" / "src"))
from onet_knowledge_base import OnetKnowledgeBase
from resume_extractor import extract_resume_text
from workforce_pipeline import WorkforcePipeline

MAX_UPLOAD_BYTES = 10 * 1024 * 1024
ALLOWED_SUFFIXES = {".pdf", ".docx", ".txt", ".md", ".png", ".jpg", ".jpeg", ".webp"}
app = FastAPI(title="CareerCrosswalk API", version="1.0.0")
origins = [item.strip() for item in os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173,http://localhost:5174,http://127.0.0.1:5174").split(",") if item.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["GET", "POST"], allow_headers=["*"], allow_credentials=False)

_kb = OnetKnowledgeBase(BACKEND / "job_profiles.json")
_artifact = BACKEND / "onet_skill_embeddings_e5.json"
def _valid_artifact(path: Path) -> Path | None:
    if not path.exists(): return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        return path if payload.get("skills") == _kb.canonical_skill_names() and len(payload.get("vectors", [])) == len(payload.get("skills", [])) else None
    except (OSError, json.JSONDecodeError): return None
_pipeline = WorkforcePipeline(
    skill_names=_kb.canonical_skill_names(),
    skill_embedding_artifact=_valid_artifact(_artifact),
    knowledge_base=_kb,
    selection_threshold=0.60,
)


class ChatMessage(BaseModel):
    role: str = Field(pattern="^(user|assistant)$")
    content: str = Field(min_length=1, max_length=6_000)


class ChatRequest(BaseModel):
    messages: list[ChatMessage] = Field(min_length=1, max_length=20)
    context: str = Field(default="", max_length=8_000)

@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "knowledge_source": _kb.source_type,
        "skills_loaded": len(_kb.canonical_skill_names()),
        "embedding_artifact": "validated" if _valid_artifact(_artifact) else "generated_at_startup",
        "ocr_available": bool(os.getenv("TESSERACT_CMD") or shutil.which("tesseract")),
        "ai_configured": bool(os.getenv("GEMINI_API_KEY")),
    }

@app.post("/api/resume/analyze")
async def analyze_resume(file: UploadFile = File(...), job_description: str = Form("")) -> dict[str, Any]:
    filename = file.filename or "resume"
    suffix = Path(filename).suffix.lower()
    if suffix not in ALLOWED_SUFFIXES:
        raise HTTPException(415, f"Unsupported file type. Allowed: {', '.join(sorted(ALLOWED_SUFFIXES))}")
    content = await file.read()
    if not content: raise HTTPException(422, "The uploaded file is empty.")
    if len(content) > MAX_UPLOAD_BYTES: raise HTTPException(413, "Resume exceeds the 10 MB upload limit.")
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as handle:
            handle.write(content); temp_path = Path(handle.name)
        extraction = extract_resume_text(str(temp_path))
        if not extraction["cleaned_text"].strip(): raise HTTPException(422, "No readable text was found in the resume.")
        # A generic technical-role description supplies a readiness/gap view
        # when a specific vacancy is not supplied. Career discovery below is
        # still independently ranked from the candidate's O*NET skill profile.
        description = job_description.strip() or "Python SQL Docker Git software development data analysis"
        readiness = _pipeline.analyze_candidate(extraction["cleaned_text"], description)
        candidate_matches = readiness["evidence"]["selected_candidate_matches"]
        careers = _kb.rank_occupations(candidate_matches)
        result = {
            **readiness,
            "career_paths": careers,
            "extraction": {"method": extraction["method"], "char_count": extraction["char_count"]},
            "knowledge_source": _kb.source_type,
        }
        return {
            "status": "real_analysis",
            "ok": True,
            "fileName": filename,
            "pipeline": "O*NET + WorkforcePipeline",
            "job_description_source": "user" if job_description.strip() else "generic_technical_baseline",
            "result": result,
        }
    except HTTPException: raise
    except ValueError as exc: raise HTTPException(422, str(exc)) from exc
    except Exception as exc:
        logger.exception("Resume analysis failed")
        raise HTTPException(503, "Analysis service is unavailable. Check the server logs for model or OCR dependency errors.") from exc
    finally:
        if temp_path is not None: temp_path.unlink(missing_ok=True)


@app.post("/api/ai/chat")
def ai_chat(request: ChatRequest) -> dict[str, str]:
    """Use Gemini only when the server is explicitly configured for it.

    The browser never receives the provider key. Provider/API failures are
    intentionally not replaced with fabricated assistant text.
    """
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        raise HTTPException(503, "AI chat is not configured. Set GEMINI_API_KEY in backend/.env and restart the API.")
    try:
        from google import genai
    except ImportError as exc:
        raise HTTPException(503, "AI chat dependency is missing. Install backend requirements and restart the API.") from exc

    conversation = "\n".join(f"{item.role.title()}: {item.content}" for item in request.messages)
    prompt = (
        "You are the CareerCrosswalk assistant. Use only the supplied career-analysis context. "
        "Do not claim that salary, job-market, or profile data exists unless it appears in the context. "
        "Give concise, practical career guidance.\n\n"
        f"Analysis context:\n{request.context or 'No analysis context is available yet.'}\n\n"
        f"Conversation:\n{conversation}\n\nAssistant:"
    )
    try:
        client = genai.Client(api_key=api_key)
        response = client.models.generate_content(
            model=os.getenv("GEMINI_MODEL", "gemini-2.0-flash"),
            contents=prompt,
        )
        content = (getattr(response, "text", None) or "").strip()
        if not content:
            logger.error("Gemini returned no text content")
            raise HTTPException(502, "AI provider returned no usable response.")
        return {"content": content}
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("AI provider request failed")
        raise HTTPException(502, "AI provider request failed. Verify GEMINI_API_KEY, GEMINI_MODEL, and server logs.") from exc
